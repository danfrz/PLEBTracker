#ifndef INTERPRETER_H_
#define INTERPRETER_H_
#include <istream>
#include <ostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <stdio.h>
#include <ctype.h>
#include <ctgmath> //logb

#include "song.h"
#include "instrument.h"
#include "pattern.h"
#include "generator.h"


namespace itrp
{

    struct Track
    {
        unsigned char *ptbl;
        float lastfrq;
        float frq;
        float nextfrq;
        float phase;

        unsigned short segments;
        unsigned char fx;
        unsigned char fxparam;
        Instrument *inst;

        unsigned short wavei;
        unsigned char lastwave;
        unsigned char waveduracc;

        unsigned char ptrnvol;

        unsigned char lastvol;
        unsigned char voli;
        unsigned char volduracc;
    };


    char **songpaths;
    int numsongs;
    

    Song *song;
    Track *tracks;
    Pattern *curpattern;
    unsigned char order;
    generator *generators;
    bool trackmute[256];
    float amplifyall;


    void initializeWaveTable();
    void initializeRender();

    bool resetsPhaseOnWave1Set(const unsigned char &wave);


    void renderTick(unsigned char *buffer, const unsigned char &track, const unsigned int &bytes);
    unsigned char *renderPattern(int start, int end, unsigned int &bytes);

    unsigned char **renderSong(unsigned int *bytes);
    unsigned char **renderSong(unsigned int *bytes, int start_order, int end_order, int start_row, int end_row);
    bool load(const char *file);
    void play(unsigned char **buffer, const unsigned int orders, unsigned int *bytes);
    void play(unsigned char *buffer, unsigned int bytes);
    void print(unsigned char **buffer, const unsigned int orders, unsigned int *bytes);


/***\//////////////////////////////////////////////////////////////////////////    
Function: void printByte(uchar &b, const char &character, const uchar &res

Description:
   Prints a single byte to cout
   using the specified character
   where each character represents 'res' units
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void printByte(unsigned char &b, const char &character, const unsigned char &res);


/***\//////////////////////////////////////////////////////////////////////////    
Function: void printBuffer(unsigned char *bfr, const unsigned long &len

Description:
   Prints a whole buffer to the console
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void printBuffer(unsigned char *bfr, const unsigned long &len);

    void purgeSong();




}

#endif
