g++ interp/*.cpp  src/*.cpp -Iincludes -Iinterp_includes -lncurses --std=c++11  -o PLEBInterpreter > buildlog.log 2> buildlog.log;
less buildlog.log
