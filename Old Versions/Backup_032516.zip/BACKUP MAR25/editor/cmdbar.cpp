#include "cmdbar.h"


bool editor::getCommand()
{
    int ypos = WIN_HEIGHT -1;
    mvprintw(ypos, 0, std::string(WIN_WIDTH, ' ').c_str(), stdscr);
    mvprintw(ypos, 0, ":", stdscr);
    int in;
    char sel[2];
    sel[1] = 0;
    textCursorPos = 0;
    numBuffer = history_head;
    for(int i = 0; i < 64; i++)
        charInputBuffer[i] = 0;
    while((in = getch()) != '\n' && in != '\t')
    {
        switch(in)
        {
            case KEY_LEFT:
                if(textCursorPos > 0)
                    textCursorPos--;

                break;
            case KEY_RIGHT:
                if(textCursorPos < strlen(charInputBuffer))
                    textCursorPos++;

                break;
            case KEY_UP://History up
                numBuffer--;
                if(numBuffer < 0)
                    numBuffer = history_size - 1;
                copy(charInputHistory[numBuffer], charInputBuffer, 64);
                textCursorPos = strlen(charInputBuffer);

                break;
            case KEY_DOWN://History down

                numBuffer++;
                if(numBuffer >= history_size)
                    numBuffer = 0;
                copy(charInputHistory[numBuffer], charInputBuffer, 64);
                textCursorPos = strlen(charInputBuffer);
                break;
            case KEY_HOME:
                textCursorPos = 0;
                break;
            case KEY_END:
                textCursorPos = strlen(charInputBuffer);
                break;
            case KEY_IC:
                {
                    int length = strlen(charInputBuffer);
                    for(int i = length; i > textCursorPos; i--)
                        charInputBuffer[i] = charInputBuffer[i-1];
                    charInputBuffer[length+1] = 0;
                    charInputBuffer[textCursorPos] = ' ';
                }
            case KEY_DC:
                {
                    int length = strlen(charInputBuffer);
                    for(int i = textCursorPos+1; i < length; i++)
                        charInputBuffer[i-1] = charInputBuffer[i];
                    charInputBuffer[length-1] = 0;
                    if(textCursorPos >= length && length > 0)
                        textCursorPos--;
                }
                break;
            default:
                {
                    if(in <= 'z' && in >= ' ')
                    {
                        charInputBuffer[textCursorPos] = in;
                        if(textCursorPos < strlen(charInputBuffer))
                            textCursorPos++;           
                    }
                }

        }
        editor::copy(charInputBuffer, charBuffer, 64);
        editor::makeUnderlines(charBuffer, 63);

        attroff(-1);
        mvprintw(ypos, 1, charBuffer, stdscr);
        sel[0] = charBuffer[textCursorPos];
        attron(COLOR_PAIR(patternedtr::COL_META_SSS));
        attron(A_BOLD);
        mvprintw(ypos, 1+textCursorPos, sel, stdscr);

        //change 


    }

    if(in == '\t')
        return false;
    copy(charInputBuffer, charInputHistory[history_head], 64);

    history_head++;
    if(history_head >= HISTORY_SIZE)
        history_head = 0;
    history_size++;
    if(history_size > HISTORY_SIZE)
        history_size = HISTORY_SIZE;
    return true;

}

void editor::tokenize(std::vector<char*> &tokens, int i)
{
    bool wasspace = true;
    for(; i < 29; i++)
    {
        if(wasspace)
        {
            if(charInputBuffer[i] != 0 && charInputBuffer[i] != ' ')
            {
                tokens.push_back(charInputBuffer + i);
                wasspace = false;
            }
        }
        else
        {
            if(charInputBuffer[i] == 0 || charInputBuffer[i] == ' ')
            {
                charInputBuffer[i] = 0;
                wasspace = true;
            }
        }
    }
}

unsigned int editor::parseUnsigned(char *str)
{
    int len = strlen(str);
    unsigned int acc =0;
    for(int i = 0; i < len; i++)
    {
        acc *= 0x10; //Horners!
        if(str[i] >= 'A')
        {
            if(str[i] >= 'a' && str[i] <= 'f')
                acc += (str[i] - 'a' + 0xa);
            else if(str[i] <= 'F')
                acc += (str[i] - 'A' + 0xA);
        }
        else
            if(str[i] >= '0' && str[i] <= '9')
                acc += (str[i] - '0');
    }
    return acc;
}

int editor::parseSigned(char *str)
{
    int acc = 0;
    int len = strlen(str);
    int end = 0;

    bool negative = false;
    if(str[0] == '-')
    {
        negative = true;
        end = 1;
    }
    else if(str[0] == '+')
        end = 1;

    for(int i = len-1; i >= end; i--)
    {
        acc *= 0x10; //Horners!
        if(str[i] >= 'A')
            if(str[i] >= 'a')
                acc += (str[i] - 'a' + 0xa);
            else
                acc += (str[i] - 'A' + 0xA);
        else
            acc += (str[i] - '0');
    }
    if(negative)
        return -acc;
    return acc;
}

float editor::parseFloat(char *str)
{
    float out;
    sscanf( str, "%f", &out);
    return out;
}


void editor::doCommand()
{
    int tokeni = 0;
    int tokenend = 0;
    int len = strlen(charInputBuffer);
    if(len < 1)
        return;

    while(charInputBuffer[tokeni] == ' ' && tokeni < len)
        tokeni++;
    if(tokeni == len)
        return;
    tokenend = tokeni;
    while(charInputBuffer[tokenend] != ' ' && tokenend < len)
        tokenend++;
    charInputBuffer[tokenend] = 0;
    std::vector<char *> tokens;
    editor::tokenize(tokens, tokenend);

    
    if(strcmp(charInputBuffer+tokeni, "w") == 0)//SAVE FILE
        handle_w(tokens);
    else if(strcmp(charInputBuffer+tokeni, "q") == 0) //QUIT TRACKER
        handle_q(tokens);
    
    else if(strcmp(charInputBuffer+tokeni, "wq") == 0) //SAVE AND QUIT
        handle_wq(tokens);
    else if(strcmp(charInputBuffer+tokeni, "o") == 0)//OPEN FILE
        handle_o(tokens);
    
    else if(strcmp(charInputBuffer+tokeni, "e") == 0)//REFRESH FILE
    {
        bool ans = editor::confirm("Restore File?");
        if(ans)
        {
            unsigned char selorder = patternedtr::selorder;
            patternedtr::openSong(lastSongPath);
            if(selorder < editor::song->numOrders())
            {
                patternedtr::selorder = selorder;
                patternedtr::selptrn = song->getPatternByOrder(selorder);
            }

        }
    }
    
    else if(strcmp(charInputBuffer+ tokeni, "d") == 0)//DELETE ...
        editor::handle_d(tokens);
    
    else if(strcmp(charInputBuffer+tokeni, "dd") == 0)//CLEAR TRACK
    {
        patternedtr::clearTrack(); 
    }
    
    else if(strcmp(charInputBuffer+tokeni, "ddd") == 0)//CLEAR PATTERN
    {
        patternedtr::clearPattern();
    }
    
    else if(strcmp(charInputBuffer+tokeni, "y") == 0)//COPY ...
        editor::handle_y(tokens);
    else if(strcmp(charInputBuffer+tokeni, "yy") == 0)//COPY TRACK ...
    {
        editor::handle_yy(tokens);
    }
    else if(strcmp(charInputBuffer+tokeni, "p") == 0)//PASTE ...
        editor::handle_p(tokens);
    
    else if(strcmp(charInputBuffer+tokeni, "n") == 0)//NEW ...
        editor::handle_n(tokens);
    //SET WAVEI for Instrument
    else if(strcmp(charInputBuffer+tokeni, "wave") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned short entry = parseUnsigned(tokens.at(0));
            editor::selinst->setWaveIndex(entry);
        }
        else
            inform("Too many params for Set Wave Index");
    
    }
    //SET selected Instrumnent
    else if(strcmp(charInputBuffer+tokeni, "inst") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= song->numInstruments())
                entry = song->numInstruments()-1;
            patternedtr::selinstrument = entry;
            editor::selinst = song->getInstrument(entry);
            instedtr::selwavrow = editor::selinst->getWaveIndex();
            instedtr::chgSelWavRow(0);
        }
        else
            inform("Too many params for Set Selected Instrument");
    }
    //SET selected Order
    else if(strcmp(charInputBuffer+tokeni, "order") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= song->numOrders())
                entry = song->numOrders()-1;
            patternedtr::selorder = entry;
            patternedtr::selptrn = song->getPatternByOrder(entry);
        }
        else
            inform("Too many params for Set Selected Order");
    
    }
    //CHANGE order's pattern
    else if(strcmp(charInputBuffer+tokeni, "ptrn") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= song->numPatterns())
                    entry = song->numPatterns()-1;
            song->setPatternIndexByOrder(patternedtr::selorder, entry);
            patternedtr::selptrn = song->getPattern(entry);
        }
        else
            inform("Too many params for Set Order's Pattern");
    }
    //SET selected row (window context sensitive)
    else if(strcmp(charInputBuffer+tokeni, "row") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= patternedtr::selptrn->numRows())
                    entry = patternedtr::selptrn->numRows()-1;
            patternedtr::selrow = entry;
        }
        else
            inform("Too many params for Set Row");

    }
    //SET selected track
    else if(strcmp(charInputBuffer+tokeni, "trk") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= patternedtr::selptrn->numTracks())
                    entry = patternedtr::selptrn->numTracks()-1;
            patternedtr::seltrack = entry;
        }
        else
            inform("Too many params for Set Track");
    
    }
    //SET step
    else if(strcmp(charInputBuffer+tokeni, "step") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            patternedtr::edit_step = entry;
        }
        else
            inform("Too many params for Set Edit Step");
    }
    //SET octave
    else if(strcmp(charInputBuffer+tokeni, "oct") == 0)
    {
    
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= 6)
                    entry = 6;
            patternedtr::octave = entry;
        }
        else
            inform("Too many params for Set Octave");
    }
    else if(strcmp(charInputBuffer+tokeni, "trans") == 0)
    {
        //+ semitones
        editor::handle_trans(tokens);

    }else if(strcmp(charInputBuffer+tokeni, "transall") == 0)
    {
        //+ semitones
        editor::handle_transall(tokens);

    }
    else if(strcmp(charInputBuffer+tokeni, "transkey") == 0)
    {
        //+ semitones
        editor::handle_transkey(tokens);

    }
    else if(strcmp(charInputBuffer+tokeni, "transkeyall") == 0)
    {
        //+ semitones
        editor::handle_transkeyall(tokens);

    }
    else if(strcmp(charInputBuffer+tokeni, "amp") == 0)
    {
        editor::handle_amp(tokens);

    }
    else if(strcmp(charInputBuffer+tokeni, "amplin") == 0)
    {
        //amp, linear prog

    }
    else if(strcmp(charInputBuffer+tokeni, "lengthen") == 0)
    {

    }
    else if(strcmp(charInputBuffer+tokeni, "key") == 0)
    {
        if(tokens.size() == 1)
        {
            //C to  B
            
        
        
        }
    }
    else
    {
        editor::inform("Input misunderstood              :(");
    }



}

void editor::handle_q(std::vector<char*> &params)
{
    bool ans = editor::confirm("Exit?");
    if(ans)
        patternedtr::exit();

}

void editor::handle_w(std::vector<char*> &params)
{

    //get extra parameter

    //confirm save

    
    if(params.size() > 0)
    {
        if(params.size() == 1)
        {
            bool ans = editor::confirm("Save to File?");
            if(ans)
            {
                bool scc = patternedtr::saveSong(params.at(0));
                if(scc)
                {
                    int len = strlen(params.at(0));
                    editor::copy(params.at(0), lastSongPath, len);
                }
                else
                    editor::inform("Couldn't save file");
            }
        }
        else
            editor::inform("Too many parameters for Save");
    }
    else
    {
        bool ans = editor::confirm("Save?");
        patternedtr::saveSong(lastSongPath);
    }
}

void editor::handle_wq(std::vector<char*> &params)
{
    //confirm save and quit
    //get extra parameter

    if(params.size() > 0)
    {
        if(params.size() == 1)
        {
            bool ans = editor::confirm("Save to File then Quit?");
            if(ans)
            {
                bool scc = patternedtr::saveSong(params.at(0));
                if(scc)
                {
                    patternedtr::exit();
                }
                else
                    editor::inform("Couldn't save file");
            }
        }
        else
            editor::inform("Too many parameters for Save");
    }
    else
    {
        bool ans = editor::confirm("Save and Quit?");

        if(ans)
        {
            bool scc = patternedtr::saveSong(lastSongPath);
            if(scc)
                patternedtr::exit();
            else
                editor::inform("Too many parameters for Save");
        }
    }
}

void editor::handle_o(std::vector<char*> &params)
{
        //get parameter
    if(params.size() > 0)
    {
        if(params.size() == 1)
        {
            bool ans = editor::confirm("Open from File?");
            if(ans)
            {
                bool scc = patternedtr::openSong(params.at(0));
                if(scc)
                {
                    int len = strlen(params.at(0));
                    editor::copy(params.at(0), lastSongPath, len);
                }
            }
        }
        else
            editor::inform("Too many parameters for Open");
    }
    else
    {
        bool ans = editor::confirm("Restore Song?");
        if(ans)
            patternedtr::openSong(lastSongPath);
    }
}

void editor::handle_d(std::vector<char*> &params)
{
    //get type by parameter
    //    no type: ...
    //            get region for pattern editor
    //          trk: clear track
    //          inst: instrument
    //          order: order 
    //          ptrn: delete pattern
    //         

    if(params.size() > 0)
    {
        char *p = params.at(0);
        if(strcmp(p, "trk") == 0)
            patternedtr::clearTrack();
        else if(strcmp(p, "inst") == 0)
            patternedtr::removeInstrument();
        else if(strcmp(p, "order") == 0)
            patternedtr::removeOrder();
        else if(strcmp(p, "ptrn") == 0)
            patternedtr::removePattern();
        else 
            inform("(d)Param not understood");

    }
    else
        patternedtr::selptrn->setAt(patternedtr::seltrack, patternedtr::selrow, R_EMPTY);
}

void editor::handle_amp(std::vector<char *> &params)
{
    if(params.size() > 0)
    {
        float amp;
        unsigned char begin=0, end=patternedtr::selptrn->numRows()-1;
        amp = parseFloat(params.at(0));
        if(params.size() > 1)
        {
            begin = parseUnsigned(params.at(1));
            if(params.size() > 2)
            {
                end = parseUnsigned(params.at(2));

                if(params.size() > 3)
                {
                    inform("Amplify Track(amp) requires 1 to 3 params");
                    return;
                }
            }
        }

        if(amp == 1)
            return;

        if(end >= patternedtr::selptrn->numRows())
            end = patternedtr::selptrn->numRows() - 1;

        unsigned int entry;
        unsigned char volume;
        for(int i = begin; i < end; i++)
        {
            entry = patternedtr::selptrn->at(patternedtr::seltrack, begin+i);
            if(entry != R_EMPTY)
            {
                volume = (entry & R_VOLUME) >> RI_VOLUME;
                volume*= amp;
                if(volume > 0x3F)
                    volume = 0x3F;
                entry &= ~R_VOLUME;
                entry |= (volume << RI_VOLUME);
            }
            patternedtr::selptrn->setAt(patternedtr::seltrack, begin+i, entry);
        }

    }
    else
        inform("Amplify Track(amp) requires 1 to 3 params");
}


void editor::handle_yy(std::vector<char *> &params)
{
    if(params.size() > 0)
    {
        float amp = 1;
        unsigned char begin=0, end=patternedtr::selptrn->numRows()-1;
        if(params.size() > 1)
        {
            begin = parseUnsigned(params.at(1));
            if(params.size() > 2)
            {
                end = parseUnsigned(params.at(2));
                if(params.size() > 3)
                {
                    amp = parseFloat(params.at(3));

                    if(params.size() > 4)
                    {
                        inform("Copy Track(yy) requires 1 to 4 params");
                        return;
                    }
                }
            }
        }


        unsigned char srctrk = parseUnsigned(params.at(0));
        if(srctrk < patternedtr::selptrn->numTracks())
        {
            int len = end-begin+1;
            if((patternedtr::selrow + len) > patternedtr::selptrn->numRows())
                len = patternedtr::selptrn->numRows() - patternedtr::selrow;
            //Copy from srctrk to editor::seltrack
            unsigned int entry;
            unsigned char volume;
            for(int i = 0; i < len; i++)
            {
                entry = patternedtr::selptrn->at(srctrk, begin+i);
                if(amp != 1 && entry != R_EMPTY)
                {
                    volume = (entry & R_VOLUME) >> RI_VOLUME;
                    volume*= amp;
                    if(volume > 0x3F)
                        volume = 0x3F;
                    entry &= ~R_VOLUME;
                    entry |= (volume << RI_VOLUME);
                }
                patternedtr::selptrn->setAt(patternedtr::seltrack, patternedtr::selrow+i, entry);
            }
        }

    }
    else
        inform("Copy Track(yy) requires 1 to 4 params");
}

void editor::handle_y(std::vector<char*> &params)
{
    //get region by parameters
    //if no region, copy cell selected
    if(params.size() > 0)
    {
        char *p = params.at(0);
        if(strcmp(p, "trk") == 0)
        {
            //get destination
        }
        else if(strcmp(p, "inst") == 0)
        {
            if(params.size() == 2)
            {
                unsigned short entry = parseUnsigned(params.at(1));
                if(entry > song->numInstruments())
                    inform("Copy(y) Instrument invalid, cant copy");
                else
                {
                    patternedtr::selinstrument = entry;
                    selinst = song->getInstrument(entry);
                }

            }
            else
                patternedtr::cloneInstrument();
        }
        else if(strcmp(p, "order") == 0)
            patternedtr::cloneOrder();
        else if(strcmp(p, "ptrn") == 0)
            patternedtr::clonePattern();
        else 
            inform("Copy(y) Param not understood");

    }


}


void editor::handle_p(std::vector<char*> &params)
{
    //paste at location by parameters
    //if no location, past at selected cell
}


//Transpose
void editor::handle_trans(std::vector<char*> &params)
{
    //transpose x semitones
    //parameters :trans semitone trkstart trkend start end
    if(params.size() > 0)
    {

        unsigned char trkbegin=0, trkend=patternedtr::selptrn->numTracks()-1;
        unsigned char begin=0, end=patternedtr::selptrn->numRows()-1;
        if(params.size() > 1)
        {
            trkbegin = parseUnsigned(params.at(1));
            trkend = trkbegin;
            if(params.size() > 2)
            {
                trkend = parseUnsigned(params.at(2));
                if(params.size() > 3)
                {
                    begin = parseUnsigned(params.at(3));

                    if(params.size() > 4)
                    {
                        end = parseUnsigned(params.at(4));

                        if(params.size() > 5)
                        {
                            inform("Tanspose(trans) requires 1 to 5 params");
                            return;
                        }
                    }
                }
            }
        }

        if(trkbegin >= patternedtr::selptrn->numTracks())
        {
            inform("Transpose(trans) param 2(trkstart) >= tracks");
            return;
        }

        if(trkend >= patternedtr::selptrn->numTracks())
        {
            trkend = patternedtr::selptrn->numTracks()-1;
        }

        if(begin >=  patternedtr::selptrn->numRows())
        {
            inform("Transpose(trans) param 4(rowstart) >= rows");
            return;
        }

        if(end >=  patternedtr::selptrn->numRows())
        {
            end = patternedtr::selptrn->numRows()-1;
        }


        unsigned char semitones = parseSigned(params.at(0));
        if(semitones == 0)
            return;

        int len = end-begin+1;
        int trklen = trkend-trkbegin+1;
        
        unsigned int entry;
        unsigned int note;
        unsigned int oct;
        for(int j = 0; j < trklen; j++)
        {
            for(int i = 0; i < len; i++)
            {
                entry = patternedtr::selptrn->at(trkbegin+j, begin+i);
                if((entry & R_FULLSEG) != R_FULLSEG)
                {
                    note = (entry & R_PITCHSEG);
                    if(semitones > 0)
                        note = patternedtr::addNotes(note, semitones*0x02000000);
                    else 
                        note = patternedtr::subNotes(note, (-semitones)*0x02000000);


                    entry &= ~R_PITCHSEG;
                    entry |= note;
                    patternedtr::selptrn->setAt(trkbegin+j, begin+i, entry);
                }
            }
        }

    }
    else
        inform("Transpose(trans) requires 1 to 5 params");

}


void editor::handle_transkeyall(std::vector<char*> &params)
{
    Pattern *selection = patternedtr::selptrn;

    unsigned char numpats = editor::song->numPatterns();
    for(int i = 0; i < numpats; i++)
    {
        patternedtr::selptrn = editor::song->getPattern(i);
        handle_transkey(params);
    }

    patternedtr::selptrn = selection;
}



void editor::handle_transall(std::vector<char*> &params)
{
    Pattern *selection = patternedtr::selptrn;

    unsigned char numpats = editor::song->numPatterns();
    for(int i = 0; i < numpats; i++)
    {
        patternedtr::selptrn = editor::song->getPattern(i);
        handle_trans(params);
    }

    patternedtr::selptrn = selection;
}


//Transpose to a key
void editor::handle_transkey(std::vector<char*> &params)
{

    //transpose x semitones
    //parameters :trans semitone trkstart trkend start end
    if(params.size() > 1)
    {

        unsigned char trkbegin=0, trkend=patternedtr::selptrn->numTracks()-1;
        unsigned char begin=0, end=patternedtr::selptrn->numRows()-1;
        if(params.size() > 2)
        {
            trkbegin = parseUnsigned(params.at(2));
            trkend = trkbegin;
            if(params.size() > 3)
            {
                trkend = parseUnsigned(params.at(3));
                if(params.size() > 4)
                {
                    begin = parseUnsigned(params.at(4));

                    if(params.size() > 5)
                    {
                        end = parseUnsigned(params.at(5));

                        if(params.size() > 6)
                        {
                            inform("Tanspose(trans) requires 1 to 5 params");
                            return;
                        }
                    }
                }
            }
        }

        if(trkbegin >= patternedtr::selptrn->numTracks())
        {
            inform("Transpose Key(trans) param 3(trkstart) >= tracks");
            return;
        }

        if(trkend >= patternedtr::selptrn->numTracks())
        {
            trkend = patternedtr::selptrn->numTracks() - 1;
        }

        if(begin >=  patternedtr::selptrn->numRows())
        {
            inform("Transpose Key(trans) param 5(rowstart) >= rows");
            return;
        }

        if(end >=  patternedtr::selptrn->numRows())
        {
            end = patternedtr::selptrn->numRows()-1;
        }


        unsigned char key = parseUnsigned(params.at(0));
        unsigned char semitones = parseSigned(params.at(1));

        int len = end-begin+1;
        int trklen = trkend-trkbegin+1;
        
        unsigned int entry;
        unsigned int note;
        unsigned int oct;
        for(int j = 0; j < trklen; j++)
        {
            for(int i = 0; i < len; i++)
            {
                entry = patternedtr::selptrn->at(trkbegin+j, begin+i);
                if((entry & R_FULLSEG) != R_FULLSEG)
                {
                    note = (entry & R_PITCHSEG);
                    if(semitones != 0)
                    {
                        if(semitones > 0)
                            note = patternedtr::addNotes(note, semitones*0x02000000);
                        else 
                            note = patternedtr::subNotes(note, (-semitones)*0x02000000);
                    }
                    note = patternedtr::toKey(note, key);

                    entry &= ~R_PITCHSEG;
                    entry |= note;
                    patternedtr::selptrn->setAt(trkbegin+j, begin+i, entry);
                }
            }
        }

    }
    else
        inform("Transpose Key(trans) requires 2 to 6 params");

}



void editor::handle_n(std::vector<char*> &params)
{
    //get type by parameter...
    //   no param: new Song
    //          song: new Song
    //          inst: new Instrument
    //             i: new Instrument
    //   
    if(params.size() > 0)
    {
        char *p = params.at(0);
        if(strcmp(p, "song") == 0)
        {
            patternedtr::newSong();
        }
        else if(strcmp(p, "inst") == 0)
            patternedtr::newInstrument();
        else if(strcmp(p, "order") == 0)
            patternedtr::newOrder();
        else if(strcmp(p, "ptrn") == 0)
            patternedtr::newPattern();
        else 
            inform("(n)Param not understood");

    }
    else
    {
        bool scc = confirm("New song? All unsaved will be lost");
        if(scc)
            patternedtr::newSong();
    }


}







