#!/bin/bash

mkdir /var/tmp/plebtrk 2>/dev/null
echo "Dependencies include:"
echo "   ncurses"     #trk
echo "   aplay"       #itp
echo "   inotifywait" #trkdaemon

touch /var/tmp/plebtrk/signal
touch /var/tmp/plebtrk/playback.plb
touch /var/tmp/plebtrk/itplog.log
touch /var/tmp/plebtrk/trklog.log

