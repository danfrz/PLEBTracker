#!/bin/bash

TEMPDIR="/var/tmp/plebtrk"
LOGPATH="$TEMPDIR/trklog.log"



./plebtrkdaemon.sh & #Run the daemon in the background
sleep 0.1 # the daemon do its thing for a moment
/home/$USER/Workspace\ C/Sound/PLEBTracker 2>"$LOGPATH" "$@"
kill %1  #make sure the daemon stops




