#ifndef PATTERNEDTR_H_
#define PATTERNEDTR_H_
#include <fstream>
#include "instrument.h"
#include "pattern.h"
#include "song.h"
#include "tables.h"
#include "instedtr.h"

namespace patternedtr
{


    unsigned int toKey(const unsigned int &entry, const unsigned char &key);
    unsigned int addNotes(const unsigned int &n1, const unsigned int &n2);
    unsigned int subNotes(const unsigned int &n1, const unsigned int &n2);


/***\//////////////////////////////////////////////////////////////////////////    
Function: void display()

Description:
   Render the pattern editor and metadata window
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void display();

/***\//////////////////////////////////////////////////////////////////////////    
Function: void displayMeta()

Description:
   Renders the metadata window
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void displayMeta();

/***\//////////////////////////////////////////////////////////////////////////    
Function: void displayPattern()

Description:
   Renders the pattern editor window
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void displayPattern();


/***\//////////////////////////////////////////////////////////////////////////    
Function: void processMetaInput(int in)

Description:
   Interprets input as input for the metadata window
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void processMetaInput(int in);

/***\//////////////////////////////////////////////////////////////////////////    
Function: void processPatternInput(int in)

Description:
   Interprets input as input for the pattern editor
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void processPatternInput(int in);

/***\//////////////////////////////////////////////////////////////////////////    
Function: void processInput(int in)

Description:
    Sends the input to the appropriate window
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void processInput(int in);


/***\//////////////////////////////////////////////////////////////////////////    
Function: void chgSelTrack(int i)

Description:
    Increases or decreases the current selected track,
    avoids overflow by comparing against editor::song->numTracks()
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void chgSelTrack(int i);

/***\//////////////////////////////////////////////////////////////////////////    
Function: void chgSelRow(int i)

Description:
    Increases or decreases the current selected rot,
    avoids overflow by comparing against ptrnedtr::selptrn->numRows();
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void chgSelRow(int i);

/***\//////////////////////////////////////////////////////////////////////////    
Function: void chgSelRowSeg(int i)

Description:
    Increases or decreases selected rowsegment,
    wraps around, calling chgSelRow if it overflows or underflows
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void chgSelRowSeg(int i);



/***\//////////////////////////////////////////////////////////////////////////    
Function: void chgSelMetaObj(int i)

Description:
    Cycles through objects in the respective rows of the metadata window
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void chgSelMetaObj(int i);


/***\//////////////////////////////////////////////////////////////////////////    
Function: void chgSelMetaRow(int i)

Description:
    Increases or decreases selected meta row with bounds checks
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void chgSelMetaRow(int i);



/***\//////////////////////////////////////////////////////////////////////////    
Function: void getKeyChar(char *bfr, unsigned char note)

Description:
   Get the key string for the selected key
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void getKeyChar(char *bfr, unsigned char note);

/***\//////////////////////////////////////////////////////////////////////////    
Function: bool setMetaAttribs(unsigned char objmeta, unsigned char rowmeta)

Description:
    Sets NCurses attributes of the provided UI element by index
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    bool setMetaAttribs(unsigned char objmeta, unsigned char rowmeta);

/***\//////////////////////////////////////////////////////////////////////////    
Function: void setPatternAttribs(unsigned char track, unsigned char row, unsigned char seg)

Description:
    Sets NCurses attributes of the provided rowsegment
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void setPatternAttribs(unsigned char track, unsigned char row, unsigned char seg);


/***\//////////////////////////////////////////////////////////////////////////    
Function: makeSpaceBuffer(char *bfr, int length)

Description:
   TODO
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    char *makeSpaceBuffer(char *bfr, int length);


/***\//////////////////////////////////////////////////////////////////////////    
Function: void startMetaEditing()

Description:
    Responsible for performing or beginning an event for the objects in the metawindow
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void startMetaEditing();

/***\//////////////////////////////////////////////////////////////////////////    
Function: void metaEdit(int in)

Description:
    An input event performed on objects in the meta window after
    a startEditing event has been fired and before doneEditing.

    Only buffers are modified, so that the user can back out of an edit.
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void metaEdit(int in);

/***\//////////////////////////////////////////////////////////////////////////    
Function: void doneMetaEditing()

Description:
   Confirms changes to the selected meta window
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void doneMetaEditing();



    void newSong();
    bool saveSong(const char *file);
    const char *browse();
    bool openSong(const char *file);



    void exit();

    void newInstrument();
    void cloneInstrument();
    void removeInstrument();

    void newPattern();
    void clonePattern();
    void clearPattern();
    void removePattern();

    void clearTrack();

    void chgSelOrder(int i);
    void newOrder();
    void cloneOrder();
    void removeOrder();
    void chgOrderPattern(int i);


    
}





#endif
