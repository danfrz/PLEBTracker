#ifndef CMDBAR_H_
#define CMDBAR_H_
#include <ncurses.h>
#include <vector>
#include "tables.h"
#include "patternedtr.h"
#include "tables.h"
#include "instedtr.h"
#include "patternedtr.h"

#include "pattern.h"
#include "instrument.h"
#include "song.h"

namespace editor
{

    int parseSigned(char *str);
    unsigned int parseUnsigned(char *str);
    float parseFloat(char *str);

    void tokenize(std::vector<char*> &tokens, int begin);
    bool getCommand();
    void doCommand();

    void handle_q(std::vector<char*> &params);
    void handle_w(std::vector<char*> &params);
    void handle_wq(std::vector<char*> &params);
    void handle_o(std::vector<char*> &params);
    void handle_d(std::vector<char*> &params);
    void handle_y(std::vector<char*> &params);
    void handle_yy(std::vector<char*> &params);
    void handle_amp(std::vector<char*> &params);
    void handle_p(std::vector<char*> &params);
    void handle_n(std::vector<char*> &params);



    void handle_trans(std::vector<char*> &params);
    void handle_transall(std::vector<char*> &params);
    void handle_transkey(std::vector<char*> &params);
    void handle_transkeyall(std::vector<char*> &params);







}

#endif
