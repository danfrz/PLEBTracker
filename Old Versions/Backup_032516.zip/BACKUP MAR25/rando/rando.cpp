#include "rando.plb"


void populateInstruments()
{
    std::vector<int> inst_wave;
    std::vector<int> inst_perc;
    std::vector<int> inst_arp;

    bool pwm;
    bool arp;

    int i;
    int len;

    //need to look up distributions some time, neeed that
    for(i = 0; i <= 0xFFFF; i++)
    {
        

    }

    

}

void createInst()
{

}


int main(int argc, const char* argv[])
{
    unsigned short segments = rand() % 0x18;
    unsigned int bytesperrow;
    unsigned char rowsperbeat;


    bool fast = rand() % 2;
    if(fast)
    {
        bytesperrow = segments*(0x100 + (rand()%0x2300)/segments);

    }
    else
    {
        bytesperrow = segments*(0x1000 + (rand()%0x3000)/segments);
    
    }
    rowsperbeat = 4;





    unsigned char orders = rand() % 12 + 1;
    for(int i = 0; i < orders; i++)
    {
    
    
    }
    

}
