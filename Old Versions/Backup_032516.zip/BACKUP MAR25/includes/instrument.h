#ifndef INSTRUMENT_H_
#define INSTRUMENT_H_

#include<istream>
#include<ostream>

class Instrument
{
    private:
        char name[23]{0};
        unsigned short waveIndex;

        
        unsigned char volEntries;
        unsigned short *volTable;
    public:

        ~Instrument();
        Instrument();
        Instrument(std::istream &in);
        Instrument(const Instrument &other);

        std::ostream &output(std::ostream &out) const;
        std::istream &input(std::istream &in);

        inline void setWaveIndex(short i){waveIndex = i;}

        inline void setVolEntry(unsigned char index, unsigned short entry){volTable[index] = entry;}
        void setVolTable(unsigned short *table);
        inline char *getName(){return name;}

        inline unsigned short getWaveIndex() const{return waveIndex;}
        inline unsigned short getVolEntry(unsigned char index) const {return volTable[index];}
        inline unsigned char numVolEntries() const {return volEntries;}
        inline unsigned short *getVolTable() const {return volTable;}

        bool insertVolEntry(unsigned char index, unsigned short entry);
        bool removeVolEntry(unsigned char index);
        void fixVolJumps(const unsigned char &index, short difference);

        unsigned char getVolume(unsigned char &cur, unsigned char &seg, unsigned char &last);


        unsigned int size();
};

#endif
