#!/bin/bash

TEMPDIR="/var/tmp/plebtrk"
echo "" > "$TEMPDIR/signal"
while inotifywait -qqe close_write "$TEMPDIR/signal" ; do
    CMD=`tail "$TEMPDIR/signal" --lines 1`
    case "$CMD" in
        p) #Play
            plebitp "$TEMPDIR/playback.plb" 
            ;;
    esac
done
