g++ rando/*.cpp  src/*.cpp -Iincludes -Irando_includes -lncurses --std=c++11  -o PLEBRandomizer > buildlog.log 2> buildlog.log;
less buildlog.log
