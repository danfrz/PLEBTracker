#ifndef RANDO_H_
#define RANDO_H_
#include <istream>
#include <ostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <stdio.h>
#include <ctype.h>

#include "song.h"
#include "instrument.h"
#include "pattern.h"
#include "generator.h"

#endif
