#include "instrument.h"


Instrument::Instrument()
{
    name[0] = 'i';
    name[1] = 'n';
    name[2] = 's';
    name[3] = 't';
    waveIndex = 0;
    volRptStartIndex=0;
    volRptEndIndex=0;
    volSustainIndex=0;
    volEntries=1;
    volTable = new unsigned char[256]{0};//64 integers worth
    volTable[0] = 0x40;
    volDurTable = new unsigned char[256]{0};
}

Instrument::~Instrument()
{
    delete [] volTable;
    delete [] volDurTable;
}

Instrument::Instrument(std::istream &in)
{
    input(in);
}
Instrument::Instrument(const Instrument &other)
{
    waveIndex        = other.waveIndex;
    volRptStartIndex = other.volRptStartIndex;
    volRptEndIndex   = other.volRptEndIndex;
    volSustainIndex  = other.volSustainIndex;
    volEntries       = other.volEntries;
    volTable = new unsigned char[256];//64 integers worth
    for(int i = 0; i < 255; i++)
        volTable[i] = other.volTable[i];

    volDurTable = new unsigned char[256];
    for(int i = 0; i < 255; i++)
        volDurTable[i] = other.volTable[i];
}


std::ostream &Instrument::output(std::ostream &out) const
{
    out << name << '\n'
        << waveIndex << '\n'
        << (volRptStartIndex) << '\n'
        << (volRptEndIndex) << '\n'
        << volSustainIndex << '\n'
        << (volEntries) << '\n';
    for(int i = 0; i < volEntries; i++)
    {
        out << (volTable[i]) << '\n';
        out << (volDurTable[i]) << '\n';
    }

    return out;	
}

std::istream &Instrument::input(std::istream &in)
{
    if(in.peek() == '\n')
        in.ignore(1,'\n');
    in.getline(name,23);
    in >> waveIndex;
    in >> volRptStartIndex >> volRptEndIndex >> volSustainIndex;
    in >> volEntries;
    volTable = new unsigned char[volEntries];
    volDurTable = new unsigned char[volEntries];
    for(int i = 0; i< volEntries; i++)
    {
        in >> volTable[i];
        in >> volDurTable[i];
    }
    return in;

}

unsigned char Instrument::getVolume(unsigned char &cur, unsigned char &time, bool gate)
{
    //Check for progress in the vol table
    while(time > volDurTable[cur])
    {
        time -= volDurTable[cur];
        cur++;
    }

    //Key OFF wasnt set
    if(!gate)
    {
        //if gate wasn't set, keep within loop
        if(volRptStartIndex < volRptEndIndex)
        {
            if(cur > volRptEndIndex)
                cur = volRptStartIndex;
        }

        //Check if on sustain index
        if(volSustainIndex && cur == volSustainIndex)
            return volTable[cur];
    }

    if(cur >= volEntries)
        return volTable[cur-1];

    //Interpolate between the last volume and next over the duration
    unsigned char dest = volTable[cur];
    if(cur >0)
    {
        unsigned char src = volTable[cur-1];
        //interpolate
        return src + ((static_cast<float>(dest) - src) / volDurTable[cur])*time;
    }
    return dest;
}



unsigned int Instrument::size()
{
    const static unsigned int minimal_bytes = sizeof waveIndex
        + sizeof volRptStartIndex
        + sizeof volRptEndIndex
        + sizeof volSustainIndex
        + sizeof volEntries;
    unsigned int bytenum = minimal_bytes;
    bytenum += sizeof(char) * volEntries*2;
    return bytenum;
}

