#ifndef INSTRUMENT_H_
#define INSTRUMENT_H_

#include<istream>
#include<ostream>

class Instrument
{
    private:
        char name[23]{0};
        unsigned short waveIndex;

        unsigned char volRptStartIndex;
        unsigned char volRptEndIndex;
        
        unsigned int volSustainIndex;

	unsigned char volEntries;
        unsigned char *volTable;
        unsigned char *volDurTable;

    public:

        ~Instrument();
        Instrument();
        Instrument(std::istream &in);
        Instrument(const Instrument &other);

	std::ostream &output(std::ostream &out) const;
	std::istream &input(std::istream &in);

        inline void setWaveIndex(short i){waveIndex = i;}
        inline void setVolRptStartIndex(const unsigned char &start){volRptStartIndex = start;}
        inline void setVolRptEndIndex(const unsigned char &end){volRptEndIndex = end;}

        inline void setVolSustainIndex(const unsigned int &sustain_index){volSustainIndex = sustain_index;}
        void setVolTable(unsigned char *table);
        void setVolDurTable(unsigned char *table);
        inline char *getName(){return name;}

        inline unsigned short getWaveIndex() const{return waveIndex;}
        inline unsigned char getVolRptStartIndex() const{return volRptStartIndex;}
        inline unsigned char getVolRptEndIndex() const{return volRptEndIndex;}
        inline unsigned char getVolSustainIndex() const{return volSustainIndex;}

        unsigned char getVolume(unsigned char &cur, unsigned char &time, bool gate=0);


	unsigned int size();
};

#endif
