#include "instedtr.h"
void instedtr::display()
{
}

void instedtr::processInput(int in)
{
}









