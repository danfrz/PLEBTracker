#ifndef TABLES_H_
#define TABLES_H_
#include <map>
#include <ncurses.h>
#include "song.h"
#include "instrument.h"

#define TRACK_WIDTH 15

namespace editor
{
    extern int WIN_HEIGHT, WIN_WIDTH;
    extern WINDOW *metawin;
    extern WINDOW *ptrnwin;
    extern WINDOW *instwin;
    extern WINDOW *volwin;
    extern WINDOW *wavewin;
    extern WINDOW *dialog;

    extern WINDOW *wingroup;
    extern WINDOW *inputwin;
    extern bool running;

    extern Song *song;
    extern Instrument *selinst;

    extern int numBuffer;
    extern char charBuffer[29];

    char *makeUnderlines(char *string, int length);
    char *noteString(char *string, unsigned int entry);
    char *byteString(char *string, const unsigned char byte);
    char *intString(char *string, const unsigned int integer, const unsigned int &strlen);
    char *instString(char *string, const unsigned int &entry);
    char *volString(char *string, const unsigned int &entry);
    char *fxString(char *string, const unsigned int &entry);
    char *fxpString(char *string, const unsigned int &entry);
    

    void copy(char *src, char *dest, int len);
    bool validateHexChar(char a);
    bool validateByte(char str[2]);
    bool validate64(char str[2]);
    unsigned char charHex(char c);
    unsigned char parseHexChar(char str[2]);

}

//Pattern Editor
namespace patternedtr
{

    //PATTERN TABLE
    const unsigned char
        TRKSEG_NOTE = 0,
        TRKSEG_INST = 1,
        TRKSEG_VOL = 2,
        TRKSEG_FX = 3,
        TRKSEG_FXP = 4;

    //Window, Object, Segment selected
    //[S]elected or [U]nselected
    const unsigned char
        COL_META_SSS = 1,
        COL_META_SSU = 2,
        COL_META_SU  = 3,
        COL_META_US  = 4,
        COL_META_UU  = 5;

    const unsigned char
        COL_PTRN_SSS = 8,
        COL_PTRN_SSU_NOTE = 9,
        COL_PTRN_SSU_INST = 10,
        COL_PTRN_SSU_VOL = 11,
        COL_PTRN_SSU_FX = 12,
        COL_PTRN_SSU_SYSFX = 13,
        COL_PTRN_SU_NOTE  = 14,
        COL_PTRN_SU_INST  = 15,
        COL_PTRN_SU_VOL  = 16,
        COL_PTRN_SU_FX  = 17,
        COL_PTRN_SU_SYSFX  = 18,
        COL_PTRN_US  = 19,
        COL_PTRN_UU  = 20;


    void populateNoteMap();
    extern std::map<int, unsigned int> notemap;
    extern Pattern *selptrn;
    extern unsigned char viewporttrack;
    extern unsigned char viewportrow;

    extern unsigned char maxtracksviewport;
    extern unsigned char maxrowsviewport;

    extern unsigned char selrow;
    extern unsigned char seltrack;
    extern unsigned char seltrackseg;
    extern unsigned char selorder;

    extern unsigned char selinstrument;
    extern unsigned char edit_step;
    extern unsigned char octave;


    //WAVE TABLE
    const unsigned char
        WAVSEG_WAVE = 1,
        WAVSEG_TONE = 2,
        WAVSEG_DUR  = 3;

    extern unsigned char selwavrow;
    extern unsigned char selwavseg;

    //METADATA (Main controls)
    extern unsigned char metaobjindex;
    extern  bool metaobjedit;
    extern unsigned char selobjmeta;//x
    extern unsigned char selrowmeta;//y



}

//Instrument Edtior
namespace instedtr
{
    extern unsigned char selvolrow;
    extern bool selvolseg;
}




#endif
