#!/bin/bash

mkdir /var/tmp/plebtrk 2>/dev/null

echo "Dependencies include:"
echo "   ncurses"     #trk
echo "   aplay"       #itp
echo "   inotifywait" #trkdaemon
echo "   flac"        #rend

touch /var/tmp/plebtrk/itplog.log
touch /var/tmp/plebtrk/trklog.log

echo "Copying executables into /usr/bin/..."
sudo cp ./plebplay /usr/bin/plebplay
echo "/usr/bin/plebplay"
sudo cp ./plebitp /usr/bin/plebitp
echo "/usr/bin/plebitp"
sudo cp ./plebrender /usr/bin/plebrender
echo "/usr/bin/plebrender"

