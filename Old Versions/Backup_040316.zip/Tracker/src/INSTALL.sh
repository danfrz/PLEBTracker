#!/bin/bash

mkdir /var/tmp/plebtrk 2>/dev/null

echo "Dependencies include:"
echo "   ncurses"     #trk
echo "   aplay"       #itp
echo "   inotifywait" #trkdaemon

touch /var/tmp/plebtrk/itplog.log
touch /var/tmp/plebtrk/trklog.log

echo "Copying executables into /usr/bin/..."
sudo cp ./plebtrk /usr/bin/plebtrk
echo "/usr/bin/plebtrk"
sudo cp ./plebtrkdaemon /usr/bin/plebtrkdaemon
echo "/usr/bin/plebtrkdaemon"
sudo cp ./plebtrkraw /usr/bin/plebtrkraw
echo "/usr/bin/plebtrkraw"

