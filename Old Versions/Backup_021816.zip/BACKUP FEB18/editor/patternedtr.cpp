#include "patternedtr.h"

#include <iostream>

void patternedtr::populateNoteMap()
{
    //bottom row
    notemap['z'] = 0x00000000;//C+0
    notemap['s'] = 0x02000000;//C#0
    notemap['x'] = 0x04000000;//D+0
    notemap['d'] = 0x06000000;//D#+0
    notemap['c'] = 0x08000000;//E+0
    notemap['v'] = 0x0A000000;//F+0
    notemap['g'] = 0x0C000000;//F#+0
    notemap['b'] = 0x0E000000;//G+0
    notemap['h'] = 0x10000000;//G#+0
    notemap['n'] = 0x12000000;//A+0
    notemap['j'] = 0x14000000;//A#+0
    notemap['m'] = 0x16000000;//B+0

    //bot extra
    notemap[','] = 0x20000000;//C+1
    notemap['l'] = 0x22000000;//C#1
    notemap['.'] = 0x24000000;//D+1
    notemap[';'] = 0x26000000;//D#1
    notemap['/'] = 0x28000000;//E+1

    //top row
    notemap['q'] = 0x20000000;//C+1
    notemap['2'] = 0x22000000;//C#1
    notemap['w'] = 0x24000000;//D+1
    notemap['3'] = 0x26000000;//D#1
    notemap['e'] = 0x28000000;//E+1
    notemap['r'] = 0x2A000000;//F+1
    notemap['5'] = 0x2C000000;//F#+1
    notemap['t'] = 0x2E000000;//G+1
    notemap['6'] = 0x30000000;//G#+1
    notemap['y'] = 0x32000000;//A+1
    notemap['7'] = 0x34000000;//A#+1
    notemap['u'] = 0x36000000;//B+1

    //top extra
    notemap['i'] = 0x40000000;//C+2
    notemap['9'] = 0x42000000;//C#2
    notemap['o'] = 0x44000000;//D+2
    notemap['0'] = 0x46000000;//D#+2
    notemap['p'] = 0x48000000;//E+2
    notemap['['] = 0x4A000000;//F+2
    notemap['='] = 0x4C000000;//F#+2
    notemap[']'] = 0x4E000000;//G+2

}

void patternedtr::chgSelTrack(int i)
{
    seltrack += i;
    if(seltrack >= selptrn->numTracks())
        if(i > 0)
            seltrack = selptrn->numTracks()-1;
        else
        {
            seltrack = 0;
            viewporttrack=0;
            return;
        }

    if(seltrack <= viewporttrack)
        viewporttrack=seltrack;
    else
    {
        if(seltrack >= viewporttrack + maxtracksviewport)
            viewporttrack = seltrack - maxtracksviewport+1;
    }
}

void patternedtr::chgSelRow(int i)
{
    selrow += i;
    if(selrow >= selptrn->numRows())
        if(i > 0)
        {
            selrow = selptrn->numRows()-1;
        }
        else
        {
            selrow = 0;
        }
    if(selrow < viewportrow)
    {
        if(selrow < 4)
            viewportrow = 0;
        else
        {
            int dif = (viewportrow - selrow) /4 + 1;
            viewportrow-=4*dif;
        }
    }
    else
    {
        int w,h;
        getmaxyx(editor::ptrnwin, h, w); 

        if(selptrn->numRows() > h && (selptrn->numRows()-selrow) < 4)
            viewportrow = selptrn->numRows() - maxrowsviewport + 1;
        else
            if(selrow >= viewportrow + h-1)
            {
                int dif = (selrow-(viewportrow+h-1)) /4 + 1;
                viewportrow+=4*dif;
            }
    }

}


void patternedtr::chgSelRowSeg(int i)
{
    seltrackseg += i;
    if(seltrackseg > TRKSEG_FXP)
        if(i > 0)
        {
            if(seltrack < editor::song->numTracks() - 1)
            {
                seltrackseg = TRKSEG_NOTE;
                chgSelTrack(1);
            }
            else
                seltrackseg = TRKSEG_FXP;
        }
        else
        {
            if(seltrack > 0)
            {
                seltrackseg = TRKSEG_FXP;
                chgSelTrack(-1);
            }
            else
                seltrackseg = TRKSEG_NOTE;
        }
}






char *editor::noteString(char *string, unsigned int entry)
{
    if((entry & R_PITCHSEG) == R_PITCHSEG)
    {
        string[0] = ' ';
        string[1] = ' ';
        string[2] = ' ';
        return string;
    }
    unsigned char  oct  = ((entry & R_OCTAVE) >> RI_OCTAVE);
    unsigned char  note = (entry & R_NOTE) >> RI_NOTE;

    string[1]='-';
    string[2]='0' + oct;
    switch(note)
    {
        case 0:
            string[0]='C';
            break;
        case 1:
            string[0]='C';
            string[1]='#';
            break;
        case 2:
            string[0]='D';
            break;
        case 3:
            string[0]='D';
            string[1]='#';
            break;
        case 4:
            string[0]='E';
            break;
        case 5:
            string[0]='F';
            break;
        case 6:
            string[0]='F';
            string[1]='#';
            break;
        case 7:
            string[0]='G';
            break;
        case 8:
            string[0]='G';
            string[1]='#';
            break;
        case 9:
            string[0]='A';
            break;
        case 10:
            string[0]='A';
            string[1]='#';
            break;
        case 11:
            string[0]='B';
            break;
    }
    return string;
}

char *editor::instString(char *string, const unsigned int &entry)
{
    if((entry & R_INSTRUMENT)==R_INSTRUMENT)
    {
        string[0] = ' ';
        string[1] = ' ';
        return string;
    }
    unsigned char inst = (entry & R_INSTRUMENT) >> RI_INSTRUMENT;
    editor::byteString(string, inst);
    return string;
}

char *editor::volString(char *string, const unsigned int &entry)
{
    unsigned char  vol  = (entry & R_VOLUME) >> RI_VOLUME;
    if(vol == 0x3f && (entry & R_FULLSEG) == R_FULLSEG)
    {
        string[0] = ' ';
        string[1] = ' ';
    }
    else
        editor::byteString(string, vol);
    return string;
}

char *editor::fxString(char *string, const unsigned int &entry)
{
    unsigned char  fx   = (entry & R_EFFECT) >> (RI_EFFECT);

    unsigned char  fxp1 = (entry & R_FXPARAM1) >> RI_FXPARAM1;
    unsigned char  fxp2 = (entry & R_FXPARAM2);
    //fx should be validated before this point
    if(fx+fxp1+fxp2 == 0)
    {
        string[0] = ' ';
        return string;
    }

    string[0] = hexnums[fx];
    return string;
}
char *editor::fxpString(char *string, const unsigned int &entry)
{
    unsigned char  fx   = (entry & R_EFFECT) >> RI_EFFECT;

    unsigned char  fxp1 = (entry & R_FXPARAM1) >> RI_FXPARAM1;
    unsigned char  fxp2 = (entry & R_FXPARAM2);
    //fx should be validated before this point
    if(fx + fxp1 + fxp2 == 0)
    {
        string[0] = ' ';
        string[1] = ' ';
        return string;
    }
    string[0] = hexnums[fxp1];
    string[1] = hexnums[fxp2];
    return string;
}

char *patternedtr::makeSpaceBuffer(char *bfr, int length)
{

    switch(length)
    {
        case 1:
            bfr[0] = '.';
            break;
        case 2:
            bfr[0]='.';
            bfr[1]='.';
            break;
        case 3:
            bfr[0]='|';
            bfr[1]='.';
            bfr[2]='|';
            break;
        case 4:
            bfr[0]='|';
            bfr[1]='.';
            bfr[2]='.';
            bfr[3]='|';
            break;
        case 5:
            bfr[0]='|';
            bfr[1]=' ';
            bfr[2]='.';
            bfr[3]=' ';
            bfr[4]='|';
            break;
    }
    if(length > 5)
    {
        int half = (length)/2;
        bfr[0] = '|';
        bfr[1] = ' ';
        bfr[2] = '.';
        bfr[3] = '.';
        for(int i = 4; i < length-1; i++)
            bfr[i] = ' ';
        bfr[length-1] = '|';
    }
    bfr[length] = 0;

    return bfr;
}

void editor::copy(char *src, char *dest, int len)
{
    for(int i = 0; i < len; i++)
        dest[i] = src[i];
}


void patternedtr::setPatternAttribs(unsigned char track, unsigned char row, unsigned char seg)
{
    attroff(-1);
    attron(A_BOLD);
    if(editor::inputwin == editor::ptrnwin)
    {
        const unsigned temp = 0;

        if(row == selrow)
        {
            if(track == seltrack )
                if(seg == seltrackseg)
                {
                    attron(COLOR_PAIR(COL_PTRN_SSS));
                    return;
                }
                else
                {
                    switch(seg)
                    {
                        case TRKSEG_NOTE:
                            attron(COLOR_PAIR(COL_PTRN_SSU_NOTE));
                            return;
                        case TRKSEG_INST:
                            attron(COLOR_PAIR(COL_PTRN_SSU_INST));
                            return;
                        case TRKSEG_VOL:
                            attron(COLOR_PAIR(COL_PTRN_SSU_VOL));
                            return;
                        case TRKSEG_FX:
                        case TRKSEG_FXP:
                            attron(COLOR_PAIR(COL_PTRN_SSU_FX));
                            return;
                    }
                }
        }
        switch(seg)
        {
            case TRKSEG_NOTE:
                attron(COLOR_PAIR(COL_PTRN_SU_NOTE));
                return;
            case TRKSEG_INST:
                attron(COLOR_PAIR(COL_PTRN_SU_INST));
                return;
            case TRKSEG_VOL:
                attron(COLOR_PAIR(COL_PTRN_SU_VOL));
                return;
            case TRKSEG_FX:
            case TRKSEG_FXP:
                attron(COLOR_PAIR(COL_PTRN_SU_FX));
                return;
        }
        attron(COLOR_PAIR(COL_META_SU));

    }
    else
    {
        if(track == seltrack && row == selrow)
            attron(COLOR_PAIR(COL_PTRN_US));
        else
            attron(COLOR_PAIR(COL_PTRN_UU));
    }
}


void patternedtr::displayPattern()
{
    using namespace editor;
    attroff(-1);

    int w, h;
    getmaxyx(editor::ptrnwin, h, w); //TODO: confirm this works
    int tracks_visible = w/15;



    unsigned char minrow = viewportrow;
    unsigned char maxrow = viewportrow+h - 1;
    unsigned char mintrack = viewporttrack;
    unsigned char maxtrack = viewporttrack + tracks_visible ;
    if(selptrn != NULL)
    {
        if(maxrow > selptrn->numRows())
            maxrow = selptrn->numRows();   
        if(maxtrack > selptrn->numTracks())
            maxtrack = selptrn->numTracks();
    }
    tracks_visible = maxtrack - mintrack;


    char name[4];
    name[2] = 0;
    unsigned char visiblerows = maxrow - minrow;
    mvprintw(3, 0, "  ", ptrnwin);
    for(int i = 0; i < visiblerows; i++)
    {
        byteString(name, viewportrow+i);
        mvprintw(4+i, 0, name, ptrnwin);
    }

    //clear spot where rows arent
    for(int i = visiblerows; i < viewportrow+h-1; i++)
        mvprintw(4+i, 0, "  ", ptrnwin);

    for(int i = 0; i < tracks_visible; i++)
    {
        unsigned char xoff = 2+15*i;
        attroff(-1);
        mvprintw(3,xoff, "|TRACK_  __<)_|",ptrnwin);
        name[2] = 0;
        byteString(name, viewporttrack+i);
        mvprintw(3, xoff + 7, name, ptrnwin);
        int j;
        for(j = 0; j < visiblerows; j++)
        {
            //std::cerr << "   neato0:" << int(selptrn->numRows());
            unsigned int entry = selptrn->at(viewporttrack+i,viewportrow+j);
            //std::cerr << "   neato1\n";
            if(entry == R_EMPTY)
            {
                setPatternAttribs(viewporttrack+i,viewportrow+j, TRKSEG_NOTE);
                mvprintw(4+j, xoff, "|   ",ptrnwin);
                setPatternAttribs(viewporttrack+i,viewportrow+j, TRKSEG_INST);
                mvprintw(4+j, xoff + 4, "   ", ptrnwin);
                setPatternAttribs(viewporttrack+i,viewportrow+j, TRKSEG_VOL);
                mvprintw(4+j, xoff + 7, "   ", ptrnwin);
                setPatternAttribs(viewporttrack+i,viewportrow+j, TRKSEG_FX);
                mvprintw(4+j, xoff + 10, "  ", ptrnwin);
                setPatternAttribs(viewporttrack+i,viewportrow+j, TRKSEG_FXP);
                mvprintw(4+j, xoff + 12, "  |", ptrnwin);
            }
            else
            {
                //print note!
                setPatternAttribs(viewporttrack+i,viewportrow+j, TRKSEG_NOTE);
                noteString(name+1, entry);
                name[0] = '|';
                name[4] = 0;
                mvprintw(4+j, xoff, name, ptrnwin);

                //print instrument
                setPatternAttribs(viewporttrack+i,viewportrow+j, TRKSEG_INST);
                name[0] = ' ';
                instString(name+1, entry);
                mvprintw(4+j, xoff + 4, name, ptrnwin);


                setPatternAttribs(viewporttrack+i,viewportrow+j, TRKSEG_VOL);
                //print volume
                volString(name+1, entry);
                mvprintw(4+j, xoff + 7, name, ptrnwin);


                setPatternAttribs(viewporttrack+i,viewportrow+j, TRKSEG_FX);
                name[2] = 0;
                fxString(name+1, entry);
                mvprintw(4+j, xoff + 10, name, ptrnwin);

                setPatternAttribs(viewporttrack+i,viewportrow+j, TRKSEG_FXP);
                name[2] = '|';
                name[3] = 0;
                fxpString(name, entry);
                mvprintw(4+j, xoff + 12, name, ptrnwin);       
            }
        }

        attroff(-1);
        while(j < viewportrow+h - 1)
        {
            mvprintw(4+j, xoff, "|             |",ptrnwin);
            j++;
        }
    }



    {//Print Spacer

        unsigned char xoff; 
        if(song->numTracks() < maxtracksviewport)
            xoff = 3+TRACK_WIDTH*song->numTracks()-1;
        else
            xoff = 3+TRACK_WIDTH*maxtracksviewport-1;

        int spacerwidth = w - xoff;
        char *spacebuffer = new char[spacerwidth+1];
        makeSpaceBuffer(spacebuffer, spacerwidth);
        attroff(-1);
        attron(COLOR_PAIR(COL_PTRN_UU));

        
        for(int j = 0; j < h; j++)
            mvprintw(4+j, xoff, spacebuffer, ptrnwin);


        for(int j = 0; j < spacerwidth; j++)
            if(spacebuffer[j] == ' ')
                spacebuffer[j] = '_';
        mvprintw(3,xoff, spacebuffer, ptrnwin);

        delete [] spacebuffer;
    }//End Print Spacer
}

void patternedtr::display()
{
    using namespace editor;

    displayPattern();
    
    instedtr::displayWav();
    
    //print meta after pattern so that meta tooltipts overlap pattern
    displayMeta();
    attroff(-1);

}

bool alphanumeric(int c)
{
    return(c >='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9');
}

void patternedtr::processPatternInput(int in)
{
    switch(in)
    {
        case KEY_UP:
            chgSelRow(-1);
            break;
        case KEY_DOWN:
            chgSelRow(1);
            break;
        case KEY_LEFT:
            chgSelRowSeg(-1);
            break;
        case KEY_RIGHT:
            chgSelRowSeg(1);
            break;
        case KEY_PPAGE:
            chgSelRow(-8);
            break;
        case KEY_NPAGE:
            chgSelRow(8);
            break;
        case KEY_HOME:
            chgSelTrack(-1);
            break;
        case KEY_END:
            chgSelTrack(1);
            break;
        case KEY_SHOME:
            chgSelTrack(-seltrack);
            //doesnt seem to work
            break;
        case KEY_SEND:
            chgSelTrack(editor::song->numTracks() - seltrack - 1);
            //doesnt seem to work
            break;
        case '\n':
            {
                patternedtr::entryclipboard = selptrn->at(seltrack, selrow);
                unsigned char inst = (patternedtr::entryclipboard & R_INSTRUMENT) >> RI_INSTRUMENT;
                if(inst < editor::song->numInstruments())
                {
                    patternedtr::selinstrument = inst;
                    editor::selinst   = editor::song->getInstrument(patternedtr::selinstrument);
                    instedtr::selwavrow = editor::selinst->getWaveIndex(); 
                }
            }
            break;
        case ' ':
            //TODO: might want to replace with some sort of KEY OFF
            selptrn->setAt(seltrack, selrow, patternedtr::entryclipboard);
            break;
        case '!':
            octave = 0;
            break;
        case '@':
            octave = 1;
            break;
        case '#':
            octave = 2;
            break;
        case '$':
            octave = 3;
            break;
        case '%':
            octave = 4;
            break;
        case '^':
            octave = 5;
            break;
        case '&':
            octave = 6;
            break;
        case '*':
            octave = 7;
            break;

        case ':'://Decrement Order
            patternedtr::chgSelOrder(-1);
            break;
        case '"'://Increment Order
            patternedtr::chgSelOrder(1);
            break;
        case '>'://Decrement Pattern
            patternedtr::chgOrderPattern(-1);
            break;
        case '?'://Increment Pattern
            patternedtr::chgOrderPattern(1);
            break;
        default:

            bool v = editor::validateHexChar(in);
            bool resolved = false;
            unsigned char val;
            switch(seltrackseg)
            {
                case TRKSEG_NOTE:
                    {
                        try
                        {
                            unsigned int note = notemap.at(in);
                            unsigned int entry = selptrn->at(seltrack, selrow);
                            //if((entry & R_INSTRUMENT) == R_INSTRUMENT)
                            if(entry == R_EMPTY)
                            {
                                //If it was an empty note, set to
                                //selected instrument
                                entry &= ~R_INSTRUMENT;
                                entry |= selinstrument << RI_INSTRUMENT;
                            }
                            entry &= ~(R_PITCHSEG);
                            entry += note;
                            entry += patternedtr::octave << RI_OCTAVE;
                            selptrn->setAt(seltrack,selrow,entry);
                            resolved=true;
                            chgSelRow(patternedtr::edit_step);
                        }
                        catch(std::out_of_range &o) //notemap.at causes this if not found
                        {
                            if(in == KEY_DC)
                            {
                                unsigned int entry = selptrn->at(seltrack, selrow);
                                if((entry & R_INSTRUMENT) != R_INSTRUMENT)
                                    entry = R_EMPTY;
                                else
                                    entry |= R_FULLSEG;
                                selptrn->setAt(seltrack,selrow,entry);
                                chgSelRow(patternedtr::edit_step);

                                resolved = true;
                            }
                        }

                    }
                    break;
                case TRKSEG_INST:
                    if(v)
                    {
                        unsigned int entry = selptrn->at(seltrack, selrow);
                        unsigned char inst = (entry & R_INSTRUMENT) >> RI_INSTRUMENT;
                        val = editor::charHex(in);
                        entry &= ~R_INSTRUMENT;
                        inst *= 0x10;

                        if(inst >= editor::song->numInstruments())
                            inst = 0;

                        inst |= val;

                        if(inst >= editor::song->numInstruments())
                            inst = editor::song->numInstruments()-1;

                        entry |= inst << RI_INSTRUMENT;
                        selptrn->setAt(seltrack,selrow,entry);
                        resolved=true;

                    }
                    else
                    {
                        if(in == KEY_DC)//DELETE
                        {
                            unsigned int entry = selptrn->at(seltrack, selrow);
                            entry |= R_INSTRUMENT;
                            selptrn->setAt(seltrack,selrow,entry);
                            resolved = true;
                        }

                    }
                    break;
                case TRKSEG_VOL:
                    if(v)
                    {
                        unsigned int entry = selptrn->at(seltrack, selrow);
                        unsigned char vol;
                        if((entry & R_EMPTY) == R_EMPTY)
                            vol = 0;
                        else
                            vol = (entry & R_VOLUME) >> RI_VOLUME;
                        val = editor::charHex(in);
                        entry &= ~R_VOLUME;
                        vol *= 0x10;
                        if(vol>=0x40)
                            vol = 0x30;
                        vol |= val;
                        entry |= vol << RI_VOLUME;
                        selptrn->setAt(seltrack,selrow,entry);
                        resolved=true;
                    }
                    else
                    {
                        if(in == KEY_DC)//DELETE
                        {
                            unsigned int entry = selptrn->at(seltrack, selrow);
                            entry = R_EMPTY;
                            selptrn->setAt(seltrack,selrow,entry);
                            resolved = true;
                        }

                    }
                    break;
                case TRKSEG_FX:
                    if(v)
                    {
                        unsigned int entry = selptrn->at(seltrack, selrow);
                        val = editor::charHex(in);
                        entry &= ~R_EFFECT;
                        entry |= val << RI_EFFECT;
                        selptrn->setAt(seltrack,selrow,entry);
                        resolved=true;
                    }
                    else
                    {
                        if(in == KEY_DC) //DELETE
                        {
                            unsigned int entry = selptrn->at(seltrack, selrow);
                            val = editor::charHex(in);
                            entry &= ~(R_EFFECT | R_FXPARAM);
                            selptrn->setAt(seltrack,selrow,entry);
                            resolved = true;
                        }

                    }
                    break;
                case TRKSEG_FXP:
                    if(v)
                    {
                        unsigned int entry = selptrn->at(seltrack, selrow);
                        unsigned char  fxp = entry & (R_FXPARAM);
                        val = editor::charHex(in);
                        entry &= ~R_FXPARAM;
                        fxp *= 0x10;
                        fxp |= val;
                        entry |= fxp;
                        selptrn->setAt(seltrack,selrow,entry);
                        resolved=true;
                    }
                    else
                    {
                        if(in == KEY_DC)//DELETE
                        {
                            unsigned int entry = selptrn->at(seltrack, selrow);
                            val = editor::charHex(in);
                            entry &= ~R_FXPARAM;
                            selptrn->setAt(seltrack,selrow,entry);
                            resolved = true;
                        }
                    }
                    break;
            }
            break;
    }

}


void patternedtr::processInput(int in)
{

    if(editor::inputwin == editor::metawin)
        processMetaInput(in);    
    else if(editor::inputwin == editor::ptrnwin)
        processPatternInput(in);
    else if(editor::inputwin == editor::wavewin)
        instedtr::processInputWav(in);

}

