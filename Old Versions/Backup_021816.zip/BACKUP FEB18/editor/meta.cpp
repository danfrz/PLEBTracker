#include "patternedtr.h"

#include <iostream>

void patternedtr::chgSelMetaObj(int i)
{
    selobjmeta += i;
    switch(selrowmeta)
    {
        case 0://First row [N S O NAME TRACKS ROWS RES/DIV ? X]
            if(selobjmeta > 9)
                if(i>0)
                    selobjmeta = 9;
                else
                    selobjmeta=0;
            break;
        case 1://Second row [INSTR N C X SEL STEP OCT]
            if(selobjmeta > 6)
                if(i>0)
                    selobjmeta = 6;
                else
                    selobjmeta = 0;
            break;
        case 2: //Third row [ORDER PATTERN v ^ N C X v ^ N C Q X] ...orders...
            if(selobjmeta > 12 + editor::song->numOrders())
                if(i > 0)
                    selobjmeta = 12 + editor::song->numOrders();
                else
                    selobjmeta = 0;
            break;
    }
}

void patternedtr::chgSelMetaRow(int i)
{
    selrowmeta += i;
    if(selrowmeta > 2)
        if(i > 0)
            selrowmeta = 2;
        else
            selrowmeta = 0;
    else
    {
        if(selrowmeta == 0)
            selobjmeta = 1;
        else if(selrowmeta == 1)
            selobjmeta = 4;
        else if(selrowmeta == 2)
            selobjmeta = 0;
    }
}

bool patternedtr::setMetaAttribs(unsigned char objmeta, unsigned char rowmeta)
{
    attroff(-1);
    using namespace patternedtr;
    if(editor::inputwin == editor::metawin)
    {
        attron(A_BOLD);
        if(objmeta == selobjmeta && rowmeta == selrowmeta)
        {
            if(metaobjedit)
                attron(COLOR_PAIR(COL_META_SSSE));
            else
                attron(COLOR_PAIR(COL_META_SSS));
            return true;
        }
        else
            attron(COLOR_PAIR(COL_META_SU));
    }
    else
    {
        if(objmeta == selobjmeta && rowmeta == selrowmeta)
            attron(COLOR_PAIR(COL_META_US));
        else
            attron(COLOR_PAIR(COL_META_UU));
    }
    return false;
}



char *editor::makeUnderlines(char *string, int length)
{
    for(int i = 0; i < length; i++)
    {
        if(string[i] == 0)
            string[i] = '_';
    }
    return string;
}



void patternedtr::displayMeta()
{
    using namespace editor;
    const bool WINCHANGE = lastwin != metawin;
    if(WINCHANGE)
    {
        lastwin = metawin;
        //using a buffer will be far more efficient than setting each individual cell
        //and for some reason im adversed to using dynamic memory here so yeah
        int div = editor::WIN_WIDTH / 12;
        int rem = editor::WIN_WIDTH % 12;
        char bfr[12];

        //CLEAR THE META WINDOW to clean up potential artifacts/////
        //clear the majority of the meta region
        int i;
        for(i = 0; i < div; i++)
            for(int j = 0; j < 3; j++)
                mvprintw(j,12*i, "            ", editor::metawin);//12 spaces

        //fill buffer to size of remainder
        for(i = 0; i < rem; i++)
            bfr[i] = ' ';
        bfr[i] = 0;

        //fill in remaining spaces
        for(i = 0; i < 3; i++)
            mvprintw(i, editor::WIN_WIDTH-(rem), bfr, editor::metawin);
        //DONE CLEARING///////////////////////////////////////////

    }

    bool isselected;
    //Disable attributes
    attroff(-1);

    //Print Top Bar
    //Row 0
    mvprintw(0, 0, "[NSO] ", metawin);
    mvprintw(0, 35, " TRACKS:", metawin);
    mvprintw(0, 46, " ROWS:", metawin);
    mvprintw(0, 55, " BPR/DIV:____/__", metawin);
    mvprintw(0, 72, "   [? X]", metawin);

    setMetaAttribs(0,0);
    mvprintw(0,1,"N",metawin);
    setMetaAttribs(1,0);
    mvprintw(0,2,"S",metawin);
    setMetaAttribs(2,0);
    mvprintw(0,3,"0",metawin);



    
    isselected = setMetaAttribs(3, 0);
    if(isselected && metaobjedit)
    {
        copy(charInputBuffer, charBuffer, 29);
        makeUnderlines(charBuffer, 29);
        mvprintw(0, 6, charBuffer, metawin);
        attron(COLOR_PAIR(COL_META_UU));
        char sel[2];
        sel[0] = charBuffer[textCursorPos];
        sel[1] = 0;
        mvprintw(0, 6 + textCursorPos, sel, metawin);
    }
    else
    {
        charBuffer[29]=0;
        copy(editor::song->getName(), charBuffer, 29);
        makeUnderlines(charBuffer, 29);
        mvprintw(0, 6, charBuffer, metawin);
    }

    //TRACKS
    charBuffer[2] = 0;
    isselected = setMetaAttribs(4, 0);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, editor::song->numTracks());
    mvprintw(0, 43, charBuffer, metawin);

    //ROWS
    isselected = setMetaAttribs(5, 0);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, patternedtr::selptrn->numRows());
    mvprintw(0, 52, charBuffer, metawin);

    //RESOLUTION
    charBuffer[4] = 0;
    isselected = setMetaAttribs(6, 0);
    if(isselected && metaobjedit)
        shortString(charBuffer, numBuffer, 4);
    else
        shortString(charBuffer, editor::song->getBytesPerRow(), 4);

    if(!metaobjedit && (editor::song->getBytesPerRow() % editor::song->getInterRowResolution()) > 0)
    {
        if(isselected)
            attron(COLOR_PAIR(COL_META_SSS_ERR));
        else
            attron(COLOR_PAIR(COL_META_ERR));
    }
    mvprintw(0, 64, charBuffer, metawin);

    //DIV
    charBuffer[2] = 0;
    isselected = setMetaAttribs(7,0);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
    {
        
        byteString(charBuffer, editor::song->getInterRowResolution());
    }

    if(!metaobjedit && (editor::song->getBytesPerRow() % editor::song->getInterRowResolution()) > 0)
    {
        if(isselected)
            attron(COLOR_PAIR(patternedtr::COL_META_SSS_ERR));
        else
            attron(COLOR_PAIR(patternedtr::COL_META_ERR));
    }

    mvprintw(0, 69, charBuffer, metawin);


    setMetaAttribs(8,0);
    mvprintw(0,76,"?",metawin);
    setMetaAttribs(9,0);
    mvprintw(0,78,"X",metawin);

    //ROW 1
    //INSTRUMENT
    attroff(-1);
    mvprintw(1, 0, "INSTR ", metawin);
    mvprintw(1, 29, " [NCX] ", metawin);
    //print order //two char hex
    mvprintw(1, 38," STEP:", metawin);
    mvprintw(1, 45, "  OCT :", metawin);
    //print octave //one char hex

    isselected = setMetaAttribs(0, 1);
    copy(editor::selinst->getName(), charBuffer, 23);
    charBuffer[22] = 0;
    mvprintw(1, 6, makeUnderlines(charBuffer,22), metawin); 

    charBuffer[2] = 0;
    isselected = setMetaAttribs(4, 1);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, patternedtr::selinstrument);
    mvprintw(1, 36, charBuffer);

    setMetaAttribs(1,1);
    mvprintw(1,31,"N",metawin);
    setMetaAttribs(2,1);
    mvprintw(1,32,"C",metawin);
    setMetaAttribs(3,1);
    mvprintw(1,33,"X",metawin);


    isselected = setMetaAttribs(5, 1);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, patternedtr::edit_step);
    mvprintw(1, 44, charBuffer+1);

    isselected = setMetaAttribs(6, 1);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        editor::byteString(charBuffer, patternedtr::octave);
    mvprintw(1, 52, charBuffer+1);

    //Row 2
    attroff(-1);
    mvprintw(2, 0, "ORDER [  -  ] [v^ NCX v^ NCWX] -- ", metawin);
    //print cur order and pattern 2 char hex

    //ORDER
    isselected = setMetaAttribs(0,2);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, patternedtr::selorder);
    mvprintw(2,7, charBuffer, metawin);

    //Pattern
    isselected = setMetaAttribs(1,2);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, song->getPatternIndexByOrder(selorder));
    mvprintw(2,10, charBuffer, metawin);

    setMetaAttribs(2,2);
    mvprintw(2,15,"v",metawin);
    setMetaAttribs(3,2);
    mvprintw(2,16,"^",metawin);
    setMetaAttribs(4,2);
    mvprintw(2,18,"N",metawin);
    setMetaAttribs(5,2);
    mvprintw(2,19,"C",metawin);
    setMetaAttribs(6,2);
    mvprintw(2,20,"X",metawin);


    setMetaAttribs(7,2);
    mvprintw(2,22,"v",metawin);
    setMetaAttribs(8,2);
    mvprintw(2,23,"^",metawin);
    setMetaAttribs(9,2);
    mvprintw(2,25,"N",metawin);
    setMetaAttribs(10,2);
    mvprintw(2,26,"C",metawin);
    setMetaAttribs(11,2);
    mvprintw(2,27,"Q",metawin);
    setMetaAttribs(12,2);
    mvprintw(2,28,"X",metawin);

}
void patternedtr::startMetaEditing()
{

    bool confirmation;
    ///////////////////////
    /////////    BUTTONS///
    ///////////////////////
    if(selrowmeta == 0)
    {
        switch(selobjmeta)
        {
            case 0:
                //New Song ||Button [0,0]

                confirmation = editor::confirm("This will delete any unsaved data");
                if(confirmation)
                    newSong();
                return;
            case 1:
                //Save Song ||Button [0,1]

                confirmation = editor::confirm("Save?");
                if(confirmation)
                {
                    const char *file = browse();
                    if(file)
                        saveSong(file);
                }

                return;
            case 2:
                //Open Song ||Button [0,2]

                confirmation = editor::confirm("Open? Any unsaved data will be lost");
                if(confirmation)
                {
                    const char *file = browse();
                    if(file)
                        openSong(file);
                }
                return;
            case 8:
                //About ||Button [0,7]
                editor::displayAbout();
                return;
            case 9:
                //Exit ||Button [0,8]
                patternedtr::exit();
                return;
        }
    }
    else if(selrowmeta == 1)
    {
        switch(selobjmeta)
        {
            case 0:
                //Instrument Edit ||Big Button [1,0]
                editor::inputwin = editor::instwin;
                editor::wingroup = editor::instwin;
                return;
            case 1:
                //New Instrument ||Button [1,1]
               newInstrument();
                return;
            case 2:
                //Clone Instrument ||Button [1,2]
               cloneInstrument();
                return;
            case 3:
                //Remove Instrument ||Button [1,3]
                removeInstrument();                
                return;
        }
    }
    else if(selrowmeta == 2)
    {
        switch(selobjmeta)
        {
            case 2:
                //DOWN Order ||Button
               chgSelOrder(-1);
                return;
            case 3:
                //UP Order ||Button
                chgSelOrder(1);
                return;
            case 4:
                //New Order ||Button
                //Create a new order with a new pattern
               newOrder(); 
                return;
            case 5:
                //Clone Order ||Button
               cloneOrder();
                return;
            case 6:
                //Remove Order ||Button
               removeOrder();
                return;
            case 7:
                //DOWN Pattern ||Button [2,2]
                chgOrderPattern(-1);
                return;
            case 8:
                //UP Pattern ||Button [2,3]
                chgOrderPattern(1);
                return;
            case 9:
                //New Pattern ||Button [2,4]
                newPattern();
                return;
            case 10:
                //Clone Pattern ||Button [2,5]
               clonePattern();
                return;
            case 11:
                //Clear Pattern ||Button [2,6]
                clearPattern();
                return;
            case 12:
                //Remove Pattern ||Button [2,7]
               removePattern(); 
                return;
        }
    }

    ///////////////////////
    /////////  EDITABLES///
    ///////////////////////
    if(selrowmeta == 0)
    {
        if(selobjmeta ==3)
        {
            editor::copy(editor::song->getName(), editor::charInputBuffer, 29);

            editor::textCursorPos = strlen(editor::song->getName());

            metaobjedit = true;
        }
        else if(selobjmeta == 4)
        {
            editor::numBuffer = 0;
            metaobjedit = true;
        }
        else if(selobjmeta == 5)
        {
            editor::numBuffer = 0;
            metaobjedit = true;
        }
        else if(selobjmeta == 6)
        {
            editor::numBuffer = editor::song->getBytesPerRow();
            metaobjedit = true;
        }
        else if(selobjmeta == 7)
        {
            editor::numBuffer = editor::song->getInterRowResolution();
            metaobjedit = true;
        }
    }
    else	if(selrowmeta == 1) 
    {
        if(selobjmeta == 4)//INST SPINNER
        {
            editor::numBuffer = selinstrument;
            metaobjedit = true;
        }
        else if(selobjmeta == 5)
        {
            editor::numBuffer = edit_step;
            metaobjedit = true;
        }
        else if(selobjmeta == 6)
        {
            editor::numBuffer = octave;
            metaobjedit = true;
        }

    }
    else if(selrowmeta == 2)
    {
        if(selobjmeta == 0)
        {
            editor::numBuffer = selorder;
            metaobjedit = true;
        }
        else if(selobjmeta == 1)
        {
            editor::numBuffer = editor::song->getPatternIndexByOrder(selorder);
            metaobjedit = true;
        }
    }

}

void patternedtr::metaEdit(int in)
{
    using namespace editor;
    bool ishex = editor::validateHexChar(in);
    bool isarrow = (in == KEY_LEFT||in==KEY_RIGHT||in==KEY_UP||in==KEY_DOWN);
    bool spinnervalid = ishex || isarrow;
    char hexnum = charHex(in);

    if(selrowmeta == 0)
    {
        switch(selobjmeta)
        {
            case 3:
                //Name ||Textbox [0,3]
                if(isarrow)
                {
                    if(in == KEY_LEFT)
                    {
                        if(textCursorPos > 0)
                            textCursorPos--;
                    }
                    else if(in == KEY_RIGHT)
                    {
                        if(textCursorPos < strlen(charInputBuffer))
                            textCursorPos++;
                    }
                }
                else if(in == KEY_DC)
                {
                    int length = strlen(charInputBuffer);
                    for(int i = textCursorPos+1; i < length; i++)
                        charInputBuffer[i-1] = charInputBuffer[i];
                    charInputBuffer[length-1] = 0;
                    if(textCursorPos >= length && length > 0)
                        textCursorPos--;

                }
                else if(in == KEY_IC)
                {
                    int length = strlen(charInputBuffer);
                    for(int i = length; i > textCursorPos; i--)
                        charInputBuffer[i] = charInputBuffer[i-1];
                    charInputBuffer[length+1] = 0;
                    charInputBuffer[textCursorPos] = ' ';

                }
                else if(in == KEY_HOME)
                    textCursorPos = 0;
                else if(in == KEY_END)
                    textCursorPos = strlen(charInputBuffer);
                else
                {
                    if(in <= 'z' && in >= ' ')
                    {
                        charInputBuffer[textCursorPos] = in;
                        if(textCursorPos < strlen(charInputBuffer))
                            textCursorPos++;
                    }
                }

                break;
            case 4:
            case 5:
                //Tracks ||Spinner [0,4]
                //Rows ||Spinner [0,5]
                if(!spinnervalid) return;
                switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_LEFT:
                        numBuffer -= 0x10;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_RIGHT:
                        numBuffer += 0x10;
                        break;
                    case KEY_END:
                        numBuffer = 1;
                        break;
                    case KEY_HOME:
                        numBuffer = 255;
                        break;
                    case KEY_DC:
                        numBuffer /= 0x10;
                        break;
                    default:
                        if(ishex)
                        {
                            numBuffer *= 0x10;
                            numBuffer += hexnum;
                            numBuffer &= 0xFF;
                        }
                }
                if(numBuffer > 255)
                    numBuffer = 0xFF;
                 

                break;
            case 6:
                //Resolution ||UInt Spinner [0,6]
                if(!spinnervalid) return;

                switch(in)
                {
                    case KEY_UP:
                        numBuffer += 0x10*editor::song->getInterRowResolution();
                        numBuffer = (numBuffer/editor::song->getInterRowResolution())* editor::song->getInterRowResolution();
                        break;
                    case KEY_LEFT:
                        numBuffer -= 0x100*editor::song->getInterRowResolution();
                        numBuffer = (numBuffer/editor::song->getInterRowResolution())* editor::song->getInterRowResolution();
                        break;
                    case KEY_DOWN:
                        numBuffer -= 0x10*editor::song->getInterRowResolution();
                        numBuffer = (numBuffer/editor::song->getInterRowResolution())* editor::song->getInterRowResolution();
                        break;
                    case KEY_RIGHT:
                        numBuffer += editor::song->getInterRowResolution()*0x100;
                        numBuffer = (numBuffer/editor::song->getInterRowResolution())* editor::song->getInterRowResolution();
                        break;
                    case KEY_END:
                        numBuffer = song->getInterRowResolution()*0x10;
                        break;
                    case KEY_HOME:
                        numBuffer = 0xFFFFF;
                        break;
                    case KEY_DC:
                        numBuffer = 0;
                        break;
                    default:
                        if(ishex)
                        {
                            numBuffer *= 0x10;
                            numBuffer += hexnum;
                        }
                }
                if(numBuffer > 0xFFFF)
                    numBuffer &= 0xFFFF;
                else if(numBuffer < 0)
                    numBuffer = 0;
                break;
            case 7:
                //DIV  ||Spinner [0,7]
                if(!spinnervalid) return;
                switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_LEFT:
                        numBuffer -= 0x10;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_RIGHT:
                        numBuffer += 0x10;
                        break;
                    case KEY_END:
                        numBuffer = 1;
                        break;
                    case KEY_HOME:
                        numBuffer = 255;
                        break;
                    case KEY_DC:
                        numBuffer /= 0x10;
                        break;
                    default:
                        if(ishex)
                        {
                            numBuffer *= 0x10;
                            numBuffer += hexnum;
                            numBuffer &= 0xFF;
                        }
                }
                if(numBuffer > 255)
                    numBuffer = 0xFF;
                break;
                 
        }
    }
    else if(selrowmeta == 1)
    {
        if(!spinnervalid) return;
        switch(selobjmeta)
        {
            case 4:
                //Instrument ||Spinner [1,4]

                switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_LEFT:
                        numBuffer -= 8;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_RIGHT:
                        numBuffer += 8;
                        break;
                    case KEY_END:
                        numBuffer = 0;
                        break;
                    case KEY_HOME:
                        numBuffer = song->numInstruments()-1;
                        break;
                    case KEY_DC:
                        numBuffer /= 0x10;
                        break;
                    default:
                        if(ishex)
                        {
                            numBuffer *= 0x10;

                            if(numBuffer > song->numInstruments())
                                numBuffer = 0;

                            numBuffer += hexnum;

                            if(numBuffer >= song->numInstruments())
                                numBuffer = song->numInstruments()-1;

                            numBuffer &= 0xFF;
                        }
                        
                }
                
                break;
            case 5:
                //Step ||Spinner [1,5]

                switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_END:
                        numBuffer = 0;
                        break;
                    case KEY_HOME:
                        numBuffer = 0xF;
                        break;
                    default:
                        if(ishex)
                            numBuffer = hexnum;
                }
                if(numBuffer >= 0xF)
                    numBuffer = 0xF;
                else if(numBuffer < 0)
                    numBuffer = 0;
                break;
            case 6:
                //Octave ||Spinner [1,6]
               
                switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_END:
                        numBuffer = 0;
                        break;
                    case KEY_HOME:
                        numBuffer = 6;
                        break;
                    default:
                        if(ishex)
                            numBuffer = hexnum;
                }
                if(numBuffer >= 7)
                    numBuffer = 6;
                else if(numBuffer < 0)
                    numBuffer = 0;
                break;
        }

    }
    else if(selrowmeta == 2)
    {
        if(!spinnervalid) return;
        switch(selobjmeta)
        {
            case 0:
            case 1:
                //Order Selected ||Spinner [2,0]
                //Pattern Selected ||Spinner [2,1]
            switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_LEFT:
                        numBuffer -= 0x10;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_RIGHT:
                        numBuffer += 0x10;
                        break;
                    case KEY_END:
                        numBuffer = 0;
                        break;
                    case KEY_HOME:
                        numBuffer = 255;
                        break;
                    case KEY_DC:
                        numBuffer /= 0x10;
                        break;
                    default:
                        if(ishex)
                        {
                            numBuffer *= 0x10;
                            numBuffer += hexnum;
                        }
                }
            if(selobjmeta == 0)
            {
                if(numBuffer >= song->numOrders())
                    numBuffer = song->numOrders()-1;
                else if(numBuffer < 0)
                    numBuffer = 0;          
            }
            else if(selobjmeta == 1)
            {
                if(numBuffer >= song->numPatterns())
                    numBuffer = song->numPatterns()-1;
                else if(numBuffer < 0)
                    numBuffer = 0;           
            }

            break;
        }
    }


}

void patternedtr::doneMetaEditing()
{
    using namespace editor;
    if(selrowmeta == 0)
    {
        switch(selobjmeta)
        {
            case 3:
                copy(charInputBuffer, song->getName(), 29);
                break;
            case 4:
                if(numBuffer < 1)
                    numBuffer = 1;
                song->setTrackNum(numBuffer);
                patternedtr::viewporttrack=0;
                break;
            case 5:
                if(numBuffer < 1)
                    numBuffer = 1;
                selptrn->setRowNum(numBuffer);
                patternedtr::viewportrow=0;
                patternedtr::selrow=0;
                break;
            case 6:
                if(numBuffer < 16)
                    numBuffer = 16;//who in the right mind would decrease the resolution any further?
                song->setBytesPerRow(numBuffer);
                break;
            case 7:
                if(numBuffer < 1)
                    numBuffer = 1;
                song->setInterRowResolution(numBuffer);
                break;
        }
    }
    else if(selrowmeta == 1)
    {
        switch(selobjmeta)
        {
            case 4:
                if(numBuffer >= song->numInstruments())
                    numBuffer = song->numInstruments()-1;
                else if(numBuffer < 0)
                    numBuffer = 0;
                selinstrument = numBuffer;
                selinst = song->getInstrument(selinstrument);
                break;
            case 5:
                edit_step = numBuffer;
                break;
            case 6:
                octave = numBuffer;
                break;

        }
    }
    else if(selrowmeta == 2)
    {
        switch(selobjmeta)
        {
            case 0:
                selorder = numBuffer;
                selptrn = song->getPatternByOrder(selorder);
                break;
            case 1:
                song->setPatternIndexByOrder(selorder, numBuffer);
                selptrn = song->getPattern(numBuffer);
                break;
        }
    }
    metaobjedit = false;
}


void patternedtr::processMetaInput(int in)
{
    bool ishex = editor::validateHexChar(in);

    if(!metaobjedit)
    {
        bool hexnum;
        switch(in)
        {
            case KEY_UP:
                chgSelMetaRow(-1);
                break;
            case KEY_DOWN:
                chgSelMetaRow(1);
                break;
            case KEY_LEFT:
                chgSelMetaObj(-1);
                break;
            case KEY_RIGHT:
                chgSelMetaObj(1);
                break;
            case KEY_HOME:
                chgSelMetaObj(-20);
                break;
            case KEY_END:
                chgSelMetaObj(20);
                break;
            case '\n':
                startMetaEditing();
                break;
            case KEY_NPAGE:
                editor::inputwin = editor::ptrnwin;
                editor::wingroup = editor::ptrnwin;
                break;
            default:
                ishex =  editor::validateHexChar(in);
                if(ishex)
                {
                    if( selrowmeta == 0 && selobjmeta == 6 ||
                            selrowmeta == 1 && (selobjmeta == 4 || selobjmeta == 5 || selobjmeta == 6) ||
                            selrowmeta == 2 && (selobjmeta == 0 || selobjmeta == 1)
                      )
                        metaEdit(in);
                }

        }
    }
    else
    {
        if(in == '\n')
            doneMetaEditing();
        else
            metaEdit(in);

    }



}





void patternedtr::newSong()
{
    delete editor::song;
    editor::selinst = NULL;

    patternedtr::viewporttrack = 0;
    patternedtr::viewportrow = 0;
    patternedtr::seltrack = 0;
    patternedtr::selrow = 0;

    patternedtr::selorder = 0;

    instedtr::selwavrow = 0;

    editor::song = new Song();
    patternedtr::selinstrument = 0;
    editor::selinst = editor::song->getInstrument(0);
    patternedtr::selptrn = editor::song->getPatternByOrder(0);

}

bool patternedtr::saveSong(const char *file)
{
    std::ofstream fileout(file);
    if(!fileout)
        return false;
    editor::song->output(fileout);
    fileout.close();
    return true;
}

const char *patternedtr::browse()
{
    return "song.plb";

}

bool patternedtr::openSong(const char *file)
{
    std::ifstream filein(file);
    if(!filein)
        return false;
    if(editor::song == NULL)
        editor::song = new Song(filein);
    else
        editor::song->input(filein);
    filein.close();

    selorder = 0;
    viewporttrack=0;
    viewportrow=0;
    selrow = 0;
    seltrack=0;
    selinstrument=0;
    editor::selinst = editor::song->getInstrument(0);
    instedtr::selwavrow=0;
    instedtr::viewportwave = 0;
    instedtr::selvolrow=0;
    instedtr::viewportvol = 0;

    selptrn = editor::song->getPatternByOrder(selorder);
    return true;
}

void patternedtr::newInstrument()
{
    bool success = editor::song->newInstrument();
    if(success)
    {
        selinstrument = editor::song->numInstruments()-1;
        editor::selinst = editor::song->getInstrument(selinstrument);
    }
    else editor::inform("New Instrument failed, too many Instruments");
}
void patternedtr::cloneInstrument()
{
    bool success = editor::song->cloneInstrument(patternedtr::selinstrument);
    if(success)
    {
        selinstrument = editor::song->numInstruments()-1;
        editor::selinst = editor::song->getInstrument(selinstrument);
    }
    else editor::inform("Clone Instrument failed, too many Instruments");

}
void patternedtr::removeInstrument()
{
    using namespace editor;
    bool success = editor::song->removeInstrument(patternedtr::selinstrument);
    if(success)
        selinstrument--;
    else
        editor::inform("Can't Remove the last Instrument               ");
    if(selinstrument > song->numInstruments())
        selinstrument = 0;
    selinst = song->getInstrument(selinstrument);
    //TODO make sure instrument set to valid inst
}
void patternedtr::chgSelOrder(int i) 
{
    using namespace editor;
    selorder += i;
    if(selorder >= song->numOrders())
    {
        if(i > 0)
            selorder = song->numOrders()-1;
        else
            selorder = 0;
    }
    selptrn = editor::song->getPattern(editor::song->getPatternIndexByOrder(selorder));
}

void patternedtr::newOrder() 
{
    using namespace editor;
    if(selorder < 255)
    {//TODO make error messages if cant make pattern etc.
        bool success = editor::song->newPattern();
        if (success)
        {
            editor::song->insertOrder(selorder+1, editor::song->numPatterns()-1);
            selorder++;
            selptrn = editor::song->getPattern(editor::song->getPatternIndexByOrder(selorder));

        }
        else
            editor::inform("Too many Patterns to make a new Pattern for the New Order");
    }
    else editor::inform("Too many orders, can't make New Order             ");
}

void patternedtr::cloneOrder() 
{
    using namespace editor;
    bool success = editor::song->insertOrder(selorder+1, editor::song->getPatternIndexByOrder(selorder));
    if(success)
    {
        selorder++;
        selptrn = editor::song->getPattern(editor::song->getPatternIndexByOrder(selorder));
    }
    else editor::inform("Failed to Insert a new order                      ");
}

void patternedtr::removeOrder() 
{
    using namespace editor;
    bool success = editor::song->removeOrder(selorder);
    if(success)
    {
        if(selorder >= editor::song->numOrders())
            selorder--;
        selptrn = editor::song->getPattern(editor::song->getPatternIndexByOrder(selorder));
    }
    else editor::inform("Can't Remove the last order                         ");
}

void patternedtr::chgOrderPattern(int i) 
{
    using namespace editor;
    unsigned char sel = editor::song->getPatternIndexByOrder(selorder);
    sel += i;
    if(sel >= editor::song->numPatterns())
        if(i>0)
            sel = editor::song->numPatterns()-1;
        else
            sel = 0;
    editor::song->setPatternIndexByOrder(selorder, sel);
    selptrn = editor::song->getPattern(sel);
}



void patternedtr::newPattern()
{
    using namespace editor;
    bool success = editor::song->newPattern();
    if(success)
    {
        unsigned char newpat = editor::song->numPatterns() - 1;
        editor::song->setPatternIndexByOrder(selorder, newpat);
        selptrn = editor::song->getPattern(newpat);

    }
    else
        editor::inform("New Pattern failed, at maximum");
}
void patternedtr::clonePattern()
{
    using namespace editor;
    bool success = editor::song->clonePattern(editor::song->getPatternIndexByOrder(selorder));
    if(success)
    {
        unsigned char newpat = editor::song->numPatterns() - 1;
        editor::song->setPatternIndexByOrder(selorder, newpat);
        selptrn = editor::song->getPattern(newpat);
    }
    else
        editor::inform("Clone Pattern failed, too many Patterns");
}

void patternedtr::clearPattern()
{
    editor::song->clearPattern(editor::song->getPatternIndexByOrder(selorder));
}

void patternedtr::removePattern()
{
    using namespace editor;
    bool success = editor::song->removePattern(editor::song->getPatternIndexByOrder(selorder));

    if(success)
    {
        //the order changes its patterns to the nearest pattern.
        //update to it:
        selptrn = editor::song->getPatternByOrder(selorder);
    }
    else
        editor::inform("Remove Pattern failed");

}



void patternedtr::clearTrack()
{
    for(int i = 0; i <selptrn->numRows(); i++)
        selptrn->setAt(seltrack, i, R_EMPTY);
}



void patternedtr::exit()
{
    editor::running = false;
}




