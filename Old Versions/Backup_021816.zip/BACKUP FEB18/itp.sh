#!/bin/bash

if [[ ("$#" != 1) ]] ; then
    echo PLEBInterpreter requires at least one parameter
    exit
fi

LOGPATH="/home/sarch/Workspace C/Sound/runlog.log"

/home/sarch/Workspace\ C/Sound/PLEBInterpreter 2>"$LOGPATH" "$@" | aplay --rate=44100 2>"$LOGPATH"


