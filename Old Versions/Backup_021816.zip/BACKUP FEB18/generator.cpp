#include "generator.h"

void genSaw(unsigned char *bfr, unsigned char *ptbl, const float &period, const unsigned char &amplitude, float &phase, const unsigned long &len)
{
    if(period == 0 || amplitude == 0)
        return;

    unsigned char halfamp = amplitude/2;
    float acc = amplitude / period;

    float ovr = phase * amplitude;
    ovr -= halfamp;

    for(unsigned long i = 0; i < len; i++)
    {
        bfr[i] += ovr;
        ovr += acc;
        if(ovr > halfamp)
            ovr = -halfamp;
    }
    ovr += halfamp;
    phase = static_cast<float>(ovr)/amplitude;
}

void genSawPulse(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &amplitude,  float &phase,  const unsigned long &len)
{
    if(period == 0 || amplitude == 0)
        return;

    float halfamp = amplitude/2.0;
    float ratio = 8 - 8*(float)(((unsigned short*)ptbl)[0]) / 0xFFFF;
    float acc = ratio*(amplitude / period);
    //unsigned long lowlen = len - (len % long(period));
    unsigned long increments = std::ceil(period);

    float ovr = phase * amplitude;
    ovr -= halfamp;

    for(long i = 0; i < len; i++)
    {
        bfr[i] += ovr;
        ovr += acc;

        if(ovr > halfamp || i >= increments)
        {
            ovr = -halfamp;
            i = increments;
            increments += std::ceil(period);
        }
    }
    ovr += halfamp;
    phase = static_cast<float>(ovr)/amplitude;

}


void genSqr(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &amplitude, float &phase, const unsigned long &len)
{
    if(period == 0 || amplitude == 0)
        return;

    long offset = phase*period;

    //unsigned long lowlen = len - (len % long(period));
    
    //Offset the length and initial phase by the phase
    const long prd = period;
    long i;
    for(i = 0; i < len; i++)
        bfr[i] += ((((i+offset)%prd) < (period/2))-0.5f)*amplitude;
    phase = ((i+offset)%prd) / period;
}


void genSqrPulse(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &amplitude, float &phase, const unsigned long &len)
{
    if(period == 0 || amplitude == 0)
        return;


    unsigned long offset = phase*period;
    unsigned long lowlen = len;
    const long prd = period;
    float ratio = (float)(((unsigned short*)ptbl)[0]) / 0xFFFF;

    long i;
    for(i = 0; i < lowlen; i++)
    {//every 8 period 
        bfr[i] += ((((i+offset) % prd) < (period*ratio)) - 0.5f)*amplitude;
    }
    phase = ((i+offset)%prd) / period;
}

void genTri(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &amplitude, float &phase, const unsigned long &len)
{
    if(period == 0 || amplitude == 0)
        return;

    unsigned char halfamp = amplitude/2;

    float acc;
    float ovr;

    if(phase >=0)
    {
        ovr = phase*amplitude;
        ovr -= halfamp;
        acc = amplitude / (period/2);
    }
    else
    {
        ovr = phase*amplitude;
        ovr += halfamp;
        acc = -(amplitude / (period/2));
    }


    for(long i = 0; i < len; i++)
    {
        bfr[i] += ovr;
        ovr +=acc;

        if(ovr > halfamp)
        {
            ovr = halfamp;
            acc = -acc;
        }
        else if(ovr < -halfamp)
        {
            ovr = -halfamp;
            acc = -acc;
        }
    }

    //weird piecewise phase maintenance
    //I'm sure if I found a better way to generate a triangle
    //(some sort of absolute value repeating interval or something)
    //this could be easier but this will work
    if(acc > 0)
    {
        ovr += halfamp;
        phase = ovr/amplitude;
    }
    else
    {
        ovr -= halfamp;
        phase = ovr/amplitude;
    }
}


void genTriPulse(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &amplitude, float &phase, const unsigned long &len)
{
    if(period == 0 || amplitude == 0)
        return;

    unsigned long lowlen = len;
    //unsigned long lowlen = len - (len % long(period));
    unsigned char halfamp = amplitude/2;
    int ovr = 0;

    unsigned short param = ((unsigned short*)ptbl)[0];
    float ratio = 4.0 - 3.0*(static_cast<float>(param) / 0xFFFF);
    float halfperiod = (period/2);

    float acc = (amplitude / halfperiod)*ratio;
    unsigned long increments = std::ceil(period);
    bool stage = 0;

    for(unsigned long i = 0; i < lowlen; i++)
    {

        bfr[i] += ovr;
        ovr +=acc;
        
        if(stage && ovr >= 0)
        {
            i = increments;
            increments += std::ceil(period);
            ovr = 0;
            stage = false;
        }
        else if(ovr > halfamp)
        {
            ovr = halfamp;
            acc = -acc;
        }
        else if(ovr < -halfamp)
        {
            ovr = -halfamp;
            acc = -acc;
            stage = true;
        }
    }


}

void genTriPulse_Attempt(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &amplitude, float &phase, const unsigned long &len)
{
    if(period == 0 || amplitude == 0)
        return;

    //unsigned long lowlen = len - (len % long(period));
    unsigned char halfamp = amplitude/2;

    unsigned short param = ((unsigned short*)ptbl)[0];
    float ratio = 4.0 - 3.0*(static_cast<float>(param) / 0xFFFF);
    float halfperiod = (period/2);

    float acc;
    unsigned long increments = std::ceil(period);
    bool stage = 0;
    int ovr;
    unsigned long i;

    if(phase >=0)
    {
        
        acc = (amplitude / halfperiod)*ratio;
        if(phase > 1)
        {
            ovr = 0;
            i = phase - 1;
        }
        else
        {
            ovr = phase*amplitude;
            ovr -= halfamp;
            i = 0;
            if(ovr < 0)
                stage = true;
        }
    }
    else
    {
        ovr = phase*amplitude;
        ovr += halfamp;
        acc = -(amplitude / halfperiod)*ratio;
        i = 0;
    }

    for(; i < len; i++)
    {

        bfr[i] += ovr;
        ovr +=acc;
        
        if(stage && ovr >= 0)
        {
            i = increments;
            increments += std::ceil(period);
            ovr = 0;
            stage = false;
        }
        else if(ovr > halfamp)
        {
            ovr = halfamp;
            acc = -acc;
        }
        else if(ovr < -halfamp)
        {
            ovr = -halfamp;
            acc = -acc;
            stage = true;
        }
    }

    //if i EQUALS len, then i must have naturally incremented to get there
    //if i GREATER than len. then period must > 1, which is very likely
    //   and the pulse should start at +0 
    if(i > len)
    {
        //
        phase = (i - len) + 1;

    }
    else
    {
        if(acc > 0)
        {
            ovr += halfamp;
            phase = ovr/amplitude;
        }
        else
        {
            ovr -= halfamp;
            phase = ovr/amplitude;
        }
    }
}




void genSilence(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &height, float &phase, const unsigned long &len)
{
    return;
}

void genBongo(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &height, float &phase, const unsigned long &len)
{
    if(period == 0 || height == 0)
        return;

    unsigned long lowlen = len;
    //unsigned long lowlen = len - (len % long(period));
    float tau = (2*M_PI);
    float ratio = 14.0 /64.0;
    unsigned long i;
    for(i = 0; i < lowlen; i++)
    {
        float f = std::sin(phase+(tau*i)/period) * std::sin(phase/ratio + (tau*i)/(period*ratio))*0.5;
        bfr[i] += f*height;
        //if(i<128)
        //    bfr[i] += (f*height)/(1);
        //else
        //    bfr[i] += (f*height)/(i/128.0);
    }
    phase = phase + (tau*i)/period;
}

void genSine(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &amplitude, float &phase, const unsigned long &len)
{
    if(period == 0 || amplitude == 0)
        return;

    const float tau = (2*M_PI);
    float halfamp = amplitude/2.0;
    unsigned long i;
    for(i = 0; i < len; i++)
        bfr[i] += halfamp*std::sin(phase + (tau*i)/period);
    phase = phase + (tau*i)/period;
}



void genNoise_White(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &height, float &phase, const unsigned long &len)
{
    if(height == 0)
        return;
    int halfamp = height/2;
    //Note, not actually white noise, for the record
    for(unsigned long i = 0; i < len; i++)
        bfr[i] += (rand() % height) - halfamp;
}


void genNoise_Brown(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &height, float &phase, const unsigned long &len)
{


}

void genNoise_Pink(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &height, float &phase, const unsigned long &len)
{
}

void genNoise_Blue(unsigned char *bfr, unsigned char *ptbl,  const float &period, const unsigned char &height, float &phase, const unsigned long &len)
{

}

