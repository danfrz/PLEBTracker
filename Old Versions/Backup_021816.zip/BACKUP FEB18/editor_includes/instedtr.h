#ifndef INSTEDTR_H_
#define INSTEDTR_H_
#include <ncurses.h>
#include "tables.h"
#include "patternedtr.h"

namespace instedtr
{

/***\//////////////////////////////////////////////////////////////////////////    
Function: void chgSelWavRow(int i)

Description:
    Increases or decreases selected wave row
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void chgSelWavRow(int i);

/***\//////////////////////////////////////////////////////////////////////////    
Function: void chgSelWavSeg(int i)

Description:
    Increases or decreases selected wave segment
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void chgSelWavSeg(int i);

    void chgSelVolRow(int i);
    void chgSelVolSeg(int i);
    void chgSelInstRow(int i);
    void chgSelInstObj(int i);



/***\//////////////////////////////////////////////////////////////////////////    
Function: void display()

Description:
  Render the Instrument Edit screen 
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void display();

/***\//////////////////////////////////////////////////////////////////////////    
Function: void displayWav()

Description:
   Render the Wave Table
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void displayWav();

    void displayInst();
    void displayVol();
    void displayEnvelope();

    bool setInstAttribs(unsigned char instrow, unsigned char instobj);
    void setWaveAttribs(unsigned short waverow, unsigned char waveseg);
    void setVolAttribs(unsigned char volrow, unsigned char volseg);

/***\//////////////////////////////////////////////////////////////////////////    
Function: void processInput(int in)

Description:
  Process NCurses keyboard input for the instrument edit screen
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void processInput(int in);

/***\//////////////////////////////////////////////////////////////////////////    
Function: void processInputWav(int in)

Description:
   Process input for the wave table
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void processInputWav(int in);

    void processInputVol(int in);
    void processInputInst(int in);

    void startInstEditing();
    void instEdit(int in);
    void doneInstEditing();

}


#endif
