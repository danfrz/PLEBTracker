KEY='';
while [[ $KEY == "" ]]; do
    sh itp.sh "$@" ;
    read -n 1 -t 4 KEY
done
