#ifndef SONG_H_
#define SONG_H_

#include "instrument.h"
#include "pattern.h"
#include <istream>
#include <ostream>

bool isJumpFunc(const unsigned short &wave);

class Song{
    private:
        char songname[29];
        unsigned char tracks;
        unsigned short  bytes_per_row;
        unsigned char interrow_resolution;

        unsigned char num_orders;
        unsigned char num_patterns;
        unsigned char *orders;
        Pattern **patterns;

        unsigned char num_instruments;
        Instrument **instruments;

        unsigned short waveEntries;
        unsigned short *waveTable;


    public:
        Song();
        Song(std::istream &in);
        ~Song();


        std::ostream &output(std::ostream &out) const;
        std::istream &input(std::istream &in);


        inline char *getName(){return songname;}
        void setName(char *name, int length);
        void set(char *name, int length);

        /***\//////////////////////////////////////////////////////////////////////////        
Function: void setBytesPerRow(unsigned short bpr)

Description:
Sets the byte samples size produces by one row
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
        inline void setBytesPerRow(unsigned short bpr){bytes_per_row = bpr;}

        /***\//////////////////////////////////////////////////////////////////////////        
Function: void setInterRowResolution(unsigned char res)

Description:
Sets the subdivision of the bytes per row 
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
        inline void setInterRowResolution(unsigned char res){interrow_resolution = res;}
        inline unsigned char getInterRowResolution(){return interrow_resolution;}



        bool insertOrder(unsigned char dest, unsigned char pattern);
        bool removeOrder(unsigned char ordr);

        bool newPattern();
        bool clonePattern(unsigned char src);
        bool clearPattern(unsigned char ptrn);
        bool removePattern(unsigned char ptrn);

        bool newInstrument();
        bool cloneInstrument(unsigned char inst);
        bool removeInstrument(unsigned char inst);

        void setTrackNum(const unsigned newtracks);

        inline unsigned char numInstruments() const {return num_instruments;}
        inline unsigned char numOrders() const {return num_orders;}
        inline unsigned char numTracks() const {return tracks;}
        inline unsigned char numPatterns() const {return num_patterns;}

        inline unsigned short numWaveEntries() const {return waveEntries;}
        inline unsigned short *getWaveTable() {return waveTable;}
        inline unsigned short getWaveEntry(unsigned short index) {return waveTable[index];}
        inline void setWaveEntry(unsigned short index, unsigned short entry){waveTable[index] = entry;}
        bool insertWaveEntry(unsigned short index, unsigned short entry);
        bool removeWaveEntry(unsigned short index);
        void fixWaveJumps(const unsigned short &index, short difference);




        inline unsigned int getBytesPerRow() const {return bytes_per_row;}
        inline unsigned char getInterrowRes() const {return interrow_resolution;}

        inline void setPatternIndexByOrder(unsigned const char &order, const unsigned char &pattern){orders[order] = pattern;}

        inline Pattern *getPattern(unsigned const char &ptrn) const {return patterns[ptrn];}
        inline Pattern *getPatternByOrder(unsigned const char &order) const {return patterns[orders[order]];}
        inline Instrument *getInstrument(unsigned const char &inst) const {if(inst >= num_instruments) return NULL; else return instruments[inst];}
        inline unsigned char getPatternIndexByOrder(unsigned const char &order) const {return orders[order];}


};

#endif
