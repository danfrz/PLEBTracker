#include <ncurses.h>
#include "tables.h"
#include "instedtr.h"
#include "patternedtr.h"
#include "cmdbar.h"

#include "pattern.h"
#include "instrument.h"
#include "song.h"


#include <iostream>
///////////////INITIALIZIING////////////////
////////////////////////////////////////////
namespace editor
{
    int WIN_HEIGHT, WIN_WIDTH;
    WINDOW *ptrnwin;
    WINDOW *instwin;
    WINDOW *metawin;
    WINDOW *volwin;
    WINDOW *wavewin;
    WINDOW *dialog;

    WINDOW *wingroup;
    WINDOW *inputwin;
    WINDOW *lastwin;

    bool running;


    int numBuffer;
    char charBuffer[29];
    char charInputBuffer[29];
    char lastSongPath[64];
    char textCursorPos;

    Song *song;
    Instrument *selinst;
}

//Pattern Editor
namespace patternedtr
{
    std::map<int,unsigned int> notemap;
    Pattern *selptrn; 
    unsigned char viewporttrack;
    unsigned char viewportrow;

    unsigned char maxtracksviewport;
    unsigned char maxrowsviewport;

    unsigned char selrow;
    unsigned char seltrack;
    unsigned char seltrackseg;
    unsigned char selorder;

    unsigned char selinstrument;
    unsigned char edit_step;
    unsigned char octave;
    unsigned int entryclipboard;


    //METADATA (Main controls)
    unsigned char metaobjindex;
    bool metaobjedit;

    unsigned char selobjmeta;//x
    unsigned char selrowmeta;//y

}

//Instrument Edtior
namespace instedtr
{
    unsigned short waveclipboard;
    unsigned short volclipboard;

    bool instobjedit;
    unsigned char selinstrow;
    unsigned char selinstobj;
    unsigned short selwavrow;
    unsigned char selwavseg;
    unsigned short viewportwave;
    unsigned char viewportvol;


    unsigned char selvolrow;
    unsigned char selvolseg;
}
/////////////DONE INITIALIZING/////////////
///////////////////////////////////////////

bool editor::validateHexChar(char a)
{
    if(a >= 'a')
        a -= 32;
    return(a <= '9' && a >= '0' || a >= 'A' && a <= 'F');
}

bool editor::validateByte(char str[2])
{


}

bool editor::validate64(char str[2])
{
    //values < 64 have to start with 0 to 3
    //invalid ascii characters are filterred
    return str[0] < '4' && str[0] >= '0' && validateHexChar(str[1]);
} 
unsigned char editor::charHex(char c)
{
    if(c<='9' && c>='0')
        return c-'0';
    if(c >= 'a')
        c -= 32;
    if(c>='A' && c <= 'F')
        return c-55;
    return -1;
}

char *editor::byteString(char *string, unsigned char byte)
{
    unsigned char d = byte % 0x10;
    string[1] = hexnums[d];
    byte /=0x10;
    d = byte % 0x10;
    string[0] = hexnums[d];
    return string;
}
char *editor::intString(char *string, unsigned int integer, const unsigned int &strlen)
{
    unsigned char d;
    for(int i = 0; i < strlen; i++)
    {
        d = integer & 0xF;
        string[strlen-i-1]= hexnums[d];
        integer >>= 4;
    }
    return string;
}

char *editor::shortString(char *string,  unsigned short shrt, const unsigned int &strlen)
{
    unsigned char d;
    for(int i = 0; i < strlen; i++)
    {
        d = shrt & 0xF;
        string[strlen-i-1]= hexnums[d];
        shrt >>= 4;
    }
    return string;
}

unsigned char editor::parseHexChar(char str[2])
{
    //values < 64 have to start with 0 to 3
    //invalid ascii characters are filterred
    unsigned char out = charHex(str[0])*0x10;
    out + charHex(str[1]);
    return out;
}

void editor::inform(const char *message)
{
    attroff(-1);
    attron(COLOR_PAIR(patternedtr::COL_META_SU));
    mvprintw(3,4,"+---------------------------------+",stdscr);
    mvprintw(8,4,"+---------------------------------+",stdscr);
    attroff(-1);
    mvprintw(4,4,"                                   ",stdscr);
    mvprintw(5,4,message,stdscr);
    mvprintw(6,4,"                                   ",stdscr);
    mvprintw(7,4," Press [Space] to continue         ",stdscr);
    int ch;
    while((ch=getch()) != ' ' && ch != '\n');
    return;
}
bool editor::confirm(const char *message)
{
    attroff(-1);
    attron(COLOR_PAIR(patternedtr::COL_META_SU));
    mvprintw(3,4,"+---------------------------------+",stdscr);
    mvprintw(8,4,"+---------------------------------+",stdscr);
    attroff(-1);
    mvprintw(4,4,"                                   ",stdscr);
    mvprintw(5,4,message,stdscr);
    int len = strlen(message);
    if(len < 34)
        for(int i = 0; i < 34; i++)
            mvprintw(5, 4+len, " ", stdscr);
    mvprintw(6,4,"                                   ",stdscr);
    mvprintw(7,4," Are you sure? [y/n]               ",stdscr);

    int ch;
    while((ch=getch()) != 'y' && ch != 'n' && ch != '\n' && ch != 27);
    if(ch == 'y' || ch == '\n')
        return true;
    return false;
}
void editor::displayAbout()
{
    attroff(-1);
    attron(COLOR_PAIR(patternedtr::COL_META_SU));
    mvprintw(3,4, "+---------------------------------+",stdscr);
    mvprintw(15,4,"+---------------------------------+",stdscr);
    attroff(-1);
    mvprintw(4,4, "  Welcome to PLEBTracker!       v1 ",stdscr);
    mvprintw(5,4, "                                   ",stdscr);
    mvprintw(6,4, "Press TAB to switch windows        ",stdscr);
    mvprintw(7,4, "                                   ",stdscr);
    mvprintw(8,4, "                                   ",stdscr);
    mvprintw(9,4, "                                   ",stdscr);
    mvprintw(10,4,"                                   ",stdscr);
    mvprintw(11,4,"                                   ",stdscr);
    mvprintw(12,4,"                      -Dan Frazier ",stdscr);
    mvprintw(13,4,"                                   ",stdscr);
    mvprintw(14,4," Press [Space] to continue         ",stdscr);
    int ch;
    while((ch=getch()) != ' ' && ch != '\n');
    return;
}


const char *editor::locateFile(bool save)
{
    return NULL;
    /*
    struct dirent *de=NULL;
    DIR *dir;

    int selection = 0;
    int viewport = 0;
    std::vector<dirent*> files;

    dir = opendir(".");
    if(dir == NULL)
    {
        std::cerr << "Failed to open current directory\n";
        return NULL;
    }
    while(de = readdir(dir))
        files.push_back(de);

    mvprintw(3,4, "+----------------------------------------------------------+",stdscr);
    if(save)
        mvprintw(4,4, "                         SAVE SONG                          ",stdscr);
    else
        mvprintw(4,4, "                         OPEN SONG                          ",stdscr);
    mvprintw(5,4, "                                                            ",stdscr);
    mvprintw(6,4, "                                                            ",stdscr);
    mvprintw(7,4, "                                                            ",stdscr);
    mvprintw(8,4, "                                                            ",stdscr);
    mvprintw(9,4, "                                                            ",stdscr);
    mvprintw(10,4,"                                                            ",stdscr);
    mvprintw(11,4,"                                                            ",stdscr);
    mvprintw(12,4,"                                                            ",stdscr);
    mvprintw(13,4,"                                                            ",stdscr);
    mvprintw(14,4,"                                                            ",stdscr);
    mvprintw(15,4,"+----------------------------------------------------------+",stdscr);



    closedir(dir);
*/
}



int main()
{
    initscr();
    raw();
    start_color();
    noecho();

    clear();
    printw("PLEBTracker [Press any key to continue] 20160114-20160121");
    curs_set(0);
    getch();
    clear();

    {
        using namespace patternedtr;
        //META color mappings
        init_pair(COL_META_SSS, COLOR_YELLOW, COLOR_CYAN);
        init_pair(COL_META_SSSE, COLOR_YELLOW, COLOR_MAGENTA);
        init_pair(COL_META_SSU, COLOR_BLACK, COLOR_CYAN);
        init_pair(COL_META_SU , COLOR_BLACK , COLOR_BLUE);
        init_pair(COL_META_US , COLOR_CYAN  , COLOR_BLACK);
        init_pair(COL_META_UU , COLOR_BLUE  , COLOR_BLACK);


        init_pair(COL_META_ERR, COLOR_MAGENTA, COLOR_BLUE);
        init_pair(COL_META_SSS_ERR, COLOR_MAGENTA, COLOR_CYAN);


        //PATTERN color mappings
        init_pair(COL_PTRN_SSS      , COLOR_YELLOW, COLOR_CYAN);

        init_pair(COL_PTRN_SSU_NOTE , COLOR_BLACK, COLOR_BLUE);
        init_pair(COL_PTRN_SSU_INST , COLOR_BLACK, COLOR_BLUE);
        init_pair(COL_PTRN_SSU_VOL  , COLOR_GREEN, COLOR_BLUE);
        init_pair(COL_PTRN_SSU_FX   , COLOR_MAGENTA, COLOR_BLUE);
        init_pair(COL_PTRN_SSU_SYSFX, COLOR_RED, COLOR_BLUE);

        init_pair(COL_PTRN_SU_NOTE  , COLOR_WHITE, COLOR_BLACK);
        init_pair(COL_PTRN_SU_INST  , COLOR_WHITE, COLOR_BLACK);
        init_pair(COL_PTRN_SU_VOL   , COLOR_GREEN, COLOR_BLACK);
        init_pair(COL_PTRN_SU_FX    , COLOR_YELLOW, COLOR_BLACK);
        init_pair(COL_PTRN_SU_SYSFX , COLOR_RED, COLOR_BLACK);

        init_pair(COL_PTRN_US       , COLOR_CYAN, COLOR_BLACK);
        init_pair(COL_PTRN_UU       , COLOR_BLUE, COLOR_BLACK);

    }













    //INITIALIZE EXTERNAL IDENTIFIERS

    getmaxyx(stdscr, editor::WIN_HEIGHT, editor::WIN_WIDTH);
    editor::metawin = newwin(3, editor::WIN_WIDTH,                       0, 0);
    editor::ptrnwin = newwin(editor::WIN_HEIGHT-3, editor::WIN_WIDTH-11, 3, 0);
    editor::instwin = newwin(editor::WIN_HEIGHT, editor::WIN_WIDTH,      0, 0);
    editor::wavewin = newwin(editor::WIN_HEIGHT-5, 10,                   3, editor::WIN_WIDTH-10);
    editor::dialog  = newwin(8, 60,             editor::WIN_HEIGHT/3, editor::WIN_WIDTH/3); //good enough
    editor::song = new Song();
    editor::selinst = editor::song->getInstrument(0);

    editor::wingroup = editor::ptrnwin;
    editor::inputwin = editor::metawin;
    editor::lastwin = editor::metawin;

    patternedtr::populateNoteMap();
    patternedtr::selptrn = editor::song->getPattern(0);
    patternedtr::viewporttrack = 0;
    patternedtr::viewportrow = 0;

    patternedtr::maxtracksviewport = (editor::WIN_WIDTH-11) / 15;
    patternedtr::maxrowsviewport = (editor::WIN_HEIGHT-3);

    patternedtr::selrow = 0;
    patternedtr::seltrack = 0;
    patternedtr::seltrackseg = 0;
    patternedtr::selorder = 0;

    patternedtr::selinstrument = 0;
    patternedtr::edit_step = 1;
    patternedtr::octave = 3;
    patternedtr::entryclipboard = R_EMPTY;

    instedtr::selinstrow = 0;
    instedtr::selinstobj = 0;
    instedtr::instobjedit = false;
    instedtr::selwavrow = 0;
    instedtr::selwavseg = 0;
    instedtr::viewportwave = 0;

    instedtr::selvolrow = 0;
    instedtr::selvolseg = 0;
    instedtr::viewportvol = 0;

    editor::lastSongPath[0] = 's';
    editor::lastSongPath[1] = 'o';
    editor::lastSongPath[2] = 'n';
    editor::lastSongPath[3] = 'g';
    editor::lastSongPath[4] = '.';
    editor::lastSongPath[5] = 'p';
    editor::lastSongPath[6] = 'l';
    editor::lastSongPath[7] = 'b';
    editor::lastSongPath[8] = 0;

    patternedtr::metaobjindex = 0;
    patternedtr::metaobjedit = false;
    patternedtr::selobjmeta = 3;
    patternedtr::selrowmeta = 0;

    keypad(stdscr, 1);
    keypad(editor::metawin, 1);
    keypad(editor::ptrnwin, 1);
    keypad(editor::instwin, 1);
    keypad(editor::wavewin, 1);
    keypad(editor::dialog, 1);

    patternedtr::display();
    int ch;
    editor::running = true;
    while(editor::running)
    {
        ch = getch();


        if(ch == '\t')
        {
            using namespace editor;

            if(patternedtr::metaobjedit)
            {
                patternedtr::metaobjedit = false;
                continue;
            } if(instedtr::instobjedit)
            {
                instedtr::instobjedit = false;
                continue;
            }
            else
            {

                mvprintw(WIN_HEIGHT-1, 0, "[q]meta [w]ptrn [e/d]wave [a]vol [s]inst", stdscr);
                while(ch == '\t')
                    ch = getch();
                switch(ch)
                {
                    case 's':
                        //Instrument view

                        inputwin = instwin;
                        wingroup = instwin;
                        instedtr::display();

                        break;
                    case 'q':
                        //Meta / Menu : Pattern View

                        inputwin = metawin;
                        wingroup = ptrnwin;
                        patternedtr::display();

                        break;
                    case 'w':
                        //Pattern View

                        inputwin = ptrnwin;
                        wingroup = ptrnwin;
                        patternedtr::display();

                        break;
                    case 'e':
                    case 'd':
                        //Wave : Pattern View -- Wave : Instrument View
                        inputwin = wavewin;
                        if(wingroup == ptrnwin)
                        {
                            patternedtr::display();
                        }
                        else if(wingroup == instwin)
                        {
                            instedtr::display();
                        }
                        else
                        {
                            wingroup = instwin;
                            instedtr::display();
                        }

                        break;
                    case 'a':
                        //Volume : Instrument View
                        inputwin = volwin;
                        wingroup = instwin;
                        instedtr::display();
                        break;
                }
            }

        }
        else if(ch == '/' && (!patternedtr::metaobjedit|| !instedtr::instobjedit) )
        {
            //If command not cancelled do it
            if(editor::getCommand())
                editor::doCommand();

            if(editor::wingroup == editor::ptrnwin)
                patternedtr::display();
            else if(editor::wingroup == editor::instwin)
                instedtr::display();
        }
        else
        {

            //MISC binds
            if(!patternedtr::metaobjedit && !instedtr::instobjedit)
            {
                using namespace editor;
                bool confirmation;
                switch(ch)
                {
                    case 'U'://Save
                        confirmation = editor::confirm("Save?");
                        if(confirmation)
                        {
                            const char *file = patternedtr::browse();
                            if(file)
                            {
                                patternedtr::saveSong(file);
                                if(wingroup == ptrnwin)
                                    patternedtr::display();
                                else if(wingroup == instwin)
                                    instedtr::display();
                            }

                        }
                        continue;
                    case 'O'://Open
                        confirmation = editor::confirm("Open? Any unsaved data will be lost");
                        if(confirmation)
                        {
                            const char *file = patternedtr::browse();
                            if(file)
                            {
                                patternedtr::openSong(file);
                                if(wingroup == ptrnwin)
                                    patternedtr::display();
                                else if(wingroup == instwin)
                                    instedtr::display();
                            }
                        }
                        continue;
                    case 'P'://New
                        confirmation = editor::confirm("This will delete any unsaved data");
                        if(confirmation)
                        {
                            patternedtr::newSong();
                            if(wingroup == ptrnwin)
                                patternedtr::display();
                            else if(wingroup == instwin)
                                instedtr::display();
                        }
                        continue;
                    case 'H'://Quick Change Instrument
                        if(editor::wingroup == editor::ptrnwin)
                        {
                            editor::inputwin = editor::metawin;
                            patternedtr::selobjmeta = 4;
                            patternedtr::selrowmeta = 1;
                            patternedtr::startMetaEditing();
                            patternedtr::display();
                        }
                        else if(editor::wingroup == editor::instwin)
                        {
                            editor::inputwin = editor::instwin;
                            instedtr::selinstrow = 0;
                            instedtr::selinstobj = 6;
                            instedtr::startInstEditing();
                            instedtr::display();
                        }

                        continue;
                    case 'J'://Quick Change Wave Index

                        editor::inputwin = editor::instwin;
                        editor::wingroup = editor::instwin;
                        instedtr::selinstrow = 1;
                        instedtr::selinstobj = 0;
                        instedtr::startInstEditing();
                        instedtr::display();
                        continue;
                    case 'K'://Quick Change Order

                        editor::wingroup = editor::ptrnwin;
                        editor::inputwin = editor::metawin;
                        patternedtr::selobjmeta = 0;
                        patternedtr::selrowmeta = 2;
                        patternedtr::startMetaEditing();
                        patternedtr::display();
                        continue;
                    case 'L'://Select Order Operations

                        editor::wingroup = editor::ptrnwin;
                        editor::inputwin = editor::metawin;
                        patternedtr::selobjmeta = 5;
                        patternedtr::selrowmeta = 2;
                        patternedtr::display();
                        continue;

                    case 'M'://Quick Change Pattern

                        editor::wingroup = editor::ptrnwin;
                        editor::inputwin = editor::metawin;
                        patternedtr::selobjmeta = 1;
                        patternedtr::selrowmeta = 2;
                        patternedtr::startMetaEditing();
                        patternedtr::display();
                        continue;

                    case '<'://Select Pattern operations

                        editor::wingroup = editor::ptrnwin;
                        editor::inputwin = editor::metawin;
                        patternedtr::selobjmeta = 10;
                        patternedtr::selrowmeta = 2;
                        patternedtr::display();
                        continue;
                }
            }

            using namespace editor;

            //Yes in this order and dont combine the if groups


            if(wingroup == ptrnwin)
                patternedtr::processInput(ch);
            else if(wingroup == instwin)
                instedtr::processInput(ch);

            if(wingroup == ptrnwin)
                patternedtr::display();
            else if(wingroup == instwin)
                instedtr::display();
        }



    }
    delete editor::song;

    endwin();
    return 0;
}
