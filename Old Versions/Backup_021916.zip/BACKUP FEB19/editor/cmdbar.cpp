#include "cmdbar.h"


bool editor::getCommand()
{
    int ypos = WIN_HEIGHT -1;
    mvprintw(ypos, 0, std::string(WIN_WIDTH, ' ').c_str(), stdscr);
    mvprintw(ypos, 0, "/:", stdscr);
    int in;
    char sel[2];
    sel[1] = 0;
    textCursorPos = 0;
    for(int i = 0; i < 29; i++)
        charInputBuffer[i] = 0;
    while((in = getch()) != '\n' && in != '\t')
    {
        switch(in)
        {
            case KEY_LEFT:
                if(textCursorPos > 0)
                    textCursorPos--;

                break;
            case KEY_RIGHT:
                if(textCursorPos < strlen(charInputBuffer))
                    textCursorPos++;

                break;
            case KEY_HOME:
                textCursorPos = 0;
                break;
            case KEY_END:
                textCursorPos = strlen(charInputBuffer);
                break;
            case KEY_IC:
                {
                    int length = strlen(charInputBuffer);
                    for(int i = length; i > textCursorPos; i--)
                        charInputBuffer[i] = charInputBuffer[i-1];
                    charInputBuffer[length+1] = 0;
                    charInputBuffer[textCursorPos] = ' ';
                }
            case KEY_DC:
                {
                    int length = strlen(charInputBuffer);
                    for(int i = textCursorPos+1; i < length; i++)
                        charInputBuffer[i-1] = charInputBuffer[i];
                    charInputBuffer[length-1] = 0;
                    if(textCursorPos >= length && length > 0)
                        textCursorPos--;
                }
                break;
            default:
                {
                    if(in <= 'z' && in >= ' ')
                    {
                        charInputBuffer[textCursorPos] = in;
                        if(textCursorPos < strlen(charInputBuffer))
                            textCursorPos++;           
                    }
                }

        }
        editor::copy(charInputBuffer, charBuffer, 29);
        editor::makeUnderlines(charBuffer, 28);

        attroff(-1);
        mvprintw(ypos, 2, charBuffer, stdscr);
        sel[0] = charBuffer[textCursorPos];
        attron(COLOR_PAIR(patternedtr::COL_META_SSS));
        attron(A_BOLD);
        mvprintw(ypos, 2+textCursorPos, sel, stdscr);

        //change 


    }

    if(in == '\t')
        return false;
    return true;

}

void editor::tokenize(std::vector<char*> &tokens, int i)
{
    bool wasspace = true;
    for(; i < 29; i++)
    {
        if(wasspace)
        {
            if(charInputBuffer[i] != 0 && charInputBuffer[i] != ' ')
            {
                tokens.push_back(charInputBuffer + i);
                wasspace = false;
            }
        }
        else
        {
            if(charInputBuffer[i] == 0 || charInputBuffer[i] == ' ')
            {
                charInputBuffer[i] = 0;
                wasspace = true;
            }
        }
    }
}

unsigned int editor::parseUnsigned(char *str)
{
    int len = strlen(str);
    unsigned int acc =0;
    for(int i = 0; i < len; i++)
    {
        acc *= 0x10; //Horners!
        if(str[i] >= 'A')
        {
            if(str[i] >= 'a' && str[i] <= 'f')
                acc += (str[i] - 'a' + 0xa);
            else if(str[i] <= 'F')
                acc += (str[i] - 'A' + 0xA);
        }
        else
            if(str[i] >= '0' && str[i] <= '9')
                acc += (str[i] - '0');
    }
    return acc;
}

int editor::parseSigned(char *str)
{
    int acc =0;
    int len = strlen(str);

    bool negative = false;
    if(str[0] == '-')
    {
        negative = true;
        len--;
    }
    else if(str[0] == '+')
        len--;

    for(int i = len-1; i >= 0; i--)
    {
        acc *= 0x10; //Horners!
        if(str[i] >= 'A')
            if(str[i] >= 'a')
                acc += (str[i] - 'a' + 0xa);
            else
                acc += (str[i] - 'A' + 0xA);
        else
            acc += (str[i] - '0');
    }
    if(negative)
        return -acc;
    return acc;
}

void editor::doCommand()
{
    int tokeni = 0;
    int tokenend = 0;
    int len = strlen(charInputBuffer);
    if(len < 1)
        return;

    while(charInputBuffer[tokeni] == ' ' && tokeni < len)
        tokeni++;
    if(tokeni == len)
        return;
    tokenend = tokeni;
    while(charInputBuffer[tokenend] != ' ' && tokenend < len)
        tokenend++;
    charInputBuffer[tokenend] = 0;
    std::vector<char *> tokens;
    editor::tokenize(tokens, tokenend);

    
    if(strcmp(charInputBuffer+tokeni, "w") == 0)//SAVE FILE
        handle_w(tokens);
    else if(strcmp(charInputBuffer+tokeni, "q") == 0) //QUIT TRACKER
        handle_q(tokens);
    
    else if(strcmp(charInputBuffer+tokeni, "wq") == 0) //SAVE AND QUIT
        handle_wq(tokens);
    else if(strcmp(charInputBuffer+tokeni, "o") == 0)//OPEN FILE
        handle_o(tokens);
    
    else if(strcmp(charInputBuffer+tokeni, "e") == 0)//REFRESH FILE
    {
        bool ans = editor::confirm("Restore File?");
        if(ans)
            patternedtr::openSong(lastSongPath);
    }
    
    else if(strcmp(charInputBuffer+ tokeni, "d") == 0)//DELETE ...
        editor::handle_d(tokens);
    
    else if(strcmp(charInputBuffer+tokeni, "dd") == 0)//CLEAR TRACK
    {
        patternedtr::clearTrack(); 
    }
    
    else if(strcmp(charInputBuffer+tokeni, "ddd") == 0)//CLEAR PATTERN
    {
        patternedtr::clearPattern();
    }
    
    else if(strcmp(charInputBuffer+tokeni, "yy") == 0)//COPY TRACK
    {
        //2 parameters

    }
    
    else if(strcmp(charInputBuffer+tokeni, "y") == 0)//COPY ...
        editor::handle_y(tokens);
    
    else if(strcmp(charInputBuffer+tokeni, "p") == 0)//PASTE ...
        editor::handle_p(tokens);
    
    else if(strcmp(charInputBuffer+tokeni, "n") == 0)//NEW ...
        editor::handle_n(tokens);
    //SET WAVEI for Instrument
    else if(strcmp(charInputBuffer+tokeni, "wave") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned short entry = parseUnsigned(tokens.at(0));
            editor::selinst->setWaveIndex(entry);
        }
        else
            inform("Too many params for Set Wave Index");
    
    }
    //SET selected Instrumnent
    else if(strcmp(charInputBuffer+tokeni, "inst") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= song->numInstruments())
                entry = song->numInstruments()-1;
            patternedtr::selinstrument = entry;
            editor::selinst = song->getInstrument(entry);
            instedtr::selwavrow = editor::selinst->getWaveIndex();
            instedtr::chgSelWavRow(0);
        }
        else
            inform("Too many params for Set Selected Instrument");
    }
    //SET selected Order
    else if(strcmp(charInputBuffer+tokeni, "order") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= song->numOrders())
                entry = song->numOrders()-1;
            patternedtr::selorder = entry;
            patternedtr::selptrn = song->getPatternByOrder(entry);
        }
        else
            inform("Too many params for Set Selected Order");
    
    }
    //CHANGE order's pattern
    else if(strcmp(charInputBuffer+tokeni, "ptrn") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= song->numPatterns())
                    entry = song->numPatterns()-1;
            song->setPatternIndexByOrder(patternedtr::selorder, entry);
            patternedtr::selptrn = song->getPattern(entry);
        }
        else
            inform("Too many params for Set Order's Pattern");
    }
    //SET selected row (window context sensitive)
    else if(strcmp(charInputBuffer+tokeni, "row") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= patternedtr::selptrn->numRows())
                    entry = patternedtr::selptrn->numRows()-1;
            patternedtr::selrow = entry;
        }
        else
            inform("Too many params for Set Row");

    }
    //SET selected track
    else if(strcmp(charInputBuffer+tokeni, "trk") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= patternedtr::selptrn->numTracks())
                    entry = patternedtr::selptrn->numTracks()-1;
            patternedtr::seltrack = entry;
        }
        else
            inform("Too many params for Set Track");
    
    }
    //SET step
    else if(strcmp(charInputBuffer+tokeni, "step") == 0)
    {
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            patternedtr::edit_step = entry;
        }
        else
            inform("Too many params for Set Edit Step");
    }
    //SET octave
    else if(strcmp(charInputBuffer+tokeni, "oct") == 0)
    {
    
        if(tokens.size() == 1)
        {
            unsigned char entry = parseUnsigned(tokens.at(0));
            if(entry >= 6)
                    entry = 6;
            patternedtr::octave = entry;
        }
        else
            inform("Too many params for Set Octave");
    }
    else if(strcmp(charInputBuffer+tokeni, "trans") == 0)
    {
        //+ semitones

    }
    else if(strcmp(charInputBuffer+tokeni, "amp") == 0)
    {
        //accept speed: linear, etc

    }else if(strcmp(charInputBuffer+tokeni, "lengthen") == 0)
    {

    }
    else
    {
        editor::inform("Input misunderstood              :(");
    }



}

void editor::handle_q(std::vector<char*> &params)
{
    bool ans = editor::confirm("Exit?");
    if(ans)
        patternedtr::exit();

}

void editor::handle_w(std::vector<char*> &params)
{

    //get extra parameter

    //confirm save

    
    if(params.size() > 0)
    {
        if(params.size() == 1)
        {
            bool ans = editor::confirm("Save to File?");
            if(ans)
            {
                bool scc = patternedtr::saveSong(params.at(0));
                if(scc)
                {
                    int len = strlen(params.at(0));
                    editor::copy(params.at(0), lastSongPath, len);
                }
                else
                    editor::inform("Couldn't save file");
            }
        }
        else
            editor::inform("Too many parameters for Save");
    }
    else
    {
        bool ans = editor::confirm("Save?");
        patternedtr::saveSong(lastSongPath);
    }
}

void editor::handle_wq(std::vector<char*> &params)
{
    //confirm save and quit
    //get extra parameter

    if(params.size() > 0)
    {
        if(params.size() == 1)
        {
            bool ans = editor::confirm("Save to File then Quit?");
            if(ans)
            {
                bool scc = patternedtr::saveSong(params.at(0));
                if(scc)
                {
                    patternedtr::exit();
                }
                else
                    editor::inform("Couldn't save file");
            }
        }
        else
            editor::inform("Too many parameters for Save");
    }
    else
    {
        bool ans = editor::confirm("Save and Quit?");

        if(ans)
        {
            bool scc = patternedtr::saveSong(lastSongPath);
            if(scc)
                patternedtr::exit();
            else
                editor::inform("Too many parameters for Save");
        }
    }
}

void editor::handle_o(std::vector<char*> &params)
{
        //get parameter
    if(params.size() > 0)
    {
        if(params.size() == 1)
        {
            bool ans = editor::confirm("Open from File?");
            if(ans)
            {
                bool scc = patternedtr::openSong(params.at(0));
                if(scc)
                {
                    int len = strlen(params.at(0));
                    editor::copy(params.at(0), lastSongPath, len);
                }
            }
        }
        else
            editor::inform("Too many parameters for Open");
    }
    else
    {
        bool ans = editor::confirm("Restore Song?");
        if(ans)
            patternedtr::openSong(lastSongPath);
    }
}

void editor::handle_d(std::vector<char*> &params)
{
    //get type by parameter
    //    no type: ...
    //            get region for pattern editor
    //          trk: clear track
    //          inst: instrument
    //          order: order 
    //          ptrn: delete pattern
    //         

    if(params.size() > 0)
    {
        char *p = params.at(0);
        if(strcmp(p, "trk") == 0)
            patternedtr::clearTrack();
        else if(strcmp(p, "inst") == 0)
            patternedtr::removeInstrument();
        else if(strcmp(p, "order") == 0)
            patternedtr::removeOrder();
        else if(strcmp(p, "ptrn") == 0)
            patternedtr::removePattern();
        else 
            inform("(d)Param not understood");

    }
    else
        patternedtr::selptrn->setAt(patternedtr::seltrack, patternedtr::selrow, R_EMPTY);
}

void editor::handle_y(std::vector<char*> &params)
{
    //get region by parameters
    //if no region, copy cell selected
    if(params.size() > 0)
    {
        char *p = params.at(0);
        if(strcmp(p, "trk") == 0)
        {
            //get destination
        }
        else if(strcmp(p, "inst") == 0)
        {
            if(params.size() == 2)
            {
                unsigned short entry = parseUnsigned(params.at(1));
                if(entry > song->numInstruments())
                    inform("Instrument invalid, cant copy");
                else
                {
                    patternedtr::selinstrument = entry;
                    selinst = song->getInstrument(entry);
                }

            }
            else
                patternedtr::cloneInstrument();
        }
        else if(strcmp(p, "order") == 0)
            patternedtr::cloneOrder();
        else if(strcmp(p, "ptrn") == 0)
            patternedtr::clonePattern();
        else 
            inform("(y)Param not understood");

    }


}


void editor::handle_p(std::vector<char*> &params)
{
    //paste at location by parameters
    //if no location, past at selected cell
}

void editor::handle_n(std::vector<char*> &params)
{
    //get type by parameter...
    //   no param: new Song
    //          song: new Song
    //          inst: new Instrument
    //             i: new Instrument
    //   
    if(params.size() > 0)
    {
        char *p = params.at(0);
        if(strcmp(p, "song") == 0)
        {
            patternedtr::newSong();
        }
        else if(strcmp(p, "inst") == 0)
            patternedtr::newInstrument();
        else if(strcmp(p, "order") == 0)
            patternedtr::newOrder();
        else if(strcmp(p, "ptrn") == 0)
            patternedtr::newPattern();
        else 
            inform("(n)Param not understood");

    }
    else
    {
        bool scc = confirm("New song? All unsaved will be lost");
        if(scc)
            patternedtr::newSong();
    }


}







