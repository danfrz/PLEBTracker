#ifndef INTERPRETER_H_
#define INTERPRETER_H_
#include <istream>
#include <ostream>
#include <fstream>
#include <cstring>
#include "includes/song.h"
#include "includes/instrument.h"
#include "includes/pattern.h"
#include "generator.h"


namespace itrp
{

    struct Track
    {
        unsigned char *ptbl;
        float frq;
        float phase;

        unsigned char fxparam;
        Instrument *inst;

        unsigned short wavei;
        unsigned char lastwave;
        unsigned char waveduracc;

        unsigned char ptrnvol;

        unsigned char lastvol;
        unsigned char voli;
        unsigned char volduracc;
    };



    Song *song;
    Track *tracks;
    Pattern *curpattern;
    unsigned char order;
    generator *generators;
    bool trackmute[256];

    void initializeWaveTable();
    void initializeRender();
    void renderTick(unsigned char *buffer, const unsigned char &track, const unsigned int &bytes);
    unsigned char *renderPattern(int start, int end, unsigned int &bytes);

    unsigned char **renderSong(unsigned int *bytes);
    unsigned char **renderSong(unsigned int *bytes, int start_order, int end_order, int start_row, int end_row);
    bool load(const char *file);
    void play(unsigned char **buffer, const unsigned int orders, unsigned int *bytes);
    void play(unsigned char *buffer, unsigned int bytes);
    void print(unsigned char **buffer, const unsigned int orders, unsigned int *bytes);


/***\//////////////////////////////////////////////////////////////////////////    
Function: void printByte(uchar &b, const char &character, const uchar &res

Description:
   Prints a single byte to cout
   using the specified character
   where each character represents 'res' units
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void printByte(unsigned char &b, const char &character, const unsigned char &res);


/***\//////////////////////////////////////////////////////////////////////////    
Function: void printBuffer(unsigned char *bfr, const unsigned long &len

Description:
   Prints a whole buffer to the console
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void printBuffer(unsigned char *bfr, const unsigned long &len);

    void purgeSong();




}

#endif
