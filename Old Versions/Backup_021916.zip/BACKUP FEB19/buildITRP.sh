g++ interpreter.cpp generator.cpp src/*.cpp -Iincludes  -lncurses --std=c++11  -o PLEBInterpreter > buildlog.log 2> buildlog.log;
less buildlog.log
