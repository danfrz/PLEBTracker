#include "song.h"


Song::Song()
{
    bytes_per_row = 1024;
    interrow_resolution = 1;
    songname[0]='N';
    songname[1]='a';
    songname[2]='m';
    songname[3]='e';

    num_instruments = 1;
    instruments = new Instrument*[256];
    Instrument *defaultInst = new Instrument();
    instruments[0] = defaultInst;

    tracks = 4;
    num_patterns = 1;
    patterns = new Pattern*[256];
    Pattern *defaultPat = new Pattern(tracks, 64);
    patterns[0] = defaultPat;

    num_orders = 1;
    orders = new unsigned char[256];
    orders[0] = 0;

    waveTable = new unsigned short[256];

}

Song::Song(std::istream &in)
{

}

Song::~Song()
{
    delete [] instruments;
    delete [] patterns;
    delete [] orders;
    delete [] waveTable;

}



std::ostream &Song::output(std::ostream &out) const
{

    const static unsigned int minimalbytes = sizeof songname
        + sizeof bytes_per_row
        + sizeof interrow_resolution
        + sizeof tracks
        + sizeof num_orders
        + sizeof waveEntries
        + sizeof num_instruments
        + sizeof num_patterns;
    /*
       unsigned int bytesnum = minimalbytes
       + sizeof orders
       + sizeof waveTable;
       for(int i = 0; i < num_instruments; i++)
       bytesnum += instruments[i]->size();
       for(int i = 0; i < num_patterns; i++)
       bytesnum += patterns[i]->size();
       */
    out << songname << '\n'
        << (bytes_per_row) << '\n'
        << (interrow_resolution) << '\n'
        << (tracks) << '\n';

    out << (num_orders) << '\n';
    for(int i = 0; i < num_orders; i++)
        out << (orders[i]) << '\n'; 

    out << (waveEntries) << '\n';
    for(int i = 0; i < waveEntries; i++)
        out << waveTable[i] << '\n';

    out << (num_instruments) << '\n';
    for(int i = 0; i < num_instruments; i++)
        (instruments[i])->output(out) << '\n';

    out << (num_patterns) << '\n';
    for(int i = 0; i < num_patterns; i++)
        (patterns[i])->output(out) << '\n';
    return out;
}

std::istream &Song::input(std::istream &in)
{

    delete [] instruments;
    delete [] patterns;
    delete [] orders;
    delete [] waveTable;

    in.getline(songname,28);
    in >> bytes_per_row >> interrow_resolution >> tracks;
    in >> num_orders;
    orders = new unsigned char[256];
    for(int i = 0; i < num_orders; i++)
        in >> orders[i];

    instruments = new Instrument*[256];
    patterns = new Pattern*[256];
    waveTable = new unsigned short[256];

    in >> waveEntries;
    for(int i = 0; i < waveEntries; i++)
        in >> waveTable[i];

    in >> num_instruments;

    for(int i = 0; i < num_instruments; i++)
        instruments[i] = new Instrument(in);	

    in >> num_patterns;
    for(int i = 0; i < num_patterns; i++)
        patterns[i] = new Pattern(in);

    return in;
}


void Song::setName(char *name, int length)
{
    if(length > 28)
        length = 28;
    for(int i = 0; i < length; i++)
        songname[i] = name[i];
}

bool Song::insertOrder(unsigned char dest, unsigned char pattern)
{
    if(pattern >= num_patterns)
        return false;
    if(dest >num_orders)
        return false;
    for(int i=(num_orders++)-1; i >= dest; i--)
        orders[i+1] = orders[i];
    orders[dest] = pattern;

    return true;
}

bool Song::removeOrder(unsigned char ordr)
{
    if(ordr >= num_orders || num_orders == 1)
        return false;
    num_orders--;
    for(int i=ordr; i < num_orders; i++)
        orders[i] = orders[i+1];

    return true;
}

void Song::setTrackNum(const unsigned newtracks)
{
    tracks = newtracks;
    //loop through every pattern and change tracks
    for(int i = 0; i < num_patterns; i++)
        patterns[i]->setTrackNum(newtracks);
}

bool Song::newPattern()
{
    if(num_patterns == 255)
        return false;
    Pattern *newPat = new Pattern();
    patterns[num_patterns++] = newPat;
    return true;
}

bool Song::clonePattern(unsigned char src)
{
    if(num_patterns == 255)
        return false;

    Pattern *source = patterns[orders[src]];
    Pattern *newPat = new Pattern(*source);
    patterns[num_patterns++] = newPat;
    return true;
}

bool Song::clearPattern(unsigned char ptrn)
{
    patterns[ptrn]->clear();
}

bool Song::rmvPattern(unsigned char ptrn)
{
    if(ptrn >= num_patterns || num_patterns == 1)
        return false;

    delete patterns[ptrn];
    for(int i = ptrn+1; i < num_patterns; i++)
        patterns[i-1] = patterns[i];

    num_patterns--;

    patterns[num_patterns] = NULL;

    //then update orders to the new pattern indicies!

    //Set to the first pattern
    //so that it stands out and it would stand out looking through order list
    for(int i = 0; i < num_orders; i++)
        if(orders[i] == ptrn)
            orders[i] = 0;

    return true;
}

bool Song::newInstrument()
{
    if(num_instruments == 255)
        return false;

    Instrument *defaultInst = new Instrument();
    instruments[num_instruments++] = defaultInst;

    return true;
}

bool Song::cloneInstrument(unsigned char inst)
{
    if(num_instruments == 255)
        return false;

    Instrument *srcInst = instruments[inst];
    Instrument *newInst = new Instrument(*srcInst);
    instruments[num_instruments++] = newInst;

    return true;
}

bool Song::rmvInstrument(unsigned char inst)
{
    if(inst >= num_instruments || num_instruments == 1)
        return false;

    delete instruments[inst];
    inst+=1;
    while(inst < num_instruments)
        instruments[inst-1] = instruments[inst++];
    num_instruments--;
    //then update patterns with new instrument indicies
    for(int i = 0; i < num_patterns; i++)
        patterns[i]->purgeInstrument(inst);


    return true;
}



