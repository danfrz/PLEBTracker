#ifndef SONG_H_
#define SONG_H_

#include "instrument.h"
#include "pattern.h"
#include <istream>
#include <ostream>

class Song{
    private:
        char songname[29]{0};
        unsigned char tracks;
        unsigned int  bytes_per_row;
        unsigned char interrow_resolution;

        unsigned char num_orders;
        unsigned char num_patterns;
        unsigned char *orders;
        Pattern **patterns;

        unsigned char num_instruments;
        Instrument **instruments;

        unsigned short waveEntries;
        unsigned short *waveTable;


    public:
        Song();
        Song(std::istream &in);
        ~Song();


        std::ostream &output(std::ostream &out) const;
        std::istream &input(std::istream &in);


        inline char *getName(){return songname;}
        void setName(char *name, int length);
        void set(char *name, int length);

        /***\//////////////////////////////////////////////////////////////////////////        
Function: void setBytesPerRow(unsigned int bpr)

Description:
Sets the byte samples size produces by one row
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
        inline void setBytesPerRow(unsigned int bpr){bytes_per_row = bpr;}

        /***\//////////////////////////////////////////////////////////////////////////        
Function: void setInterRowResolution(unsigned char res)

Description:
Sets the subdivision of the bytes per row 
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
        void setInterRowResolution(unsigned char res);



        bool insertOrder(unsigned char dest, unsigned char pattern);
        bool removeOrder(unsigned char ordr);

        bool newPattern();
        bool clonePattern(unsigned char src);
        bool clearPattern(unsigned char ptrn);
        bool rmvPattern(unsigned char ptrn);

        bool newInstrument();
        bool cloneInstrument(unsigned char inst);
        bool rmvInstrument(unsigned char inst);

        void setTrackNum(const unsigned newtracks);

        inline unsigned char numInstruments() const {return num_instruments;}
        inline unsigned char numOrders() const {return num_orders;}
        inline unsigned char numTracks() const {return tracks;}
        inline unsigned char numPatterns() const {return num_patterns;}
        inline unsigned short numWaveEntries() const {return waveEntries;}

        inline unsigned int getBytesPerRow() const {return bytes_per_row;}
        inline unsigned char getInterrowRes() const {return interrow_resolution;}

        inline void setPatternIndexByOrder(unsigned const char &order, const unsigned char &pattern){orders[order] = pattern;}

        inline Pattern *getPattern(unsigned const char &ptrn) const {return patterns[ptrn];}
        inline Pattern *getPatternByOrder(unsigned const char &order) const {return patterns[orders[order]];}
        inline Instrument *getInstrument(unsigned const char &inst) const {return instruments[inst];}
        inline unsigned char getPatternIndexByOrder(unsigned const char &order) const {return orders[order];}


};

#endif
