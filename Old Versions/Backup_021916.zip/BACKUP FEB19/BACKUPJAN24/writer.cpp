#include <ncurses.h>

const unsigned int  WINDOW_META = 1, WINDOW_ROWS = 2;
const unsigned char ROWSEG_NOTE = 1, ROWSEG_INST = 2, ROWSEG_VOL = 3, ROWSEG_FX = 4;
const unsigned char WIN_HEIGHT = 24, WIN_WIDTH = 80;
const unsigned char WINROWS_HEIGHT = 21, WINROWS_WIDTH = 80;
const unsigned char WINMETA_HEIGHT = 3, WINMETA_WIDTH = 80;


unsigned int **data;
unsigned int bytesperrow;
unsigned int rows;
unsigned int channels;

unsigned int selinstr;
unsigned int octave;
unsigned int order;
unsigned int orders;
unsigned int pattern;
unsigned int patterns;


unsigned int viewportrow;
unsigned int viewportchan;
unsigned int selwin;
unsigned int selchan;
unsigned int selrow;
unsigned char selrowseg;

bool chgSelChan(int i)
{
    selchan += i;
    if(selchan >= channels)
        if(i > 0)
        {
            selchan = channels-1;
            if(channels > 4)
            {
                if(selchan - viewportchan > 3)
                    viewportchan = selchan - 2;
            }
        }
        else
        {
            selchan = 0;
            viewportchan=0;
        }
}

bool chgSelRow(int i)
{
    selrow += i;
    if(selrow >= length)
        if(i > 0)
        {
            selrow = length-1;
            viewportrow = selrow - 24;
        }
        else
        {
            selrow = 0;
            viewportrow = 0;
        }
}


bool chgSelRowSeg(int i)
{
    selrowseg += i;
    if(selrowseg >= length)
        if(i > 0)
        {
            selrowseg = ROWSEG_NOTE;
            chgSelChan(1);
        }
        else
        {
            selrowseg = ROWSEG_FX;
            chgSelChan(-1);
        }
}

void input_WINDOW_META(int ch)
{
    switch(ch)
    {
        case KEY_UP:

            break;
        case KEY_DOWN:

            break;
        case KEY_LEFT:

            break;
        case KEY_RIGHT:

            break;
    }
}

void input_WINDOW_ROWS(int ch)
{
    switch(ch)
    {
        case KEY_UP:
            chgSelRow(-1);
            break;
        case KEY_DOWN:
            chgSelRow(1);
            break;
        case KEY_LEFT:
            chgSelRowSeg(-1);
            break;
        case KEY_RIGHT:
            chgSelRowSeg(1);
            break;
    }

}

void renderROWS(WINDOW *window)
{


}


int main()
{
    initscr();
    cbreak();
    noecho();

    length = 64;
    channels = 4;
    data = new unsigned int*[channels];
    for(int i = 0; i < channels; i++)
        data[i] = new unsigned int[length]{0};
    selwin = WINDOW_ROWS;
    selrow = 0;
    selrowseg=1;
    viewportrow=0;
    viewportchan=0;
    selchan=0;
    octave=0;



    clear();
    printw("PLEBTracker [Press any key to coninue] 2016-01-14");
    getch();
    clear();

    WINDOW *mainwin = newwin(24, 80, 0, 0);


    int ch;
    bool running = true;
    while(running)
    {
        ch = wgetch(mainwin);
        if(ch == '`')
        {
            running = false;
            break;
        } else 
        {
            switch(selwin)
            {
                case WINDOW_META:
                    input_WINDOW_META(ch);
                    break;
                case WINDOW_ROWS:
                    input_WINDOW_ROWS(ch);
                    break;
            }
        }


    
    }

    endwin();
    return 0;
}
