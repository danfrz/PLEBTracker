#include "patternedtr.h"

#include <iostream>

void patternedtr::chgSelMetaObj(int i)
{
    selobjmeta += i;
    switch(selrowmeta)
    {
        case 0://First row [N S O NAME TRACKS ROWS RES ? X]
            if(selobjmeta > 8)
                if(i>0)
                    selobjmeta = 8;
                else
                    selobjmeta=0;
            break;
        case 1://Second row [INSTR N C X SEL STEP OCT]
            if(selobjmeta > 6)
                if(i>0)
                    selobjmeta = 6;
                else
                    selobjmeta = 0;
            break;
        case 2: //Third row [ORDER PATTERN v ^ N C X v ^ N C Q X] ...orders...
            if(selobjmeta > 12 + editor::song->numOrders())
                if(i > 0)
                    selobjmeta = 12 + editor::song->numOrders();
                else
                    selobjmeta = 0;
            break;
    }
}

void patternedtr::chgSelMetaRow(int i)
{
    selrowmeta += i;
    if(selrowmeta > 2)
        if(i > 0)
            selrowmeta = 2;
        else
            selrowmeta = 0;
    else
    {
        if(selrowmeta == 0)
            selobjmeta = 1;
        else if(selrowmeta == 1)
            selobjmeta = 4;
        else if(selrowmeta == 2)
            selobjmeta = 0;
    }
}

bool patternedtr::setMetaAttribs(unsigned char objmeta, unsigned char rowmeta)
{
    attroff(-1);
    using namespace patternedtr;
    if(editor::inputwin == editor::metawin)
    {
        attron(A_BOLD);
        if(objmeta == selobjmeta && rowmeta == selrowmeta)
        {
            attron(COLOR_PAIR(COL_META_SSS));
            return true;
        }
        else
            attron(COLOR_PAIR(COL_META_SU));
    }
    else
    {
        if(objmeta == selobjmeta && rowmeta == selrowmeta)
            attron(COLOR_PAIR(COL_META_US));
        else
            attron(COLOR_PAIR(COL_META_UU));
    }
    return false;
}



char *editor::makeUnderlines(char *string, int length)
{
    for(int i = 0; i < length; i++)
    {
        if(string[i] == 0)
            string[i] = '_';
    }
    return string;
}



void patternedtr::displayMeta()
{
    using namespace editor;
    bool isselected;
    //Disable attributes
    attroff(-1);

    //Print Top Bar
    //Row 0
    mvprintw(0, 0, "[NSO] ", metawin);
    mvprintw(0, 35, " TRACKS:", metawin);
    mvprintw(0, 46, " ROWS:", metawin);
    mvprintw(0, 55, " RESOLUTION:", metawin);
    mvprintw(0, 72, "   [? X]", metawin);

    setMetaAttribs(0,0);
    mvprintw(0,1,"N",metawin);
    setMetaAttribs(1,0);
    mvprintw(0,2,"S",metawin);
    setMetaAttribs(2,0);
    mvprintw(0,3,"0",metawin);



    charBuffer[29]=0;
    copy(editor::song->getName(), charBuffer, 29);
    makeUnderlines(charBuffer, 29);
    isselected = setMetaAttribs(3, 0);
    mvprintw(0, 6, charBuffer, metawin);

    //TRACKS
    charBuffer[2] = 0;
    isselected = setMetaAttribs(4, 0);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, editor::song->numTracks());
    mvprintw(0, 43, charBuffer, metawin);

    //ROWS
    isselected = setMetaAttribs(5, 0);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, patternedtr::selptrn->numRows());
    mvprintw(0, 52, charBuffer, metawin);

    //RESOLUTION
    charBuffer[5] = 0;
    isselected = setMetaAttribs(6, 0);
    if(isselected && metaobjedit)
        intString(charBuffer, numBuffer, 5);
    else
        intString(charBuffer, editor::song->getBytesPerRow(), 5);
    mvprintw(0, 67, charBuffer, metawin);


    setMetaAttribs(7,0);
    mvprintw(0,76,"?",metawin);
    setMetaAttribs(8,0);
    mvprintw(0,78,"X",metawin);

    //ROW 1
    //INSTRUMENT
    attroff(-1);
    mvprintw(1, 0, "INSTR ", metawin);
    mvprintw(1, 29, " [NCX] ", metawin);
    //print order //two char hex
    mvprintw(1, 38," STEP:", metawin);
    mvprintw(1, 45, "  OCT :", metawin);
    //print octave //one char hex

    isselected = setMetaAttribs(0, 1);
    copy(editor::selinst->getName(), charBuffer, 23);
    charBuffer[22] = 0;
    mvprintw(1, 6, makeUnderlines(charBuffer,22), metawin); 

    charBuffer[2] = 0;
    isselected = setMetaAttribs(4, 1);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, patternedtr::selinstrument);
    mvprintw(1, 36, charBuffer);

    setMetaAttribs(1,1);
    mvprintw(1,31,"N",metawin);
    setMetaAttribs(2,1);
    mvprintw(1,32,"C",metawin);
    setMetaAttribs(3,1);
    mvprintw(1,33,"X",metawin);


    isselected = setMetaAttribs(5, 1);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, patternedtr::edit_step);
    mvprintw(1, 44, charBuffer+1);

    isselected = setMetaAttribs(6, 1);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        editor::byteString(charBuffer, patternedtr::octave);
    mvprintw(1, 52, charBuffer+1);

    //Row 2
    attroff(-1);
    mvprintw(2, 0, "ORDER [  -  ] [v^ NCX v^ NCWX] -- ", metawin);
    //print cur order and pattern 2 char hex

    //ORDER
    isselected = setMetaAttribs(0,2);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, patternedtr::selorder);
    mvprintw(2,7, charBuffer, metawin);

    //Pattern
    isselected = setMetaAttribs(1,2);
    if(isselected && metaobjedit)
        byteString(charBuffer, numBuffer);
    else
        byteString(charBuffer, song->getPatternIndexByOrder(selorder));
    mvprintw(2,10, charBuffer, metawin);

    setMetaAttribs(2,2);
    mvprintw(2,15,"v",metawin);
    setMetaAttribs(3,2);
    mvprintw(2,16,"^",metawin);
    setMetaAttribs(4,2);
    mvprintw(2,18,"N",metawin);
    setMetaAttribs(5,2);
    mvprintw(2,19,"C",metawin);
    setMetaAttribs(6,2);
    mvprintw(2,20,"X",metawin);


    setMetaAttribs(7,2);
    mvprintw(2,22,"v",metawin);
    setMetaAttribs(8,2);
    mvprintw(2,23,"^",metawin);
    setMetaAttribs(9,2);
    mvprintw(2,25,"N",metawin);
    setMetaAttribs(10,2);
    mvprintw(2,26,"C",metawin);
    setMetaAttribs(11,2);
    mvprintw(2,27,"Q",metawin);
    setMetaAttribs(12,2);
    mvprintw(2,28,"X",metawin);

}
void patternedtr::startMetaEditing()
{

    bool confirmation;
    ///////////////////////
    /////////    BUTTONS///
    ///////////////////////
    if(selrowmeta == 0)
    {
        switch(selobjmeta)
        {
            case 0:
                //New Song ||Button [0,0]

                confirmation = confirm("This will delete any unsaved data");
                if(confirmation)
                    newSong();
                return;
            case 1:
                //Save Song ||Button [0,1]

                confirmation = confirm("Save?");
                if(confirmation)
                {
                    std::ofstream fileout("song.plb");
                    editor::song->output(fileout);
                    fileout.close();

                }

                return;
            case 2:
                //Open Song ||Button [0,2]

                confirmation = confirm("Open?");
                if(confirmation)
                {
                    std::ifstream filein("song.plb");
                    editor::song->input(filein);
                    filein.close();

                    selorder = 0;
                    viewporttrack=0;
                    viewportrow=0;
                    selrow = 0;
                    seltrack=0;
                    selinstrument=0;
                    editor::selinst = editor::song->getInstrument(0);
                    selwavrow=0;
                    instedtr::selvolrow=0;

                    selptrn = editor::song->getPatternByOrder(selorder);


                }
                return;
            case 7:
                //About ||Button [0,7]
                patternedtr::displayAbout();
                return;
            case 8:
                //Exit ||Button [0,8]
                patternedtr::exit();
                return;
        }
    }
    else if(selrowmeta == 1)
    {
        bool success;
        switch(selobjmeta)
        {
            case 0:
                //Instrument Edit ||Big Button [1,0]
                editor::inputwin = editor::instwin;
                editor::wingroup == editor::instwin;
                return;
            case 1:
                //New Instrument ||Button [1,1]
                success = editor::song->newInstrument();
                if(success)
                {
                    selinstrument = editor::song->numInstruments()-1;
                    editor::selinst = editor::song->getInstrument(selinstrument);
                }
                else inform("New Instrument failed, too many instruments");
                return;
            case 2:
                //Clone Instrument ||Button [1,2]
                success = editor::song->cloneInstrument(patternedtr::selinstrument);
                if(success)
                {
                    selinstrument = editor::song->numInstruments()-1;
                    editor::selinst = editor::song->getInstrument(selinstrument);
                }
                else inform("Clone Instrument failed, too many instruments");

                return;
            case 3:
                //Remove Instrument ||Button [1,3]
                success = editor::song->rmvInstrument(patternedtr::selinstrument);
                if(success)
                    selinstrument--;
                else
                    inform("Remove Instrument failed               ");
                //TODO make sure instrument set to valid inst
                return;
        }
    }
    else if(selrowmeta == 2)
    {
        unsigned char sel; 
        bool success;
        switch(selobjmeta)
        {
            case 2:
                //DOWN Order ||Button
                if(selorder > 0)
                {
                    selorder--;
                    selptrn = editor::song->getPattern(editor::song->getPatternIndexByOrder(selorder));

                }

                return;
            case 3:
                //UP Order ||Button
                if(selorder < editor::song->numOrders()-1)
                {
                    selorder++;
                    selptrn = editor::song->getPattern(editor::song->getPatternIndexByOrder(selorder));
                }
                return;
            case 4:
                //New Order ||Button
                //Create a new order with a new pattern
                if(selorder < 255)
                {//TODO make error messages if cant make pattern etc.
                    success = editor::song->newPattern();
                    if (success)
                    {
                        success = editor::song->insertOrder(selorder+1, editor::song->numPatterns()-1);
                        if(success)
                        {
                            selorder++;
                            selptrn = editor::song->getPattern(editor::song->getPatternIndexByOrder(selorder));
                        }

                    }
                }

                return;
            case 5:
                //Clone Order ||Button
                success = editor::song->insertOrder(selorder+1, editor::song->getPatternIndexByOrder(selorder));
                if(success)
                {
                    selorder++;
                    selptrn = editor::song->getPattern(editor::song->getPatternIndexByOrder(selorder));
                }
                return;
            case 6:
                //Remove Order ||Button
                success = editor::song->removeOrder(selorder);
                if(success)
                {
                    if(selorder >= editor::song->numOrders())
                        selorder--;
                    selptrn = editor::song->getPattern(editor::song->getPatternIndexByOrder(selorder));

                }
                return;
            case 7:
                //DOWN Pattern ||Button [2,2]
                sel = editor::song->getPatternIndexByOrder(selorder);
                if(sel > 0)
                {
                    sel--;
                    editor::song->setPatternIndexByOrder(selorder, sel);
                    selptrn = editor::song->getPattern(sel);
                }
                return;
            case 8:
                //UP Pattern ||Button [2,3]
                sel = editor::song->getPatternIndexByOrder(selorder);
                if(sel < editor::song->numPatterns()-1)
                {
                    sel++;
                    editor::song->setPatternIndexByOrder(selorder, sel);		
                    selptrn = editor::song->getPattern(sel);
                }
                return;
            case 9:
                //New Pattern ||Button [2,4]
                success = editor::song->newPattern();
                if(success)
                {
                    unsigned char newpat = editor::song->numPatterns() - 1;
                    editor::song->setPatternIndexByOrder(selorder, newpat);
                    selptrn = editor::song->getPattern(newpat);

                }
                else
                    inform("New Pattern failed, too many patterns");
                return;
            case 10:
                //Clone Pattern ||Button [2,5]
                success = editor::song->clonePattern(editor::song->getPatternIndexByOrder(selorder));
                if(success)
                {
                    unsigned char newpat = editor::song->numPatterns() - 1;
                    editor::song->setPatternIndexByOrder(selorder, newpat);
                    selptrn = editor::song->getPattern(newpat);
                }
                else
                    inform("Clone Pattern failed, too many patterns");

                return;
            case 11:
                //Clear Pattern ||Button [2,6]
                editor::song->clearPattern(editor::song->getPatternIndexByOrder(selorder));
                return;
            case 12:
                //Remove Pattern ||Button [2,7]
                success = editor::song->rmvPattern(editor::song->getPatternIndexByOrder(selorder));

                if(success)
                {

                    //the order changes its patterns to the nearest pattern
                    //update to it
                    selptrn = editor::song->getPatternByOrder(selorder);
                }
                else
                    inform("Remove Pattern failed");
                return;
        }
    }

    ///////////////////////
    /////////  EDITABLES///
    ///////////////////////
    if(selrowmeta == 0)
    {
        if(selobjmeta ==3)
            metaobjedit = true;
        else if(selobjmeta == 4)
        {
            editor::numBuffer = editor::song->numTracks();
            metaobjedit = true;
        }
        else if(selobjmeta == 5)
        {
            editor::numBuffer = selptrn->numRows();
            metaobjedit = true;
        }
        else if(selobjmeta == 6)
        {
            editor::numBuffer = editor::song->getBytesPerRow();
            metaobjedit = true;
        }
    }
    else	if(selrowmeta == 1) 
    {
        if(selobjmeta == 4)//INST SPINNER
        {
            editor::numBuffer = selinstrument;
            metaobjedit = true;
        }
        else if(selobjmeta == 5)
        {
            editor::numBuffer = edit_step;
            metaobjedit = true;
        }
        else if(selobjmeta == 6)
        {
            editor::numBuffer = octave;
            metaobjedit = true;
        }

    }
    else if(selrowmeta == 2)
    {
        if(selobjmeta == 0)
        {
            editor::numBuffer = selorder;
            metaobjedit = true;
        }
        else if(selobjmeta == 1)
        {
            editor::numBuffer = editor::song->getPatternIndexByOrder(selorder);
            metaobjedit = true;
        }
    }

}

void patternedtr::metaEdit(int in)
{
    using namespace editor;
    bool ishex = editor::validateHexChar(in);
    bool isarrow = (in == KEY_LEFT||in==KEY_RIGHT||in==KEY_UP||in==KEY_DOWN);
    bool spinnervalid = ishex || isarrow;
    char hexnum = charHex(in);

    if(selrowmeta == 0)
    {
        switch(selobjmeta)
        {
            case 3:
                //Name ||Textbox [0,3]


                break;
            case 4:
            case 5:
                //Tracks ||Spinner [0,4]
                //Rows ||Spinner [0,5]
                if(!spinnervalid) return;
                switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_LEFT:
                        numBuffer -= 0x10;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_RIGHT:
                        numBuffer += 0x10;
                        break;
                    case KEY_END:
                        numBuffer = 1;
                        break;
                    case KEY_HOME:
                        numBuffer = 255;
                        break;
                    case KEY_DC:
                        numBuffer /= 0x10;
                        break;
                    default:
                        if(ishex)
                        {
                            numBuffer *= 0x10;
                            numBuffer += hexnum;
                        }
                }
                if(numBuffer > 255)
                    numBuffer = 255;
                else if(numBuffer < 1)
                    numBuffer = 1;

                break;
            case 6:
                //Resolution ||UInt Spinner [0,6]
                if(!spinnervalid) return;

                switch(in)
                {
                    case KEY_UP:
                        numBuffer += 0x10;
                        break;
                    case KEY_LEFT:
                        numBuffer -= 0x100;
                        break;
                    case KEY_DOWN:
                        numBuffer -= 0x10;
                        break;
                    case KEY_RIGHT:
                        numBuffer += 0x100;
                        break;
                    case KEY_END:
                        numBuffer = 0x10;
                        break;
                    case KEY_HOME:
                        numBuffer = 0xFFFFF;
                        break;
                    case KEY_DC:
                        numBuffer /= 0x10;
                        break;
                    default:
                        if(ishex)
                        {
                            numBuffer *= 0x10;
                            numBuffer += hexnum;
                        }
                }
                if(numBuffer > 0xFFFFF)
                    numBuffer &= 0xFFFFF;
                else if(numBuffer < 16)
                    numBuffer = 16;
                break;
        }
    }
    else if(selrowmeta == 1)
    {
        if(!spinnervalid) return;
        switch(selobjmeta)
        {
            case 4:
                //Instrument ||Spinner [1,4]

                switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_LEFT:
                        numBuffer -= 8;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_RIGHT:
                        numBuffer += 8;
                        break;
                    case KEY_END:
                        numBuffer = 0;
                        break;
                    case KEY_HOME:
                        numBuffer = song->numInstruments()-1;
                        break;
                    case KEY_DC:
                        numBuffer /= 0x10;
                        break;
                    default:
                        if(ishex)
                        {
                            numBuffer *= 0x10;
                            numBuffer += hexnum;
                        }
                        
                }
                if(numBuffer >= song->numInstruments())
                    numBuffer = song->numInstruments()-1;
                else if(numBuffer < 0)
                    numBuffer = 0;
                break;
            case 5:
                //Step ||Spinner [1,5]

                switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_END:
                        numBuffer = 0;
                        break;
                    case KEY_HOME:
                        numBuffer = 0xF;
                        break;
                    default:
                        if(ishex)
                            numBuffer = hexnum;
                }
                if(numBuffer >= 0xF)
                    numBuffer = 0xF;
                else if(numBuffer < 0)
                    numBuffer = 0;
                break;
            case 6:
                //Octave ||Spinner [1,6]
               
                switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_END:
                        numBuffer = 0;
                        break;
                    case KEY_HOME:
                        numBuffer = 6;
                        break;
                    default:
                        if(ishex)
                            numBuffer = hexnum;
                }
                if(numBuffer >= 7)
                    numBuffer = 6;
                else if(numBuffer < 0)
                    numBuffer = 0;
                break;
        }

    }
    else if(selrowmeta == 2)
    {
        if(!spinnervalid) return;
        switch(selobjmeta)
        {
            case 0:
            case 1:
                //Order Selected ||Spinner [2,0]
                //Pattern Selected ||Spinner [2,1]
            switch(in)
                {
                    case KEY_UP:
                        numBuffer++;
                        break;
                    case KEY_LEFT:
                        numBuffer -= 0x10;
                        break;
                    case KEY_DOWN:
                        numBuffer--;
                        break;
                    case KEY_RIGHT:
                        numBuffer += 0x10;
                        break;
                    case KEY_END:
                        numBuffer = 0;
                        break;
                    case KEY_HOME:
                        numBuffer = 255;
                        break;
                    case KEY_DC:
                        numBuffer /= 0x10;
                        break;
                    default:
                        if(ishex)
                        {
                            numBuffer *= 0x10;
                            numBuffer += hexnum;
                        }
                }
            if(selobjmeta == 0)
            {
                if(numBuffer >= song->numOrders())
                    numBuffer = song->numOrders()-1;
                else if(numBuffer < 0)
                    numBuffer = 0;          
            }
            else if(selobjmeta == 1)
            {
                if(numBuffer >= song->numPatterns())
                    numBuffer = song->numPatterns()-1;
                else if(numBuffer < 0)
                    numBuffer = 0;           
            }

            break;
        }
    }


}

void patternedtr::doneMetaEditing()
{
    using namespace editor;
    if(selrowmeta == 0)
    {
        switch(selobjmeta)
        {
            case 3:
                copy(charBuffer, song->getName(), 29);
                break;
            case 4:
                song->setTrackNum(numBuffer);
                break;
            case 5:
                selptrn->setRowNum(numBuffer);
                break;
            case 6:
                song->setBytesPerRow(numBuffer);
                break;
        }
    }
    else if(selrowmeta == 1)
    {
        switch(selobjmeta)
        {
            case 4:
                selinstrument = numBuffer;
                selinst = song->getInstrument(selinstrument);
                break;
            case 5:
                edit_step = numBuffer;
                break;
            case 6:
                octave = numBuffer;
                break;

        }
    }
    else if(selrowmeta == 2)
    {
        switch(selobjmeta)
        {
            case 0:
                selorder = numBuffer;
                selptrn = song->getPatternByOrder(selorder);
                break;
            case 1:
                song->setPatternIndexByOrder(selorder, numBuffer);
                selptrn = song->getPattern(numBuffer);
                break;
        }
    }
    metaobjedit = false;
}


void patternedtr::processMetaInput(int in)
{
    bool ishex = editor::validateHexChar(in);

    if(!metaobjedit)
    {
        bool hexnum;
        switch(in)
        {
            case KEY_UP:
                chgSelMetaRow(-1);
                break;
            case KEY_DOWN:
                chgSelMetaRow(1);
                break;
            case KEY_LEFT:
                chgSelMetaObj(-1);
                break;
            case KEY_RIGHT:
                chgSelMetaObj(1);
                break;
            case KEY_HOME:
                chgSelMetaObj(-20);
                break;
            case KEY_END:
                chgSelMetaObj(20);
                break;
            case '\n':
                startMetaEditing();
                break;
            default:
                ishex =  editor::validateHexChar(in);
                if(ishex)
                {
                    if( selrowmeta == 0 && selobjmeta == 6 ||
                            selrowmeta == 1 && (selobjmeta == 4 || selobjmeta == 5 || selobjmeta == 6) ||
                            selrowmeta == 2 && (selobjmeta == 0 || selobjmeta == 1)
                      )
                        metaEdit(in);
                }

        }
    }
    else
    {
        if(in == '\n')
            doneMetaEditing();
        else
            metaEdit(in);

    }



}



void patternedtr::inform(const char *message)
{
    mvprintw(3,4,"+---------------------------------+",stdscr);
    mvprintw(4,4,"                                   ",stdscr);
    mvprintw(5,4,message,stdscr);
    mvprintw(6,4,"                                   ",stdscr);
    mvprintw(7,4," Press [Space] to continue         ",stdscr);
    mvprintw(8,4,"+---------------------------------+",stdscr);
    int ch;
    while((ch=getch()) != ' ' && ch != '\n');
    return;
}
bool patternedtr::confirm(const char *message)
{
    mvprintw(3,4,"+---------------------------------+",stdscr);
    mvprintw(4,4,"                                   ",stdscr);
    mvprintw(5,4,message,stdscr);
    mvprintw(6,4,"                                   ",stdscr);
    mvprintw(7,4," Are you sure? [y/n]               ",stdscr);
    mvprintw(8,4,"+---------------------------------+",stdscr);

    int ch;
    while((ch=getch()) != 'y' && ch != 'n' && ch != '\n' && ch != 27);
    if(ch == 'y' || ch == '\n')
        return true;
    return false;
}

void patternedtr::newSong()
{
    delete editor::song;
    editor::selinst = NULL;

    patternedtr::viewporttrack = 0;
    patternedtr::viewportrow = 0;
    patternedtr::seltrack = 0;
    patternedtr::selrow = 0;

    patternedtr::selorder = 0;
    patternedtr::selwavrow = 0;

    editor::song = new Song();
    patternedtr::selinstrument = 0;
    editor::selinst = editor::song->getInstrument(0);
    patternedtr::selptrn = editor::song->getPatternByOrder(0);

}

void patternedtr::saveSong(const char *file)
{

}

void patternedtr::openSong(const char *file)
{

}

void patternedtr::displayAbout()
{
    mvprintw(3,4, "+---------------------------------+",stdscr);
    mvprintw(4,4, "  Welcome to PLEBTracker!       v1 ",stdscr);
    mvprintw(5,4, "                                   ",stdscr);
    mvprintw(6,4, "Press TAB to switch windows        ",stdscr);
    mvprintw(7,4, "                                   ",stdscr);
    mvprintw(8,4, "                                   ",stdscr);
    mvprintw(9,4, "                                   ",stdscr);
    mvprintw(10,4,"                                   ",stdscr);
    mvprintw(11,4,"                                   ",stdscr);
    mvprintw(12,4,"                      -Dan Frazier ",stdscr);
    mvprintw(13,4,"                                   ",stdscr);
    mvprintw(14,4," Press [Space] to continue         ",stdscr);
    mvprintw(15,4,"+---------------------------------+",stdscr);
    int ch;
    while((ch=getch()) != ' ' && ch != '\n');
    return;
}

void patternedtr::exit()
{
    editor::running = false;
}




