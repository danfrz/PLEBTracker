#include <ncurses.h>
#include "tables.h"
#include "instedtr.h"
#include "patternedtr.h"

#include "pattern.h"
#include "instrument.h"
#include "song.h"


#include <iostream>
///////////////INITIALIZIING////////////////
////////////////////////////////////////////
namespace editor
{
    int WIN_HEIGHT, WIN_WIDTH;
    WINDOW *ptrnwin;
    WINDOW *instwin;
    WINDOW *metawin;
    WINDOW *volwin;
    WINDOW *wavewin;
    WINDOW *dialog;

    WINDOW *wingroup;
    WINDOW *inputwin;

    bool running;


    int numBuffer;
    char charBuffer[29];

    Song *song;
    Instrument *selinst;
}

//Pattern Editor
namespace patternedtr
{
    std::map<int,unsigned int> notemap;
    Pattern *selptrn; 
    unsigned char viewporttrack;
    unsigned char viewportrow;

    unsigned char maxtracksviewport;
    unsigned char maxrowsviewport;

    unsigned char selrow;
    unsigned char seltrack;
    unsigned char seltrackseg;
    unsigned char selorder;

    unsigned char selinstrument;
    unsigned char edit_step;
    unsigned char octave;


    unsigned char selwavrow;
    unsigned char selwavseg;

    //METADATA (Main controls)
    unsigned char metaobjindex;
    bool metaobjedit;

    unsigned char selobjmeta;//x
    unsigned char selrowmeta;//y

}

//Instrument Edtior
namespace instedtr
{
    unsigned char selvolrow;
    bool selvolseg;
}
/////////////DONE INITIALIZING/////////////
///////////////////////////////////////////

bool editor::validateHexChar(char a)
{
    if(a >= 'a')
        a -= 32;
    return(a <= '9' && a >= 0 || a >= 'A' && a <= 'F');
}

bool editor::validateByte(char str[2])
{


}

bool editor::validate64(char str[2])
{
    //values < 64 have to start with 0 to 3
    //invalid ascii characters are filterred
    return str[0] < '4' && str[0] >= '0' && validateHexChar(str[1]);
} 
unsigned char editor::charHex(char c)
{
    if(c<='9' && c>='0')
        return c-'0';
    if(c >= 'a')
        c -= 32;
    if(c>='A' && c <= 'F')
        return c-55;
    return -1;
}

unsigned char editor::parseHexChar(char str[2])
{
    //values < 64 have to start with 0 to 3
    //invalid ascii characters are filterred
    unsigned char out = charHex(str[0])*0x10;
    out + charHex(str[1]);
    return out;
}

int main()
{
    initscr();
    raw();
    start_color();
    noecho();

    clear();
    printw("PLEBTracker [Press any key to continue] 20160114-20160121");
    curs_set(0);
    getch();
    clear();

    {
        using namespace patternedtr;
        //META color mappings
        init_pair(COL_META_SSS, COLOR_YELLOW, COLOR_CYAN);
        init_pair(COL_META_SSU, COLOR_BLUE  , COLOR_CYAN);
        init_pair(COL_META_SU , COLOR_BLACK , COLOR_BLUE);
        init_pair(COL_META_US , COLOR_CYAN  , COLOR_BLACK);
        init_pair(COL_META_UU , COLOR_BLUE  , COLOR_BLACK);

        //PATTERN color mappings
        init_pair(COL_PTRN_SSS      , COLOR_YELLOW, COLOR_CYAN);

        init_pair(COL_PTRN_SSU_NOTE , COLOR_BLACK, COLOR_BLUE);
        init_pair(COL_PTRN_SSU_INST , COLOR_BLACK, COLOR_BLUE);
        init_pair(COL_PTRN_SSU_VOL  , COLOR_GREEN, COLOR_BLUE);
        init_pair(COL_PTRN_SSU_FX   , COLOR_MAGENTA, COLOR_BLUE);
        init_pair(COL_PTRN_SSU_SYSFX, COLOR_RED, COLOR_BLUE);

        init_pair(COL_PTRN_SU_NOTE  , COLOR_WHITE, COLOR_BLACK);
        init_pair(COL_PTRN_SU_INST  , COLOR_WHITE, COLOR_BLACK);
        init_pair(COL_PTRN_SU_VOL   , COLOR_GREEN, COLOR_BLACK);
        init_pair(COL_PTRN_SU_FX    , COLOR_YELLOW, COLOR_BLACK);
        init_pair(COL_PTRN_SU_SYSFX , COLOR_RED, COLOR_BLACK);

        init_pair(COL_PTRN_US       , COLOR_CYAN, COLOR_BLACK);
        init_pair(COL_PTRN_UU       , COLOR_BLUE, COLOR_BLACK);

    }













    //INITIALIZE EXTERNAL IDENTIFIERS

    getmaxyx(stdscr, editor::WIN_HEIGHT, editor::WIN_WIDTH);
    editor::metawin = newwin(3, editor::WIN_WIDTH,                       0, 0);
    editor::ptrnwin = newwin(editor::WIN_HEIGHT-3, editor::WIN_WIDTH-11, 3, 0);
    editor::instwin = newwin(editor::WIN_HEIGHT, editor::WIN_WIDTH,      0, 0);
    editor::wavewin = newwin(editor::WIN_HEIGHT-5, 10,                   3, editor::WIN_WIDTH-10);
    editor::dialog  = newwin(8, 60,             editor::WIN_HEIGHT/3, editor::WIN_WIDTH/3); //good enough
    editor::song = new Song();
    editor::selinst = editor::song->getInstrument(0);

    editor::wingroup = editor::ptrnwin;
    editor::inputwin = editor::metawin;

    patternedtr::populateNoteMap();
    patternedtr::selptrn = editor::song->getPattern(0);
    patternedtr::viewporttrack = 0;
    patternedtr::viewportrow = 0;

    patternedtr::maxtracksviewport = (editor::WIN_WIDTH-11) / 15;
    patternedtr::maxrowsviewport = (editor::WIN_HEIGHT-3);

    patternedtr::selrow = 0;
    patternedtr::seltrack = 0;
    patternedtr::seltrackseg = 0;
    patternedtr::selorder = 0;

    patternedtr::selinstrument = 0;
    patternedtr::edit_step = 1;
    patternedtr::octave = 3;

    patternedtr::selwavrow = 0;
    patternedtr::selwavseg = 0;


    patternedtr::metaobjindex = 0;
    patternedtr::metaobjedit = false;
    patternedtr::selobjmeta = 3;
    patternedtr::selrowmeta = 0;

    keypad(stdscr, 1);
    keypad(editor::metawin, 1);
    keypad(editor::ptrnwin, 1);
    keypad(editor::instwin, 1);
    keypad(editor::wavewin, 1);
    keypad(editor::dialog, 1);

    patternedtr::display();
    int ch;
    editor::running = true;
    while(editor::running)
    {
        ch = getch();


        if(ch == '`')
        {
            //prompt!
            editor::running = false;
            break;
        } else if(ch == '\t')
        {
            using namespace editor;

            if(patternedtr::metaobjedit)
            {
                patternedtr::metaobjedit = false;
            }
            else
            {

                mvprintw(WIN_HEIGHT-1, 0, "[m]eta [p]trn [i]nst [w]avetbl [v]oltbl", stdscr);
                while(ch == '\t')
                    ch = getch();
                switch(ch)
                {
                    case 'i':
                        //Instrument view

                        inputwin = instwin;
                        wingroup = instwin;
                        instedtr::display();

                        break;
                    case 'm':
                        //Meta / Menu : Pattern View

                        inputwin = metawin;
                        wingroup = ptrnwin;
                        patternedtr::display();

                        break;
                    case 'p':
                        //Pattern View

                        inputwin = ptrnwin;
                        wingroup = ptrnwin;
                        patternedtr::display();

                        break;
                    case 'w':
                        //Wave : Pattern View -- Wave : Instrument View
                        inputwin = wavewin;
                        if(wingroup == ptrnwin)
                        {
                            patternedtr::display();
                        }
                        else if(wingroup == instwin)
                        {
                            instedtr::display();
                        }
                        else
                        {
                            wingroup = instwin;
                            instedtr::display();
                        }

                        break;
                    case 'v':
                        //Volume : Instrument View
                        inputwin = volwin;
                        wingroup = instwin;
                        instedtr::display();
                        break;
                }
            }

        }
        else
        {
            using namespace editor;



            if(wingroup == ptrnwin)
            {
                patternedtr::processInput(ch);
                patternedtr::display();
            }
            else if(wingroup == instwin)
            {
                instedtr::display();
            }
        }



    }
    delete editor::song;

    endwin();
    return 0;
}
