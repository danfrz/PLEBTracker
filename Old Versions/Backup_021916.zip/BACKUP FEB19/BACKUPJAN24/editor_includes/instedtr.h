#ifndef INSTEDTR_H_
#define INSTEDTR_H_
#include <ncurses.h>
#include "tables.h"

namespace instedtr
{
    void display();
    void processInput(int in);
    bool validateByte(char str[2]);
    bool validate64(char str[2]);


}


#endif
