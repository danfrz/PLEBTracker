#ifndef PATTERNEDTR_H_
#define PATTERNEDTR_H_
#include <fstream>
#include "instrument.h"
#include "pattern.h"
#include "song.h"
#include "tables.h"

namespace patternedtr
{
    void display();
    void displayMeta();
    void displayPattern();

    void processMetaInput(int in);
    void processPatternInput(int in);
    void processInput(int in);

    void chgSelTrack(int i);
    void chgSelRow(int i);
    void chgSelRowSeg(int i);

    void chgSelWavRow(int i);
    void chgSelWavSeg(int i);

    void chgSelMetaObj(int i);
    void chgSelMetaRow(int i);

    bool setMetaAttribs(unsigned char objmeta, unsigned char rowmeta);
    void setPatternAttribs(unsigned char track, unsigned char row, unsigned char seg);

    char *makeSpaceBuffer(char *bfr, int length);

    void startMetaEditing();
    void metaEdit(int in);
    void doneMetaEditing();


    void inform(const char *message);
    bool confirm(const char *message);
    void newSong();
    void saveSong(const char *file);
    void openSong(const char *file);
    void displayAbout();
    void exit();

    void newInstrument();
    void cloneInstrument();
    void removeInstrument();

    void newPattern();
    void clonePattern();
    void clearPattern();
    void removePattern();


    
}





#endif
