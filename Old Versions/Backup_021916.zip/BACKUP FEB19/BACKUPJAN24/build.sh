g++ src/*.cpp editor/*.cpp -Iincludes -Ieditor_includes -lncurses --std=c++11  -o PLEBTracker > buildlog.log 2> buildlog.log;
less buildlog.log
