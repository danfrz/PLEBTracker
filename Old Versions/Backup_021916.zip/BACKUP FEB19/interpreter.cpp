#include "interpreter.h"
#include <iostream>




/***\//////////////////////////////////////////////////////////////////////////    
Function: void printByte(uchar &b, const char &character, const uchar &res

Description:
   Prints a single byte to cout
   using the specified character
   where each character represents 'res' (resolution) units
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
void itrp::printByte(unsigned char &b, const char &character, const unsigned char &res)
{
    while(b > res)
    {
        std::cout << character;
        b-=res;
    }
    std::cout << character << '\n';
}


/***\//////////////////////////////////////////////////////////////////////////    
Function: void printBuffer(unsigned char *bfr, const unsigned long &len

Description:
   Prints a whole buffer to the console
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
void itrp::printBuffer(unsigned char *bfr, const unsigned long &len)
{
    for(unsigned long i = 0; i < len; i++)
        printByte(bfr[i], '#', 4);
}

void printWaveTable(unsigned short *tbl, unsigned short entries)
{
    for(unsigned int i = 0; i < entries; i++)
        std::cout << std::hex << tbl[i] << '\n';

}

void itrp::play(unsigned char **buffer, const unsigned int orders, unsigned int *bytes)
{
   // std::cerr << "playing\n";

    for(unsigned int orderi = 0; orderi < orders; orderi++)
    {
        
        unsigned char *order = buffer[orderi];
        //std::cerr << int(curpattern->numRows()) << " ? " << song->getBytesPerRow() <<'\n';
        //std::cerr << "playing order " << orderi << ' ' << bytes << " bytes\n";

        for(unsigned int i = 0; i < bytes[orderi]; i++)
            putchar(order[i]);
        //std::cerr << int(order[i]) << ' ';
        
    }

}

void itrp::print(unsigned char **buffer, const unsigned int orders, unsigned int *bytes)
{
    std::cerr << "printing\n";

    for(unsigned int orderi = 0; orderi < orders; orderi++)
    {
        
        unsigned char *order = buffer[orderi];
        curpattern = song->getPatternByOrder(orderi);
        std::cerr << int(curpattern->numRows()) << " ? " << song->getBytesPerRow() <<'\n';
        std::cerr << "playing order " << orderi << ' ' << bytes << " bytes\n";

        printBuffer(order, bytes[orderi]);
        //for(unsigned int i = 0; i < bytes; i++)
        //    std::cerr << int(order[i]) << ' 
        
    }

}


void itrp::play(unsigned char *buffer, unsigned int bytes)
{
    for(unsigned int i = 0; i < bytes; i++)
        putchar(buffer[i]);
}


void itrp::renderTick(unsigned char *buffer, const unsigned char &track, const unsigned int &bytes)
{
    //std::cerr << "renderTick0\n";
    Track *seltrk = &tracks[track];
    //std::cerr << "renderTick1 voli=" << std::hex << int(seltrk->voli) << " volduracc=" << int(seltrk->volduracc) << " lastvol=" << int(seltrk->lastvol) <<  "\n";
    if(seltrk->inst == NULL)
        return;
    unsigned char amp = seltrk->inst->getVolume(seltrk->voli, seltrk->volduracc, seltrk->lastvol);
    seltrk->volduracc++;

    //std::cerr << "renderTick2 getVolume=" << int(amp) << " ptrnvol=" << int(seltrk->ptrnvol) <<"\n";
    amp *= seltrk->ptrnvol / 63.0f;

    //interpolate pitch
    //seltrk->frq;
    
    float frq = seltrk->frq;

    unsigned short _wav = song->getWaveEntry(seltrk->wavei);
    if((_wav & 0xF000) == 0xF000)
    {
        while((_wav & 0xF000) == 0xF000)
        {
            unsigned char cmd = (_wav & 0x0F00) >> 8;
            if(cmd == 0xF) //FF, JUMP
            {
                if(seltrk->wavei < 0xFFFF)
                {
                    unsigned short nxtwav = song->getWaveEntry(seltrk->wavei + 1);
                    if((nxtwav & 0xFF00) == 0xFF00)
                    {
                        seltrk->wavei = ((_wav & 0x00FF) << 8) | (nxtwav & 0x00FF);
                        _wav = song->getWaveEntry(seltrk->wavei);
                    }
                    else
                    {
                        seltrk->wavei = _wav & 0x00FF;
                        _wav = song->getWaveEntry(seltrk->wavei);
                    }
                }
                else
                {
                    seltrk->wavei = _wav & 0x00FF;
                    _wav = song->getWaveEntry(seltrk->wavei);
                }
                
            } else if(cmd == 0xB) //Set loop Counter
            {
                seltrk->ptbl[4] = _wav & 0xFF;
                seltrk->wavei++;
                _wav = song->getWaveEntry(seltrk->wavei);
            } else if(cmd == 0xC) //decrement loop ctr, jump if != 0
            {
                seltrk->ptbl[4]--;
                if(seltrk->ptbl[4]!=0)
                {

                    //jump 
                    if(seltrk->wavei < 0xFFFF)
                    {
                    
                        unsigned short nxtwav = song->getWaveEntry(seltrk->wavei + 1);
                        if((nxtwav & 0xFF00) == 0xFC00)
                        {
                            seltrk->wavei = ((_wav & 0x00FF) << 8) | (nxtwav & 0x00FF);
                            _wav = song->getWaveEntry(seltrk->wavei);
                        }
                        else
                        {
                            seltrk->wavei = _wav & 0x00FF;
                            _wav = song->getWaveEntry(seltrk->wavei);
                        }
                    }
                    else
                    {
                        seltrk->wavei = _wav & 0x00FF;
                        _wav = song->getWaveEntry(seltrk->wavei);
                    }
                }
                else
                {
                    if(seltrk->wavei < 0xFFFF)
                    {
                        unsigned short nxtwav = song->getWaveEntry(seltrk->wavei + 1);
                        if((nxtwav & 0xFF) == 0xFC)
                            seltrk->wavei+=2;
                        else
                            seltrk->wavei++;
                    }
                    else
                        seltrk->wavei++;

                    _wav = song->getWaveEntry(seltrk->wavei);
                }
            
            } else if(cmd == 0x0) //F0, SET PULSE 
            {
                ((unsigned short*)seltrk->ptbl)[0] = (_wav & 0x00FF) << 8;

                seltrk->wavei++;
                _wav = song->getWaveEntry(seltrk->wavei);
            } else if(cmd == 0x1) //F1, ADD PULSE 
            {
                ((short*)seltrk->ptbl)[0] += static_cast<char>(_wav & 0x00FF)*0x10; //shift once to the left

                seltrk->wavei++;
                _wav = song->getWaveEntry(seltrk->wavei);
            } else if(cmd == 0xD) //FD, SET CUSTOM JUMP
            {
                if(seltrk->wavei < 0xFFFF)
                {
                    unsigned short nxtwav = song->getWaveEntry(seltrk->wavei + 1);
                    if((nxtwav & 0xFF00) == 0xFD00)
                    {
                        ((unsigned short*)seltrk->ptbl)[1] = ((_wav & 0x00FF) << 8) | (nxtwav & 0x00FF);
                        seltrk->wavei++;
                    }
                    else
                        ((unsigned short*)seltrk->ptbl)[1] = (_wav & 0x00FF);
                }
                else
                    ((unsigned short*)seltrk->ptbl)[1] = (_wav & 0x00FF);

                seltrk->wavei++;
                _wav = song->getWaveEntry(seltrk->wavei);
            } else if(cmd == 0xE) //FE, JUMP CUSTOM JUMP
            {
                seltrk->wavei = ((unsigned short*)seltrk->ptbl)[1] + (_wav & 0xFF);
                _wav = song->getWaveEntry(seltrk->wavei);
            }


        }
    }
    else
    {
        unsigned char params = (_wav & 0x00FF);
        if(params)
        {
            if(params < 0x40)
                frq /= std::pow(NOTEMULT, params);
            else
            {
                params = ~params + 1;
                frq *= std::pow(NOTEMULT, params);
            }
        
        }
    }
    if(frq < 1)
        frq = 1;
    seltrk->wavei++;




    unsigned char waveform = (_wav & 0xFF00) >> 8;

    //Maintain phase only in similar waveforms
    //because the different generators use phase differently
    //at the moment
    if(seltrk->lastwave != waveform)
        seltrk->phase = 0;
    //std::cerr << "renderTick 3 amp=" << int(amp) << ", wav="  << _wav << "h frq=" << frq <<  " bytes=" << bytes << " phase=" << seltrk->phase << " pos=" << (int*)buffer << "\n" ;

    generators[waveform](buffer, seltrk->ptbl,  frq, amp, seltrk->phase, bytes);
    seltrk->lastwave =  waveform;
    //play(buffer, bytes);
    //std::cerr << "renderTick END\n";
}

void itrp::initializeWaveTable()
{
    generators = new generator[256];
    generators[0] = genSilence;

    for(int i = 4; i < 256; i++)
        generators[i] = genSilence;

    //BASIC WAVE FORMS!
    generators[0x01] = genSqr;
    generators[0x02] = genTri;
    generators[0x03] = genSaw;
    generators[0x04] = genSine;

    //NOISE
    generators[0x05] = genNoise_White;

    //PULSE WAVE FORMS
    generators[0x06] = genSqrPulse;
    generators[0x07] = genTriPulse;
    generators[0x08] = genSawPulse;



    //PERCUSSION
    generators[0x20] = genBongo;

    
}





void itrp::initializeRender()
{
    order = 0;
    curpattern = song->getPatternByOrder(0);
    for(int i = 0; i < song->numTracks(); i++)
    {
        unsigned int firstrow = curpattern->at(i,0);
        tracks[i].frq = 1;
        if(((firstrow & R_INSTRUMENT) >> RI_INSTRUMENT) < song->numInstruments())
            tracks[i].inst = song->getInstrument((firstrow & R_INSTRUMENT) >> RI_INSTRUMENT);
        else
            tracks[i].inst = NULL;
        if(tracks[i].inst != NULL)
        {
            tracks[i].wavei = tracks[i].inst->getWaveIndex();
            tracks[i].voli = tracks[i].inst->getVolEntry(0);
        }

        tracks[i].ptbl = new unsigned char[15];

        tracks[i].ptrnvol = (firstrow & R_VOLUME) >> RI_VOLUME;

        tracks[i].waveduracc = 0;
        tracks[i].volduracc = 0;
        tracks[i].lastvol = 0;
    }
    //std::cerr << "initialized render\n";
}

unsigned char *itrp::renderPattern(int start, int end, unsigned int &bytes)
{

    unsigned int row;
    //PLEASE choose a subdiv that divides bytesperrow
    const unsigned short bytesperrow = song->getBytesPerRow();
    const unsigned char  subdiv = song->getInterrowRes();
    const unsigned short segment = bytesperrow / subdiv;

    //std::cerr << "renderSong0 orders:" << int(song->numOrders()) <<" \n";

    unsigned char _oct;
    unsigned char _note;
    unsigned char _inst;

    unsigned char _vol;
    unsigned char _fx;
    unsigned char _fxp1;
    unsigned char _fxp2;
    unsigned short _wav;
    Track *seltrk;


    if(end < start)
        end = curpattern->numRows();
    int rows = end - start;
    bytes = rows*bytesperrow;

    unsigned char *buffer = new unsigned char[bytes];
    for(int i = 0; i < bytes; i++)
        buffer[i]=127;
    for(unsigned int tracki = 0; tracki < song->numTracks(); tracki++)
    {
        //if track muted, go to next track
        if(trackmute[tracki])
            continue;

        //track not muted,

        seltrk = &tracks[tracki];
        //std::cerr << "renderSong2 track=" << tracki << '\n';

        for(unsigned int rowi = start; rowi < end; rowi++)
        {
            //std::cerr << "renderSong3    row=" << rowi << '\n';
            row = curpattern->at(tracki, rowi);

            if((row & R_EMPTY) != R_EMPTY) //FULLSEG AND VOLUME
            {
                if((row & R_FULLSEG) != R_FULLSEG) // PITCHSEG AND INST
                {
                    if((row & R_PITCHSEG) != R_PITCHSEG) //OCTAVE AND NOTE
                    {
                        //std::cerr << "pitch";
                        _oct  = (row & R_OCTAVE) >> RI_OCTAVE;
                        _note = (row & R_NOTE) >> RI_NOTE;
                        seltrk->frq = BASEFRQ/std::pow(NOTEMULT, 12*_oct+_note);
                    }

                    if((row & R_INSTRUMENT) != R_INSTRUMENT)
                    {
                        //std::cerr << " inst";

                        _inst = (row & R_INSTRUMENT) >> RI_INSTRUMENT;
                        seltrk->inst = song->getInstrument(_inst);
                        _wav = seltrk->inst->getWaveIndex();
                        seltrk->wavei = _wav;
                        seltrk->waveduracc = 0;
                        seltrk->voli = 0;
                        seltrk->volduracc = 0;
                        seltrk->lastvol = (seltrk->inst->getVolEntry(0) & 0xFF00) >> 8;

                    }

                    _vol  = (row & R_VOLUME) >> RI_VOLUME;
                    seltrk->ptrnvol = _vol;
                    //std::cerr << " vol lastvol=" << (int)seltrk->lastvol;
                }
                else
                {
                    if((row & R_VOLUME) != R_VOLUME)
                    {
                        _vol  = (row & R_VOLUME) >> RI_VOLUME;
                        seltrk->ptrnvol = _vol;
                        //std::cerr << "vol lastvol=" << (int)(seltrk->lastvol);
                    }
                }
                //std::cerr << '\n';

            }

            if(row & R_EFFECTSEG) // Handle effects seperately
            {
                _fx = (row & R_EFFECT) >> RI_EFFECT;
                if(_fx == 8)
                { 
                    _fxp1 = row & R_FXPARAM;
                    ((unsigned short*)seltrk->ptbl)[0] = (((unsigned short)_fxp1)<< 8); //oh dear.
                }



            }


            //std::cerr << "renderSong4 starting segloop subdiv=" << int(subdiv) << " segment=" << segment << '\n';
            for(unsigned int subi = 0; subi < subdiv; subi++)
            {
                renderTick(buffer + (rowi - start)*bytesperrow + subi*segment,  tracki, segment);
            }
        }
    }
    return buffer;
}

unsigned char **itrp::renderSong(unsigned int *bytes)
{
    
    //std::cerr << "renderSong creating buffers \n";

    unsigned char **buffers = new unsigned char*[song->numOrders()];
    //std::cerr << "renderSong1\n";
    for(unsigned int orderi = 0; orderi < song->numOrders(); orderi++)
    {
        curpattern = song->getPatternByOrder(orderi);
        unsigned char *buffer = renderPattern(0, curpattern->numRows(), bytes[orderi]);
        buffers[orderi] = buffer;
    }
    //std::cerr << "renderSong END\n";
    return buffers;
}


bool itrp::load(const char *file)
{
    std::ifstream infile;

    infile.open(file);
    if(!infile)
        return false;
    song = new Song(infile);
    infile.close();
    tracks = new Track[song->numTracks()];
    return true;
}


void itrp::purgeSong()
{
    for(int i = 0; i < song->numTracks(); i++)
        delete [] tracks[i].ptbl;
    delete song;
    delete [] tracks;
    delete [] generators;
    //delete buffer
}




void testWaveTable()
{
    itrp::initializeWaveTable();

    int waves = 5;
    int bytes = 100000;
    int step = bytes / waves / 16;


    unsigned char *bfr = new unsigned char[bytes];
    for(int i = 0; i < waves; i++)
    {
        float phase = 0;
        generator g = itrp::generators[i];
        g(bfr+i*16*step         , NULL,  64, 75, phase, step);
        g(bfr+i*16*step + step  , NULL, 32, 75, phase, step);
        g(bfr+i*16*step + step*2, NULL, 16, 75, phase, step);
        g(bfr+i*16*step + step*3, NULL, 64, 75, phase, step);
        g(bfr+i*16*step + step*4, NULL, 64, 75, phase, step);
        g(bfr+i*16*step + step*5, NULL, 32, 75, phase, step);
        g(bfr+i*16*step + step*6, NULL, 16, 75, phase, step);
        g(bfr+i*16*step + step*7, NULL, 64, 75, phase, step);
        g(bfr+i*16*step + step*8, NULL, 64, 75, phase, step);
        g(bfr+i*16*step + step*9, NULL, 32, 75, phase, step);
        g(bfr+i*16*step + step*10, NULL, 16, 75, phase, step);
        g(bfr+i*16*step + step*11, NULL, 64, 75, phase, step);
        g(bfr+i*16*step + step*12, NULL, 64, 75, phase, step);
        g(bfr+i*16*step + step*13, NULL, 32, 75, phase, step);
        g(bfr+i*16*step + step*14, NULL, 16, 75, phase, step);
        g(bfr+i*16*step + step*15, NULL, 64, 75, phase, step);
    }
    itrp::play(bfr, bytes);
    //itrp::printBuffer(bfr, bytes);
    delete [] bfr;

}




void testLoadWholeSong()
{
    //Load the song
    if(!itrp::load("song.plb"))
    {
        //Didn't load
        std::cerr << "song.plb could not be found.";
    }

    //printWaveTable(itrp::song->getWaveTable(), 10);

    itrp::initializeWaveTable();
    //std::cerr << "main1 initialized wave table\n";
    itrp::initializeRender();
    //std::cerr << "main2 initialized render\n";

    unsigned int *bytes = new unsigned int[itrp::song->numOrders()];
    unsigned char **bfrs = itrp::renderSong(bytes);
    //std::cerr << "main3 finished render!\n";

    itrp::play(bfrs, itrp::song->numOrders(),  bytes);
    //itrp::print(bfrs, itr[::song->numOrders(), bytes);
    for(int i = 0; i < itrp::song->numOrders(); i++)
        delete [] bfrs[i];
    delete [] bfrs;

    //std::cerr << "main4 deleted buffers, deleting song\n";

    itrp::purgeSong();
}

unsigned char **itrp::renderSong(unsigned int *bytes, int start_order, int end_order, int start_row, int end_row)
{
    if(end_row >= 0)
    {
        //Only play start order
        unsigned char **buffers = new unsigned char*[1];
        curpattern = song->getPatternByOrder(start_order);
        unsigned char *buffer = renderPattern(start_row, end_row, bytes[0]);
        buffers[0] = buffer;
        return buffers;
    }
    else
    {
        //play through order
        int orders = end_order - start_order + 1;
        unsigned char **buffers = new unsigned char*[orders];

        int bfri = 0;
        for(unsigned int orderi = start_order; orderi <= end_order; orderi++)
        {
            curpattern = song->getPatternByOrder(orderi);
            unsigned char *buffer = renderPattern(start_row, curpattern->numRows(), bytes[bfri]);
            start_row = 0;
            buffers[bfri] = buffer;
            bfri++;
        }
        return buffers;
    }

}

void parseParams(int argc, const char* argv[])
{

    int start_order = 0;
    int start_row = 0;
    int end_order = itrp::song->numOrders()-1;
    int end_row = -1;
    for(int i = 0; i < 256; i++)
        itrp::trackmute[i] = 0;

    for(int i = 0; i < argc; i++)
    {
        if(strcmp(argv[i], "order") == 0)
        {
            if(++i < argc)
            {
                start_order = atoi(argv[i]);
            }
            else
                std::cerr << "erm what order then?\n";
        }
        else if(strcmp(argv[i], "endorder") == 0)
        {
            if(++i < argc)
            {
                end_order = atoi(argv[i]);
            }
            else
                std::cerr << "erm what order then?\n";
        }
        else if(strcmp(argv[i], "row") == 0)
        {
            if(++i < argc)
            {
                start_row = atoi(argv[i]);
            }
            else
                std::cerr << "erm what row then?\n";
        }
        else if(strcmp(argv[i], "endrow") == 0)
        {
            if(++i < argc)
            {
                end_row = atoi(argv[i]);
            }
            else
                std::cerr << "erm what row then?\n";
        }



    }
    



    unsigned int *bytes;
    int orders;

    if(start_order < 0)
        start_order = 0;
    if(start_order >= itrp::song->numOrders())
        start_order = itrp::song->numOrders() - 1;

    if(end_row > 1)
    {
        orders = 1;
        bytes = new unsigned int[1];
        end_order = start_order;
    }
    else
    {
        bytes = new unsigned int[orders];
        if(end_order < start_order)
            end_order = start_order;
        else if(end_order >= itrp::song->numOrders())
            end_order = itrp::song->numOrders()-1;

        orders = end_order - start_order+1;
    }

    
    unsigned char **bfrs = itrp::renderSong(bytes, start_order, end_order, start_row, end_row);
    std::cerr << "BYTES " << bytes[0] << '\n';
    itrp::play(bfrs, orders, bytes);
    //itrp::print(bfrs, orders, bytes);

    for(int i = 0; i < orders; i++)
        delete [] bfrs[i];
    delete [] bfrs;
    delete [] bytes;

    //std::cerr << "main4 deleted buffers, deleting song\n";

    itrp::purgeSong();

}

void playSong(const char *path)
{
    itrp::initializeWaveTable();
    itrp::initializeRender();


}



int main(int argc, const char* argv[])
{ 
    if(argc > 1)
    {
        itrp::load(argv[1]);
        itrp::initializeWaveTable();
        itrp::initializeRender();

        //Has parameters
        parseParams(argc, argv);
    }
    else
        testLoadWholeSong();



}






