#./PLEBInterpreter 2>./runlog.log | aplay --rate=32000


./PLEBInterpreter 2>./runlog.log "$@" | aplay --rate=44100


