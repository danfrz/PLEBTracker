#ifndef TABLES_H_
#define TABLES_H_
#include <map>
#include <cstring>
#include <ncurses.h>
#include "song.h"
#include "instrument.h"

#define TRACK_WIDTH 15


namespace editor
{
    extern int WIN_HEIGHT, WIN_WIDTH;
    extern WINDOW *metawin;
    extern WINDOW *ptrnwin;
    extern WINDOW *instwin;
    extern WINDOW *volwin;
    extern WINDOW *wavewin;
    extern WINDOW *dialog;


    extern WINDOW *wingroup;
    extern WINDOW *inputwin;
    extern WINDOW *lastwin;
    extern bool running;

    extern Song *song;
    extern Instrument *selinst;

    extern int numBuffer;
    extern char charBuffer[29];
    extern char textCursorPos;
    extern char charInputBuffer[29];
    extern char lastSongPath[64];
    const char hexnums[17] = "0123456789ABCDEF";

    char *makeUnderlines(char *string, int length);
    char *noteString(char *string, unsigned int entry);
    char *byteString(char *string, const unsigned char byte);
    char *shortString(char *string, unsigned short shrt, const unsigned int &strlen);
    char *intString(char *string,  unsigned int integer, const unsigned int &strlen);
    char *instString(char *string, const unsigned int &entry);
    char *volString(char *string, const unsigned int &entry);
    char *fxString(char *string, const unsigned int &entry);
    char *fxpString(char *string, const unsigned int &entry);
   

    /***\//////////////////////////////////////////////////////////////////////////    
Function: void inform(const char *message)

  Description:
Shows an information message to the user
This method blocks processing until Space is pressed
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void inform(const char *message);



    /***\//////////////////////////////////////////////////////////////////////////    
Function: bool confirm(const char *message)

  Description:
Thows a confirmation message to the user
This method blocks processing until y/n is pressed
and returns the result y(1), n(0)
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    bool confirm(const char *message);


/***\//////////////////////////////////////////////////////////////////////////    
Function: void displayAbout()

Description:
   Displays the about window to the user until Space is pressed
*////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\___///
    void displayAbout();

    const char *locateFile(bool save);

    void copy(char *src, char *dest, int len);
    bool validateHexChar(char a);
    bool validateByte(char str[2]);
    bool validate64(char str[2]);
    unsigned char charHex(char c);
    unsigned char parseHexChar(char str[2]);

}

//Pattern Editor
namespace patternedtr
{

    //PATTERN TABLE
    const unsigned char
        TRKSEG_NOTE = 0,
        TRKSEG_INST = 1,
        TRKSEG_VOL = 2,
        TRKSEG_FX = 3,
        TRKSEG_FXP = 4;

    //Window, Object, Segment selected
    //[S]elected or [U]nselected
    const unsigned char
        COL_META_SSS = 1,
        COL_META_SSSE = 6,
        COL_META_SSU = 2,
        COL_META_SU  = 3,
        COL_META_US  = 4,
        COL_META_UU  = 5,
        COL_META_ERR  = 7,
        COL_META_SSS_ERR  = 21;

    const unsigned char
        COL_PTRN_SSS = 8,
        COL_PTRN_SSU_NOTE = 9,
        COL_PTRN_SSU_INST = 10,
        COL_PTRN_SSU_VOL = 11,
        COL_PTRN_SSU_FX = 12,
        COL_PTRN_SSU_SYSFX = 13,
        COL_PTRN_SU_NOTE  = 14,
        COL_PTRN_SU_INST  = 15,
        COL_PTRN_SU_VOL  = 16,
        COL_PTRN_SU_FX  = 17,
        COL_PTRN_SU_SYSFX  = 18,
        COL_PTRN_US  = 19,
        COL_PTRN_UU  = 20;


    void populateNoteMap();
    extern std::map<int, unsigned int> notemap;
    extern Pattern *selptrn;
    extern unsigned char viewporttrack;
    extern unsigned char viewportrow;

    extern unsigned char maxorderlistviewport;
    extern unsigned char maxtracksviewport;
    extern unsigned char maxrowsviewport;

    extern unsigned char selrow;
    extern unsigned char seltrack;
    extern unsigned char seltrackseg;
    extern unsigned char selorder;

    extern unsigned char selinstrument;
    extern unsigned char edit_step;
    extern unsigned char octave;




    //PATTERN EDITOR CLIPBOARD
    extern unsigned int entryclipboard;





    //METADATA (Main controls)
    extern unsigned char metaobjindex;
    extern  bool metaobjedit;
    extern unsigned char selobjmeta;//x
    extern unsigned char selrowmeta;//y



}

//Instrument Editor
namespace instedtr
{ 
    //WAVE TABLE
    const unsigned char
        WAVSEG_WAVE = 0,
        WAVSEG_TONE = 1,
        WAVSEG_NUM = 2;

    //VOL TABLE
    const unsigned char
        VOLSEG_VOL = 0,
        VOLSEG_DUR = 1,
        VOLSEG_NUM = 2;
    extern unsigned short waveclipboard;
    extern unsigned short volclipboard;

    extern unsigned short selwavrow;
    extern unsigned char selwavseg;

    extern  bool instobjedit;
    extern unsigned char selinstrow;
    extern unsigned char selinstobj;

    extern unsigned short viewportwave;
    extern unsigned char viewportvol;



    extern unsigned char selvolrow;
    extern unsigned char selvolseg;
}




#endif
