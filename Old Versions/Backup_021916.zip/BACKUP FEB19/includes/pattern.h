#ifndef PATTERN_H_
#define PATTERN_H_

#include<istream>
#include<ostream>

//twelvth root of 2
#define NOTEMULT 1.05946309435929526456f
//more or less arbitrary
//#define BASEFRQ 3200.0f
#define BASEFRQ 4410.0f

//Integer segments
#define R_OCTAVE      0xE0000000
#define R_NOTE        0x1E000000
#define R_INSTRUMENT  0x01FC0000
#define R_VOLUME      0x0003F000
#define R_EFFECT      0x00000F00
#define R_FXPARAM1    0x000000F0
#define R_FXPARAM2    0x0000000F
#define R_FXPARAM     0x000000FF

#define R_PITCHSEG    0xFE000000
#define R_FULLSEG     0xFFFC0000
#define R_EFFECTSEG   0x00000FFF

#define RI_OCTAVE     29
#define RI_NOTE       25
#define RI_INSTRUMENT 18
#define RI_VOLUME     12
#define RI_EFFECT     8
#define RI_FXPARAM1   4

//For empty cells in pattern editor
#define R_EMPTY 0xFFFFF000

//Holds data for one pattern of a song
class Pattern
{
    private:
        unsigned int **data;
        unsigned char tracks;
        unsigned char rows;

    public:
        Pattern();
        Pattern(std::istream &in);
        Pattern(unsigned int track, unsigned int length);
        Pattern(const Pattern &other);
        ~Pattern();



        std::ostream &output(std::ostream &out) const;
        std::istream &input(std::istream &in);

        unsigned char numTracks() const {return tracks;}
        unsigned char numRows() const {return rows;};

        void setSize(const unsigned char &newtrack, const unsigned char &newrow);

        void setRowNum(const unsigned char &newrow);
        void setTrackNum(const unsigned char &newtrack);
        void setAt(const unsigned char &track, const unsigned char &row, const unsigned int &cell);
        void setTrack(const unsigned char &which, unsigned int *track);
        void setRow(const unsigned char &which, unsigned int *row);
        unsigned int size();

        void clearAt(const unsigned char &track, const unsigned char &row);
        void clearTrack(const unsigned char &which);
        void clearRow(const unsigned char &which);
        void clear();

        unsigned int at(const unsigned char &track, const unsigned char &row);
        unsigned int *trackAt(const unsigned char &track);

        void purgeInstrument(const unsigned char &inst);
        void transpose(const unsigned char &track, const unsigned char &row, const char &semitones);

};

#endif
